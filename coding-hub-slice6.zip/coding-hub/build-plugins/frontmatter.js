/**
 * frontmatter.js
 *
 * A deliberately tiny frontmatter parser — just enough to handle the flat
 * key: value and key: [array] shapes used in this project's lesson
 * frontmatter (spec §5.2). Not a full YAML parser; that's a conscious
 * scope decision so the build pipeline has one fewer dependency; if
 * lesson frontmatter ever needs nested structures, swap this for a real
 * YAML library rather than extending the regex-based approach here.
 */

/**
 * @param {string} raw - Full markdown file contents, optionally starting
 *   with a `---` delimited frontmatter block.
 * @returns {{ frontmatter: Object, body: string }}
 */
export function parseFrontmatter(raw) {
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!match) {
    return { frontmatter: {}, body: raw };
  }

  const [, frontmatterBlock, body] = match;
  const frontmatter = {};

  for (const line of frontmatterBlock.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const colonIndex = trimmed.indexOf(':');
    if (colonIndex === -1) continue;

    const key = trimmed.slice(0, colonIndex).trim();
    let value = trimmed.slice(colonIndex + 1).trim();

    frontmatter[key] = parseValue(value);
  }

  return { frontmatter, body: body.trim() };
}

/**
 * @param {string} value - Raw string value from a frontmatter line.
 * @returns {string|number|boolean|Array<string>}
 */
function parseValue(value) {
  // Array: ["a", "b"] or [] — flat string arrays only, matching how this
  // project's lesson frontmatter uses `tags` and `prerequisites`.
  if (value.startsWith('[') && value.endsWith(']')) {
    const inner = value.slice(1, -1).trim();
    if (!inner) return [];
    return inner
      .split(',')
      .map((item) => stripQuotes(item.trim()))
      .filter((item) => item.length > 0);
  }

  if (value === 'true') return true;
  if (value === 'false') return false;
  if (/^-?\d+$/.test(value)) return parseInt(value, 10);
  if (/^-?\d+\.\d+$/.test(value)) return parseFloat(value);

  return stripQuotes(value);
}

/**
 * @param {string} str
 * @returns {string}
 */
function stripQuotes(str) {
  if (
    (str.startsWith('"') && str.endsWith('"')) ||
    (str.startsWith("'") && str.endsWith("'"))
  ) {
    return str.slice(1, -1);
  }
  return str;
}
