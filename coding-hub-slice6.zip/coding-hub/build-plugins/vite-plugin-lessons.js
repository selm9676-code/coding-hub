/**
 * vite-plugin-lessons.js
 *
 * Build-time content pipeline (spec §5.2, §5.3, §14):
 *
 *  1. Walks `src/data/<languageId>/<tier>/*.md`.
 *  2. Parses frontmatter + body for each lesson.
 *  3. Converts the Markdown body to sanitized HTML via `marked`.
 *  4. Extracts fenced code blocks separately (for "Try It" editor buttons).
 *  5. Loads each language's `quizzes.json` (spec §5.3) and populates each
 *     compiled lesson's `quizIds` with quizzes whose `lessonId` matches.
 *  6. Writes one compiled JSON file per lesson to `dist/data/...`,
 *     mirroring the source path but with `.json` instead of `.md`.
 *  7. Copies `languages.json`, each language's `meta.json`, and each
 *     language's `quizzes.json` through unchanged (already JSON, but
 *     need to land in `dist/data/` alongside the compiled lessons).
 *  8. Builds a single `search-index.json` at `dist/search-index.json`
 *     covering language names + lesson titles/tags.
 *
 * This plugin only runs on `vite build` (via `generateBundle`), not in
 * dev — see `devLessonsMiddleware.js` for the dev-server equivalent,
 * which serves the same compiled shape on the fly so `npm run dev`
 * doesn't require a separate build step.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { marked } from 'marked';
import { parseFrontmatter } from './frontmatter.js';

const DATA_DIR = 'src/data';

/**
 * @returns {import('vite').Plugin}
 */
export function lessonsPlugin() {
  return {
    name: 'coding-hub:lessons',

    generateBundle() {
      const { languagesJson, languageMetaJsonByLang, languageQuizzesJsonByLang, compiledLessons } =
        compileAllContent();

      this.emitFile({
        type: 'asset',
        fileName: 'data/languages.json',
        source: languagesJson,
      });

      for (const [languageId, metaJson] of Object.entries(languageMetaJsonByLang)) {
        this.emitFile({
          type: 'asset',
          fileName: `data/${languageId}/meta.json`,
          source: metaJson,
        });
      }

      for (const [languageId, quizzesJson] of Object.entries(languageQuizzesJsonByLang)) {
        this.emitFile({
          type: 'asset',
          fileName: `data/${languageId}/quizzes.json`,
          source: quizzesJson,
        });
      }

      for (const lesson of compiledLessons) {
        this.emitFile({
          type: 'asset',
          fileName: lesson.outputPath,
          source: JSON.stringify(lesson.compiled, null, 2),
        });
      }

      const searchIndex = buildSearchIndex(compiledLessons);
      this.emitFile({
        type: 'asset',
        fileName: 'search-index.json',
        source: JSON.stringify(searchIndex, null, 2),
      });
    },
  };
}

/**
 * Walks the data directory, compiles every lesson, and returns everything
 * downstream steps need. Pulled into its own function (rather than inlined
 * in generateBundle) so the dev-server middleware can reuse it.
 */
export function compileAllContent() {
  const languagesJson = readFileSync(join(DATA_DIR, 'languages.json'), 'utf-8');
  const languages = JSON.parse(languagesJson);

  const languageMetaJsonByLang = {};
  const languageQuizzesJsonByLang = {};
  const compiledLessons = [];

  for (const language of languages) {
    const languageDir = join(DATA_DIR, language.id);
    let metaRaw;
    try {
      metaRaw = readFileSync(join(languageDir, 'meta.json'), 'utf-8');
    } catch {
      // Roadmap languages (spec: 15 remaining languages with roadmap
      // pages) have no meta.json yet — that's expected, not an error.
      continue;
    }
    languageMetaJsonByLang[language.id] = metaRaw;

    // quizzes.json is optional — a language can have lessons with no
    // quizzes authored yet without breaking the build.
    let quizzesByLessonId = {};
    try {
      const quizzesRaw = readFileSync(join(languageDir, 'quizzes.json'), 'utf-8');
      languageQuizzesJsonByLang[language.id] = quizzesRaw;
      const quizzes = JSON.parse(quizzesRaw);
      for (const quiz of quizzes) {
        if (!quizzesByLessonId[quiz.lessonId]) quizzesByLessonId[quiz.lessonId] = [];
        quizzesByLessonId[quiz.lessonId].push(quiz.id);
      }
    } catch {
      // no quizzes.json for this language yet
    }

    for (const tier of language.tiers) {
      const tierDir = join(languageDir, tier);
      let files;
      try {
        files = readdirSync(tierDir).filter((f) => f.endsWith('.md'));
      } catch {
        continue; // tier has no lessons yet
      }

      for (const file of files) {
        const fullPath = join(tierDir, file);
        const raw = readFileSync(fullPath, 'utf-8');
        const compiled = compileLesson(raw, language.id, tier);
        compiled.quizIds = quizzesByLessonId[compiled.id] ?? [];
        const outputPath = `data/${relative(DATA_DIR, fullPath).replace(/\.md$/, '.json').split('\\').join('/')}`;
        compiledLessons.push({ languageId: language.id, tier, outputPath, compiled });
      }
    }
  }

  return { languagesJson, languageMetaJsonByLang, languageQuizzesJsonByLang, compiledLessons };
}

/**
 * @param {string} raw - Raw .md file content including frontmatter.
 * @param {string} languageId
 * @param {string} tier
 * @returns {Object} Compiled lesson JSON matching spec §5.2's shape.
 */
export function compileLesson(raw, languageId, tier) {
  const { frontmatter, body } = parseFrontmatter(raw);
  const codeBlocks = extractCodeBlocks(body);
  const html = marked.parse(body);

  return {
    id: frontmatter.id,
    title: frontmatter.title,
    tier: frontmatter.tier ?? tier,
    languageId,
    duration: frontmatter.duration ?? 0,
    xp: frontmatter.xp ?? 0,
    prerequisites: frontmatter.prerequisites ?? [],
    tags: frontmatter.tags ?? [],
    html,
    codeBlocks,
    // Populated by compileAllContent() after this returns, by matching
    // this lesson's id against quizzes.json's lessonId field — kept out
    // of compileLesson() itself so this function stays a pure
    // markdown-in/JSON-out transform with no knowledge of sibling files.
    quizIds: [],
  };
}

/**
 * Extracts fenced code blocks (```lang ... ```) from a lesson body so the
 * "Run in Editor" button (spec §8.6) can pre-populate the editor without
 * re-parsing the rendered HTML.
 *
 * @param {string} markdown
 * @returns {Array<{ language: string, code: string }>}
 */
function extractCodeBlocks(markdown) {
  const blocks = [];
  const fencePattern = /```(\w+)?\n([\s\S]*?)```/g;
  let match;
  while ((match = fencePattern.exec(markdown)) !== null) {
    blocks.push({
      language: match[1] || 'text',
      code: match[2].replace(/\n$/, ''),
    });
  }
  return blocks;
}

/**
 * @param {Array<{languageId: string, tier: string, compiled: Object}>} compiledLessons
 * @returns {Array<Object>} Flat search index entries (spec §14).
 *
 * Note: only lesson entries are indexed here, even though quizzes now
 * exist as of Slice 5. The search UI itself (fuzzy matching, the search
 * modal, keyboard nav) is explicitly Slice 7 in the delivery plan — until
 * that UI exists to consume them, adding quiz entries to this index
 * wouldn't be tested against anything and risks guessing at a shape the
 * actual search feature doesn't end up needing. This index format is
 * revisited when Slice 7 builds the real consumer.
 */
function buildSearchIndex(compiledLessons) {
  return compiledLessons.map((lesson) => ({
    type: 'lesson',
    languageId: lesson.languageId,
    tier: lesson.tier,
    lessonId: lesson.compiled.id,
    title: lesson.compiled.title,
    tags: lesson.compiled.tags,
    path: `/language/${lesson.languageId}/${lesson.tier}/${lesson.compiled.id}`,
  }));
}
