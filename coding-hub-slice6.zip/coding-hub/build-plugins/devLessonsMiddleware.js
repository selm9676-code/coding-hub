/**
 * devLessonsMiddleware.js
 *
 * `generateBundle` (used by vite-plugin-lessons.js) only fires on
 * `vite build`, not during `vite dev`. Without this, running the app in
 * dev mode would 404 on every `/data/*.json` fetch. This middleware
 * intercepts those requests and compiles content on the fly using the
 * same `compileAllContent()` used by the production build, so dev and
 * prod always render identical content from identical source files.
 *
 * Not optimized for hot-reload-on-every-keystroke — it recompiles all
 * content on every matching request, which is fine at this project's
 * content scale (a handful of lessons per language in early slices) and
 * keeps this file simple. If content volume grows large enough to make
 * that slow, add a mtime-based cache here rather than restructuring the
 * plugin.
 */
import { compileAllContent } from './vite-plugin-lessons.js';

/**
 * @returns {import('vite').Plugin}
 */
export function devLessonsMiddlewarePlugin() {
  return {
    name: 'coding-hub:dev-lessons-middleware',
    apply: 'serve',

    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (!req.url?.startsWith('/data/') && req.url !== '/search-index.json') {
          return next();
        }

        let payload;
        try {
          const { languagesJson, languageMetaJsonByLang, languageQuizzesJsonByLang, compiledLessons } =
            compileAllContent();

          if (req.url === '/data/languages.json') {
            payload = languagesJson;
          } else if (req.url === '/search-index.json') {
            payload = JSON.stringify(
              compiledLessons.map((lesson) => ({
                type: 'lesson',
                languageId: lesson.languageId,
                tier: lesson.tier,
                lessonId: lesson.compiled.id,
                title: lesson.compiled.title,
                tags: lesson.compiled.tags,
                path: `/language/${lesson.languageId}/${lesson.tier}/${lesson.compiled.id}`,
              })),
              null,
              2
            );
          } else {
            const metaMatch = req.url.match(/^\/data\/([^/]+)\/meta\.json$/);
            const quizzesMatch = req.url.match(/^\/data\/([^/]+)\/quizzes\.json$/);
            if (metaMatch) {
              payload = languageMetaJsonByLang[metaMatch[1]];
            } else if (quizzesMatch) {
              payload = languageQuizzesJsonByLang[quizzesMatch[1]];
            } else {
              const lessonMatch = compiledLessons.find(
                (l) => `/${l.outputPath}` === req.url
              );
              payload = lessonMatch ? JSON.stringify(lessonMatch.compiled, null, 2) : undefined;
            }
          }
        } catch (err) {
          res.statusCode = 500;
          res.end(`Content compilation error: ${err.message}`);
          return;
        }

        if (payload === undefined) {
          return next();
        }

        res.setHeader('Content-Type', 'application/json');
        res.end(payload);
      });
    },
  };
}
