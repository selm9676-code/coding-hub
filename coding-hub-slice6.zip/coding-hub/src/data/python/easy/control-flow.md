---
id: control-flow
title: Control Flow
tier: easy
duration: 20
xp: 100
prerequisites: ["variables"]
tags: ["basics", "logic"]
---

# Control Flow

Control flow lets your program make decisions and repeat work, rather
than just running top to bottom.

## if / elif / else

```python
age = 20

if age < 13:
    print("child")
elif age < 20:
    print("teenager")
else:
    print("adult")
```

Python uses **indentation** (not braces) to mark which lines belong to
which block. Consistent indentation isn't a style preference here — it's
required syntax.

## Loops

A `for` loop iterates over a sequence:

```python
for i in range(5):
    print(i)
```

A `while` loop repeats as long as a condition is true:

```python
count = 0
while count < 3:
    print(count)
    count += 1
```

Remember: a `while` loop with a condition that never becomes false will
run forever. Always make sure something inside the loop moves it toward
the exit condition.
