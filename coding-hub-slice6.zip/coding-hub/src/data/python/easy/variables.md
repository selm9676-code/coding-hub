---
id: variables
title: Variables & Data Types
tier: easy
duration: 15
xp: 100
prerequisites: []
tags: ["basics", "memory"]
---

# Variables

A variable is a name that refers to a value stored in memory. In Python,
you create one just by assigning to it — there's no separate declaration
step.

```python
x = 5
name = "Ada"
is_valid = True
```

Python is **dynamically typed**: the type of a variable is determined by
the value it currently holds, and can change if you reassign it.

```python
x = 5
x = "now a string"
```

## Core data types

Python has a handful of built-in types you'll use constantly:

- `int` — whole numbers, like `42`
- `float` — decimal numbers, like `3.14`
- `str` — text, like `"hello"`
- `bool` — `True` or `False`
- `list` — an ordered, changeable collection, like `[1, 2, 3]`

```python
count = 10          # int
price = 19.99        # float
label = "widget"     # str
in_stock = True       # bool
items = [1, 2, 3]    # list
```

Don't use reserved keywords (like `class`, `for`, or `if`) as variable
names — Python will raise a `SyntaxError`.
