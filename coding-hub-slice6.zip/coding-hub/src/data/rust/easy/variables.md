---
id: variables
title: Variables & Mutability
tier: easy
duration: 20
xp: 100
prerequisites: []
tags: ["basics", "memory", "ownership"]
---

# Variables & Mutability

Rust variables are **immutable by default** — a deliberate design choice
that prevents an entire class of bugs where a value changes
unexpectedly.

```rust
let x = 5;
x = 6; // compile error: cannot assign twice to immutable variable
```

To make a variable mutable, opt in explicitly with `mut`:

```rust
let mut x = 5;
x = 6; // fine
```

## Core types

Rust is statically typed, and the compiler can usually infer types from
context:

```rust
let count = 10;              // i32 (inferred)
let price: f64 = 19.99;       // f64 (explicit)
let label = String::from("widget");
let in_stock = true;
```

## Why immutability matters here

Rust's ownership system tracks exactly who can read or modify a piece of
data at any moment. Defaulting to immutable means the compiler can
reason about your data more strictly, which is a big part of how Rust
guarantees memory safety without a garbage collector.
