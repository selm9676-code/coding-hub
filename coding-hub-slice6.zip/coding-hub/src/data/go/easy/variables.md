---
id: variables
title: Variables & Data Types
tier: easy
duration: 15
xp: 100
prerequisites: []
tags: ["basics", "memory"]
---

# Variables

Go is statically typed, but it can often infer a variable's type for
you using the `:=` short declaration:

```go
count := 10          // int, inferred
price := 19.99        // float64, inferred
label := "widget"     // string, inferred
inStock := true        // bool, inferred
```

Outside a function, or when you want to be explicit, use `var`:

```go
var count int = 10
var label string = "widget"
```

## Zero values

Unlike C++, Go always initializes variables — you never get garbage
memory. A declared-but-unassigned variable gets its type's **zero
value**:

```go
var count int      // 0
var label string    // ""
var inStock bool     // false
```

This is one of Go's core design philosophies: predictable, boring
defaults so there's one less category of bug to worry about.
