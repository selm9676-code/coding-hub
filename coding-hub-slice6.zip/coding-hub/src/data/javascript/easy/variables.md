---
id: variables
title: Variables & Data Types
tier: easy
duration: 15
xp: 100
prerequisites: []
tags: ["basics", "memory"]
---

# Variables

JavaScript gives you three ways to declare a variable: `let`, `const`,
and `var`. In modern code, you'll use `let` and `const` almost
exclusively.

```javascript
let score = 0;
const name = "Ada";
```

Use `const` when a variable's value won't be reassigned, and `let` when
it will. Avoid `var` — it has confusing scoping rules that `let` and
`const` were introduced to fix.

## Core data types

```javascript
let count = 10;             // number
let label = "widget";        // string
let inStock = true;          // boolean
let items = [1, 2, 3];       // array
let nothing = null;          // null
let notSet;                  // undefined
```

JavaScript is dynamically typed, like Python: a variable's type is
determined by its current value, not fixed at declaration.

```javascript
let x = 5;
x = "now a string"; // totally legal, if not always a good idea
```
