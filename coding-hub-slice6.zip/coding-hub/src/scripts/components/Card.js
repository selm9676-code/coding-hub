/**
 * Card.js
 *
 * Factory class for the card family (spec §8.6, §9): language cards on
 * the home grid, lesson cards on tier list pages, stat cards on the
 * progress dashboard. One class with a `variant` covers all three since
 * they share the same visual chrome (`.card` base class) and differ only
 * in their inner content template.
 *
 * Usage:
 *   const card = new Card({ variant: 'language', data: languageEntry, staggerIndex: 2 });
 *   card.mount(gridContainer);
 */

export class Card {
  /** @type {HTMLElement} */
  el;

  /**
   * @param {Object} options
   * @param {'language'|'lesson'|'stat'} options.variant
   * @param {Object} options.data - Shape depends on variant; see #render*.
   * @param {number} [options.staggerIndex] - For staggered entrance animation (spec §8.6).
   * @param {(data: Object) => void} [options.onClick] - Optional click handler; if omitted and data.href is set, the card is a real link.
   */
  constructor({ variant, data, staggerIndex = 0, onClick }) {
    this.variant = variant;
    this.data = data;

    const isLink = Boolean(data.href) && !onClick;
    this.el = document.createElement(isLink ? 'a' : 'div');
    this.el.className = 'card card--entrance';
    this.el.style.setProperty('--stagger-index', String(staggerIndex));

    if (isLink) {
      this.el.href = data.href;
    } else {
      this.el.setAttribute('role', 'button');
      this.el.tabIndex = 0;
      this.el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick?.(data);
        }
      });
    }

    if (onClick) {
      this.el.addEventListener('click', () => onClick(data));
    }

    if (variant === 'language') {
      this.#renderLanguage();
    } else if (variant === 'lesson') {
      this.#renderLesson();
    } else if (variant === 'stat') {
      this.#renderStat();
    }
  }

  #renderLanguage() {
    const { name, tagline, accentColor, difficulty, estimatedHours, status } = this.data;
    this.el.style.borderTopWidth = '3px';
    this.el.style.borderTopColor = accentColor;
    this.el.style.borderTopStyle = 'solid';

    const statusPill =
      status === 'roadmap'
        ? `<span class="pill" style="margin-left:auto;">Coming soon</span>`
        : `<span class="pill" style="margin-left:auto; color:${accentColor}; border-color:${accentColor}66;">${escapeHtml(difficulty)}</span>`;

    this.el.innerHTML = `
      <div style="display:flex; align-items:center; gap: var(--space-2); margin-bottom: var(--space-3);">
        <h3 style="font-size: var(--text-lg); color:${accentColor};">${escapeHtml(name)}</h3>
        ${statusPill}
      </div>
      <p style="color: var(--text-secondary); font-size: var(--text-sm); line-height: var(--leading-relaxed);">
        ${escapeHtml(tagline ?? '')}
      </p>
      <p style="color: var(--text-tertiary); font-size: var(--text-xs); margin-top: var(--space-4);">
        ${estimatedHours ? `~${estimatedHours} hours` : 'Roadmap'}
      </p>
    `;
  }

  #renderLesson() {
    const { title, duration, xp, completed } = this.data;
    this.el.innerHTML = `
      <div style="display:flex; align-items:center; justify-content:space-between; gap: var(--space-3);">
        <h3 style="font-size: var(--text-base);">${escapeHtml(title)}</h3>
        ${completed ? '<span class="pill" style="color: var(--success); border-color: rgba(0,230,118,0.3);">Done</span>' : ''}
      </div>
      <p style="color: var(--text-tertiary); font-size: var(--text-xs); margin-top: var(--space-3);">
        ${duration ? `${duration} min` : ''}${duration && xp ? ' · ' : ''}${xp ? `${xp} XP` : ''}
      </p>
    `;
  }

  #renderStat() {
    const { label, value } = this.data;
    this.el.innerHTML = `
      <p style="color: var(--text-tertiary); font-size: var(--text-sm);">${escapeHtml(label)}</p>
      <p style="font-size: var(--text-3xl); font-weight: var(--font-bold); margin-top: var(--space-2);">${escapeHtml(String(value))}</p>
    `;
  }

  /** @param {HTMLElement} parent */
  mount(parent) {
    parent.appendChild(this.el);
  }

  destroy() {
    this.el.remove();
  }
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
