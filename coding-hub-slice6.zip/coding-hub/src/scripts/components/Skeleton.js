/**
 * Skeleton.js
 *
 * Loading placeholder matching the card structure it stands in for
 * (spec §8.7, §9). Renders a grid of shimmering blocks the same
 * dimensions as a real card grid, so there's no layout shift when real
 * content replaces it.
 */

export class Skeleton {
  /** @type {HTMLElement} */
  el;

  /**
   * @param {Object} [options]
   * @param {number} [options.count] - How many skeleton cards to render.
   * @param {string} [options.height] - CSS height for each skeleton block.
   */
  constructor({ count = 6, height = '160px' } = {}) {
    this.el = document.createElement('div');
    this.el.className = 'grid';
    this.el.setAttribute('aria-busy', 'true');
    this.el.setAttribute('aria-label', 'Loading content');

    for (let i = 0; i < count; i += 1) {
      const block = document.createElement('div');
      block.className = 'skeleton';
      block.style.height = height;
      block.style.borderRadius = 'var(--radius-lg)';
      this.el.appendChild(block);
    }
  }

  /** @param {HTMLElement} parent */
  mount(parent) {
    parent.appendChild(this.el);
  }

  destroy() {
    this.el.remove();
  }
}
