/**
 * Store.js
 *
 * A minimal, dependency-free Redux-like state container.
 *
 * Design contract (spec §7):
 *  - Single source of truth: one Store instance for the whole app.
 *  - UI components NEVER touch storage directly. They dispatch actions;
 *    the Store runs reducers to produce new state; a persistence
 *    subscriber (wired in bootstrap.js) writes relevant slices to a
 *    StorageProvider; UI subscribers re-render from the new state.
 *  - Reducers are pure: (state, action) => nextState. No side effects,
 *    no async work, no direct DOM access inside a reducer.
 *  - Slices register themselves via `registerSlice(key, reducer, initialState)`
 *    so feature modules stay independent of each other and of the Store's
 *    internals.
 */

/**
 * @typedef {Object} Action
 * @property {string} type - Namespaced action type, e.g. 'progress/completeLesson'.
 * @property {*} [payload] - Action-specific data.
 */

/**
 * @callback Reducer
 * @param {*} sliceState - Current state for this slice.
 * @param {Action} action - The dispatched action.
 * @returns {*} Next state for this slice. Must return a new reference when
 *   the slice actually changes so subscribers can cheaply diff with !==.
 */

/**
 * @callback Subscriber
 * @param {Object} state - Full state tree after the action was applied.
 * @param {Object} prevState - Full state tree before the action was applied.
 * @param {Action} action - The action that triggered this notification.
 */

export class Store {
  /** @type {Object.<string, Reducer>} */
  #reducers = {};

  /** @type {Object} */
  #state = {};

  /** @type {Set<Subscriber>} */
  #subscribers = new Set();

  /** @type {boolean} guards against reducers dispatching synchronously */
  #isDispatching = false;

  /** @type {Action[]} queue for actions dispatched while already dispatching */
  #pendingActions = [];

  constructor() {
    this.dispatch = this.dispatch.bind(this);
  }

  /**
   * Register a slice of state with its reducer. Must be called before any
   * action targeting that slice is dispatched (typically during app boot,
   * see bootstrap.js).
   *
   * @param {string} key - Unique slice key, becomes `state[key]`.
   * @param {Reducer} reducer - Pure reducer function for this slice.
   * @param {*} initialState - Seed value for the slice, usually overwritten
   *   immediately afterward by a StorageProvider hydration pass.
   */
  registerSlice(key, reducer, initialState) {
    if (this.#reducers[key]) {
      throw new Error(`Store: slice "${key}" is already registered.`);
    }
    this.#reducers[key] = reducer;
    this.#state = { ...this.#state, [key]: initialState };
  }

  /**
   * Replace an already-registered slice's state wholesale. Used by
   * StorageProvider during initial hydration (loading persisted data before
   * the user interacts with anything) — this bypasses the reducer
   * intentionally since hydration is not a user action.
   *
   * @param {string} key
   * @param {*} value
   */
  hydrateSlice(key, value) {
    if (!(key in this.#reducers)) {
      throw new Error(`Store: cannot hydrate unregistered slice "${key}".`);
    }
    const prevState = this.#state;
    this.#state = { ...this.#state, [key]: value };
    this.#notify(this.#state, prevState, { type: '@@hydrate', payload: { key } });
  }

  /**
   * @returns {Object} The current full state tree. Treat as read-only —
   *   never mutate the returned object directly.
   */
  getState() {
    return this.#state;
  }

  /**
   * Dispatch an action. Runs every registered reducer with the action;
   * reducers that don't recognize the action type should return their
   * slice's state unchanged (standard reducer convention).
   *
   * Re-entrant dispatch (a subscriber calling dispatch synchronously) is
   * queued and flushed after the current dispatch completes, so reducers
   * and subscribers never observe a half-applied state.
   *
   * @param {Action} action
   */
  dispatch(action) {
    if (!action || typeof action.type !== 'string') {
      throw new Error('Store: dispatched actions must be objects with a string "type".');
    }

    if (this.#isDispatching) {
      this.#pendingActions.push(action);
      return;
    }

    this.#isDispatching = true;
    const prevState = this.#state;
    let nextState = prevState;

    try {
      for (const key of Object.keys(this.#reducers)) {
        const reducer = this.#reducers[key];
        const prevSliceState = prevState[key];
        const nextSliceState = reducer(prevSliceState, action);
        if (nextSliceState !== prevSliceState) {
          if (nextState === prevState) {
            nextState = { ...prevState };
          }
          nextState[key] = nextSliceState;
        }
      }
    } finally {
      this.#isDispatching = false;
    }

    this.#state = nextState;

    if (nextState !== prevState) {
      this.#notify(nextState, prevState, action);
    }

    if (this.#pendingActions.length > 0) {
      const next = this.#pendingActions.shift();
      this.dispatch(next);
    }
  }

  /**
   * Subscribe to every state change. Returns an unsubscribe function.
   *
   * @param {Subscriber} callback
   * @returns {() => void}
   */
  subscribe(callback) {
    this.#subscribers.add(callback);
    return () => this.#subscribers.delete(callback);
  }

  #notify(state, prevState, action) {
    for (const callback of this.#subscribers) {
      callback(state, prevState, action);
    }
  }
}

/**
 * Singleton store instance shared across the whole app. Feature modules
 * import this directly rather than constructing their own Store, so slice
 * registration in bootstrap.js is the single place slices are wired up.
 */
export const store = new Store();
