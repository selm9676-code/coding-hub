/**
 * notesSlice.js
 *
 * Mirrors the `notes` IndexedDB object store (spec §6, §16). Notes are
 * plain text with Markdown support (rendered, not stored differently —
 * `content` is always the raw Markdown source; NoteManager.js renders it
 * for display via the same sanitizeHtml() chokepoint as lesson content).
 *
 * Shape:
 * {
 *   byId: {
 *     [noteId]: { id, lessonId, content, updatedAt }
 *   }
 * }
 */

export const NOTES_INITIAL_STATE = {
  byId: {},
};

export function notesReducer(state = NOTES_INITIAL_STATE, action) {
  switch (action.type) {
    case 'notes/save': {
      const { id, lessonId, content } = action.payload;
      return {
        ...state,
        byId: {
          ...state.byId,
          [id]: { id, lessonId, content, updatedAt: new Date().toISOString() },
        },
      };
    }

    case 'notes/delete': {
      const { id } = action.payload;
      const next = { ...state.byId };
      delete next[id];
      return { ...state, byId: next };
    }

    case 'notes/reset':
      return NOTES_INITIAL_STATE;

    default:
      return state;
  }
}
