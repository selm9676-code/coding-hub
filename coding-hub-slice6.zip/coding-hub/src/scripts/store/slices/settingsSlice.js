/**
 * settingsSlice.js
 *
 * User preferences, mirroring the `settings` IndexedDB object store
 * (spec §6). Small, flat, and fully persisted on every change.
 */

export const SETTINGS_INITIAL_STATE = {
  theme: 'dark', // v1.0 is dark-only (spec §2); reserved for future light mode.
  editorConfig: {
    fontSize: 14,
    tabSize: 2,
    keymap: 'default',
  },
  lastRoute: '/home',
  dailyGoalMinutes: 15,
};

export function settingsReducer(state = SETTINGS_INITIAL_STATE, action) {
  switch (action.type) {
    case 'settings/updateEditorConfig':
      return {
        ...state,
        editorConfig: { ...state.editorConfig, ...action.payload },
      };

    case 'settings/setLastRoute':
      return { ...state, lastRoute: action.payload.route };

    case 'settings/setDailyGoal':
      return { ...state, dailyGoalMinutes: action.payload.minutes };

    default:
      return state;
  }
}
