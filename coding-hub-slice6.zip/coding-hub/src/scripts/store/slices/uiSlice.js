/**
 * uiSlice.js
 *
 * Transient, non-persisted UI state: which modal is open, active toasts,
 * editor drawer collapsed state, current route params echoed for
 * convenience. This slice is intentionally excluded from persistence —
 * bootstrap.js's persistence subscriber should skip `state.ui` entirely.
 *
 * Shape:
 * {
 *   activeModal: null | { id: string, props: Object },
 *   toasts: Array<{ id, variant, message, durationMs }>,
 *   editorDrawerCollapsed: boolean,
 *   editorFullscreen: boolean,
 *   sidebarOpen: boolean
 * }
 */

export const UI_INITIAL_STATE = {
  activeModal: null,
  toasts: [],
  editorDrawerCollapsed: true,
  editorFullscreen: false,
  sidebarOpen: false,
};

export function uiReducer(state = UI_INITIAL_STATE, action) {
  switch (action.type) {
    case 'ui/openModal':
      return { ...state, activeModal: { id: action.payload.id, props: action.payload.props ?? {} } };

    case 'ui/closeModal':
      return { ...state, activeModal: null };

    case 'ui/pushToast':
      return { ...state, toasts: [...state.toasts, action.payload] };

    case 'ui/dismissToast':
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.payload.id) };

    case 'ui/toggleEditorDrawer':
      return { ...state, editorDrawerCollapsed: !state.editorDrawerCollapsed };

    case 'ui/setEditorFullscreen':
      return { ...state, editorFullscreen: action.payload.value };

    case 'ui/toggleSidebar':
      return { ...state, sidebarOpen: !state.sidebarOpen };

    default:
      return state;
  }
}
