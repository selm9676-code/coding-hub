/**
 * quizSlice.js
 *
 * Tracks quiz attempts and scores, mirroring the `quizResults` IndexedDB
 * object store (spec §6). First-attempt score counts toward completion;
 * subsequent attempts are marked as practice (spec §13).
 *
 * Shape:
 * {
 *   byQuizId: {
 *     [quizId]: { quizId, attempts, bestScore, completedAt, firstAttemptScore, hintsUsed }
 *   }
 * }
 */

export const QUIZ_INITIAL_STATE = {
  byQuizId: {},
};

export function quizReducer(state = QUIZ_INITIAL_STATE, action) {
  switch (action.type) {
    case 'quiz/recordAttempt': {
      const { quizId, score, hintsUsed = false } = action.payload;
      const existing = state.byQuizId[quizId];
      const attempts = (existing?.attempts ?? 0) + 1;
      const isFirstAttempt = attempts === 1;

      const entry = {
        quizId,
        attempts,
        bestScore: Math.max(existing?.bestScore ?? 0, score),
        completedAt: new Date().toISOString(),
        firstAttemptScore: isFirstAttempt ? score : existing?.firstAttemptScore ?? null,
        hintsUsed: existing?.hintsUsed || hintsUsed,
      };

      return {
        ...state,
        byQuizId: { ...state.byQuizId, [quizId]: entry },
      };
    }

    case 'quiz/reset':
      return QUIZ_INITIAL_STATE;

    default:
      return state;
  }
}
