/**
 * progressSlice.js
 *
 * Tracks per-lesson completion state. Mirrors the `progress` object store
 * defined in the IndexedDB schema (spec §6), keyed by lessonId so lookups
 * during lesson rendering are O(1).
 *
 * Shape:
 * {
 *   byLessonId: {
 *     [lessonId]: { lessonId, completedAt, score, timeSpent }
 *   },
 *   recentlyViewed: [lessonId, ...]   // max 20, most recent first
 * }
 */

export const PROGRESS_INITIAL_STATE = {
  byLessonId: {},
  recentlyViewed: [],
};

const MAX_RECENTLY_VIEWED = 20;

/**
 * @param {typeof PROGRESS_INITIAL_STATE} state
 * @param {import('../Store.js').Action} action
 */
export function progressReducer(state = PROGRESS_INITIAL_STATE, action) {
  switch (action.type) {
    case 'progress/completeLesson': {
      const { lessonId, score = null, timeSpent = 0 } = action.payload;
      const existing = state.byLessonId[lessonId];
      const entry = {
        lessonId,
        completedAt: new Date().toISOString(),
        score,
        timeSpent: (existing?.timeSpent ?? 0) + timeSpent,
      };
      return {
        ...state,
        byLessonId: { ...state.byLessonId, [lessonId]: entry },
      };
    }

    case 'progress/recordView': {
      const { lessonId } = action.payload;
      const withoutCurrent = state.recentlyViewed.filter((id) => id !== lessonId);
      return {
        ...state,
        recentlyViewed: [lessonId, ...withoutCurrent].slice(0, MAX_RECENTLY_VIEWED),
      };
    }

    case 'progress/reset':
      return PROGRESS_INITIAL_STATE;

    default:
      return state;
  }
}
