/**
 * xpSlice.js
 *
 * Mirrors the `xp` IndexedDB object store (spec §6, §15). Level is derived
 * from total XP using a simple curve; kept as a selector rather than
 * stored state so the leveling formula can change without a migration.
 */

export const XP_INITIAL_STATE = {
  total: 0,
  history: [], // { source, amount, date }
};

export function xpReducer(state = XP_INITIAL_STATE, action) {
  switch (action.type) {
    case 'xp/award': {
      const { source, amount } = action.payload;
      return {
        total: state.total + amount,
        history: [...state.history, { source, amount, date: new Date().toISOString() }],
      };
    }

    case 'xp/reset':
      return XP_INITIAL_STATE;

    default:
      return state;
  }
}
