/**
 * achievementsSlice.js
 *
 * Mirrors the `achievements` IndexedDB object store (spec §6, §15).
 * Achievement *definitions* (the list of 20+ possible achievements,
 * their unlock conditions, names, descriptions) live in
 * `AchievementEngine.js` as static data — this slice only tracks which
 * ones have actually been unlocked for this learner, keyed by
 * achievement id.
 *
 * Shape:
 * {
 *   unlockedById: {
 *     [achievementId]: { id, unlockedAt }
 *   }
 * }
 */

export const ACHIEVEMENTS_INITIAL_STATE = {
  unlockedById: {},
};

export function achievementsReducer(state = ACHIEVEMENTS_INITIAL_STATE, action) {
  switch (action.type) {
    case 'achievements/unlock': {
      const { id } = action.payload;
      if (state.unlockedById[id]) return state; // already unlocked, no-op
      return {
        ...state,
        unlockedById: {
          ...state.unlockedById,
          [id]: { id, unlockedAt: new Date().toISOString() },
        },
      };
    }

    case 'achievements/reset':
      return ACHIEVEMENTS_INITIAL_STATE;

    default:
      return state;
  }
}
