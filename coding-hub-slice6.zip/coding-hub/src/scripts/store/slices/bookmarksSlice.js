/**
 * bookmarksSlice.js
 *
 * Mirrors the `bookmarks` IndexedDB object store (spec §6, §16).
 * Bookmarks can target either a lesson or a code snippet — `type`
 * distinguishes them, `targetId` is the lesson id or a snippet
 * identifier (`${lessonId}:${codeBlockIndex}`, assigned by the caller in
 * BookmarkManager.js).
 *
 * Shape:
 * {
 *   byId: {
 *     [bookmarkId]: { id, type: 'lesson'|'snippet', targetId, createdAt }
 *   }
 * }
 */

export const BOOKMARKS_INITIAL_STATE = {
  byId: {},
};

export function bookmarksReducer(state = BOOKMARKS_INITIAL_STATE, action) {
  switch (action.type) {
    case 'bookmarks/add': {
      const { id, bookmarkType, targetId } = action.payload;
      return {
        ...state,
        byId: {
          ...state.byId,
          [id]: { id, type: bookmarkType, targetId, createdAt: new Date().toISOString() },
        },
      };
    }

    case 'bookmarks/remove': {
      const { id } = action.payload;
      const next = { ...state.byId };
      delete next[id];
      return { ...state, byId: next };
    }

    case 'bookmarks/reset':
      return BOOKMARKS_INITIAL_STATE;

    default:
      return state;
  }
}
