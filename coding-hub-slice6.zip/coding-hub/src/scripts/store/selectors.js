/**
 * selectors.js
 *
 * Derived-state queries. Kept separate from slices so components can
 * depend on a stable selector API without knowing slice internals, and so
 * expensive derivations (e.g. level-from-XP curve, streak calculation) are
 * memoized rather than recomputed on every render.
 *
 * Memoization strategy: a simple last-args cache. This is intentionally
 * lightweight — the app has one Store and selectors are called from a
 * small number of subscriber call sites, so a full memoization library
 * would be overkill.
 */

/**
 * @template Args, Result
 * @param {(...args: Args) => Result} fn
 * @returns {(...args: Args) => Result}
 */
function memoizeLast(fn) {
  let lastArgs = null;
  let lastResult;
  return (...args) => {
    if (
      lastArgs &&
      lastArgs.length === args.length &&
      lastArgs.every((a, i) => a === args[i])
    ) {
      return lastResult;
    }
    lastArgs = args;
    lastResult = fn(...args);
    return lastResult;
  };
}

/** XP required to reach each level; level N needs a triangular-ish curve. */
function xpForLevel(level) {
  return 100 * level * (level + 1) / 2;
}

export const selectLevelFromXp = memoizeLast((totalXp) => {
  let level = 1;
  while (xpForLevel(level + 1) <= totalXp) {
    level += 1;
  }
  const currentLevelFloor = xpForLevel(level);
  const nextLevelCeiling = xpForLevel(level + 1);
  return {
    level,
    xpIntoLevel: totalXp - currentLevelFloor,
    xpForNextLevel: nextLevelCeiling - currentLevelFloor,
  };
});

/**
 * @param {Object} state - Full store state.
 * @returns {number} Count of completed lessons.
 */
export function selectCompletedLessonCount(state) {
  return Object.keys(state.progress.byLessonId).length;
}

/**
 * @param {Object} state
 * @param {string} languageId
 * @param {string[]} lessonIdsForLanguage - All lesson ids belonging to the language.
 * @returns {number} 0..1 completion ratio for a language.
 */
export function selectLanguageCompletionRatio(state, languageId, lessonIdsForLanguage) {
  if (lessonIdsForLanguage.length === 0) return 0;
  const completed = lessonIdsForLanguage.filter((id) => state.progress.byLessonId[id]).length;
  return completed / lessonIdsForLanguage.length;
}

/**
 * @param {Object} state
 * @returns {Array} Recently viewed lesson ids, most recent first.
 */
export function selectRecentlyViewed(state) {
  return state.progress.recentlyViewed;
}

/**
 * @param {Object} state
 * @returns {Array} Active toasts in display order.
 */
export function selectToasts(state) {
  return state.ui.toasts;
}
