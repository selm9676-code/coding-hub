/**
 * QuizLoader.js
 *
 * Fetches and caches `data/<languageId>/quizzes.json` (spec §5.3),
 * mirroring `LanguageRegistry.js`'s caching pattern for `languages.json`
 * and `meta.json`. Views resolve a lesson's `quizIds` (populated at
 * build/dev-serve time by the content pipeline) into full quiz
 * definitions through this module, rather than fetching quizzes.json
 * repeatedly per quiz.
 */

/** @type {Map<string, Promise<Array<Object>>>} */
const quizzesPromiseCache = new Map();

/**
 * @param {string} languageId
 * @returns {Promise<Array<Object>>} All quiz definitions for this language.
 */
function getQuizzesForLanguage(languageId) {
  if (!quizzesPromiseCache.has(languageId)) {
    const promise = fetch(`./data/${languageId}/quizzes.json`)
      .then((res) => {
        if (!res.ok) return []; // language has no quizzes.json yet — not an error
        return res.json();
      })
      .catch((err) => {
        quizzesPromiseCache.delete(languageId);
        throw err;
      });
    quizzesPromiseCache.set(languageId, promise);
  }
  return quizzesPromiseCache.get(languageId);
}

/**
 * @param {string} languageId
 * @param {string[]} quizIds
 * @returns {Promise<Array<Object>>} Quiz definitions matching the given ids, in the given order.
 */
export async function getQuizzesByIds(languageId, quizIds) {
  if (!quizIds || quizIds.length === 0) return [];
  const allQuizzes = await getQuizzesForLanguage(languageId);
  const byId = new Map(allQuizzes.map((q) => [q.id, q]));
  return quizIds.map((id) => byId.get(id)).filter(Boolean);
}
