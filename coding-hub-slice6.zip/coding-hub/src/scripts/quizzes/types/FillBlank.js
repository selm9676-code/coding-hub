/**
 * FillBlank.js
 *
 * Quiz type 3/9 (spec §13). Renders `question` with `___` replaced by a
 * text input; matches the trimmed, case-insensitive input against
 * `correct` (a string) or any of `acceptedAnswers` (string[], for
 * questions with more than one valid phrasing — e.g. "int" vs "integer").
 * Requires an explicit Submit action (unlike MultipleChoice/TrueFalse)
 * since a text input can't auto-submit on every keystroke.
 *
 * Quiz data shape:
 * { id, type: 'fill-blank', question, correct: string, acceptedAnswers?: string[], explanation, hints, xp }
 */

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountFillBlank(container, quiz, onSubmit) {
  let answered = false;

  const [before, after] = quiz.question.split('___');

  const form = document.createElement('div');
  form.style.display = 'flex';
  form.style.flexWrap = 'wrap';
  form.style.alignItems = 'center';
  form.style.gap = 'var(--space-2)';

  if (before) {
    const beforeSpan = document.createElement('span');
    beforeSpan.textContent = before;
    form.appendChild(beforeSpan);
  }

  const input = document.createElement('input');
  input.className = 'input';
  input.style.width = 'auto';
  input.style.minWidth = '140px';
  input.style.flex = '0 1 200px';
  input.setAttribute('aria-label', 'Your answer');
  form.appendChild(input);

  if (after) {
    const afterSpan = document.createElement('span');
    afterSpan.textContent = after;
    form.appendChild(afterSpan);
  }

  const submitBtn = document.createElement('button');
  submitBtn.className = 'btn btn--primary';
  submitBtn.textContent = 'Submit';
  submitBtn.style.marginLeft = 'var(--space-2)';

  const acceptedAnswers = [quiz.correct, ...(quiz.acceptedAnswers ?? [])].map((a) =>
    a.trim().toLowerCase()
  );

  const submit = () => {
    if (answered) return;
    answered = true;

    const isCorrect = acceptedAnswers.includes(input.value.trim().toLowerCase());
    input.disabled = true;
    submitBtn.disabled = true;
    input.style.borderColor = isCorrect ? 'var(--success)' : 'var(--error)';

    onSubmit({ correct: isCorrect });
  };

  const onSubmitClick = () => submit();
  const onKeyDown = (e) => {
    if (e.key === 'Enter') submit();
  };

  submitBtn.addEventListener('click', onSubmitClick);
  input.addEventListener('keydown', onKeyDown);

  form.appendChild(submitBtn);
  container.appendChild(form);

  return () => {
    submitBtn.removeEventListener('click', onSubmitClick);
    input.removeEventListener('keydown', onKeyDown);
  };
}
