/**
 * MiniProject.js
 *
 * Quiz type 9/9 (spec §13: "Open-ended code challenges. User writes code
 * in editor; system checks output against test cases."). Structurally
 * this is WriteCode.js with more framing: a fuller task description
 * (rendered as sanitized HTML, matching lesson content rendering) above
 * the editor, and typically more/varied test cases. Kept as a separate
 * file rather than a parameterized variant of WriteCode because the
 * spec lists it as its own quiz type with its own data shape (a
 * `description` field lesson authors fill in with multi-paragraph
 * instructions) — collapsing the two would make WriteCode's simpler data
 * shape carry an unused field for every non-project quiz.
 *
 * Quiz data shape:
 * { id, type: 'mini-project', question, description (HTML-safe markdown-rendered string),
 *   starterCode, editorLanguage, testCases: Array<{input, expectedOutput}>, explanation, hints, xp }
 */
import { Editor } from '../../editor/Editor.js';
import { ExecutionManager } from '../../editor/ExecutionManager.js';
import { sanitizeHtml } from '../../utils/sanitize.js';

const REAL_EXECUTION_LANGUAGES = new Set(['python', 'javascript']);

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountMiniProject(container, quiz, onSubmit) {
  let answered = false;
  const executionManager = new ExecutionManager();

  const descriptionEl = document.createElement('div');
  descriptionEl.className = 'reading-column';
  descriptionEl.style.marginBottom = 'var(--space-4)';
  container.appendChild(descriptionEl);

  if (quiz.description) {
    sanitizeHtml(quiz.description).then((safeHtml) => {
      descriptionEl.innerHTML = safeHtml;
    });
  }

  const editorWrapper = document.createElement('div');
  editorWrapper.style.height = '320px';
  container.appendChild(editorWrapper);

  const editor = new Editor({ code: quiz.starterCode ?? '', editorLanguage: quiz.editorLanguage });
  editor.mount(editorWrapper);

  const resultsEl = document.createElement('div');
  resultsEl.style.marginTop = 'var(--space-3)';
  resultsEl.style.display = 'flex';
  resultsEl.style.flexDirection = 'column';
  resultsEl.style.gap = 'var(--space-1)';
  resultsEl.style.fontSize = 'var(--text-sm)';

  const submitBtn = document.createElement('button');
  submitBtn.className = 'btn btn--primary';
  submitBtn.style.marginTop = 'var(--space-3)';
  submitBtn.textContent = 'Run Tests';

  const onSubmitClick = async () => {
    if (answered) return;
    submitBtn.disabled = true;
    resultsEl.innerHTML = '<p style="color: var(--text-tertiary);">Running tests…</p>';

    const code = editor.getCode();
    const usesRealExecution = REAL_EXECUTION_LANGUAGES.has(quiz.editorLanguage) && quiz.testCases?.length > 0;

    let isCorrect;
    if (usesRealExecution) {
      const outcomes = [];
      for (const testCase of quiz.testCases) {
        const fullCode = `${testCase.input}\n${code}`;
        const result = await executionManager.run(quiz.editorLanguage, fullCode);
        const actual = result.ok ? result.output.trim() : `Error: ${result.error}`;
        outcomes.push({
          expected: testCase.expectedOutput.trim(),
          actual,
          passed: result.ok && actual === testCase.expectedOutput.trim(),
        });
      }
      isCorrect = outcomes.every((o) => o.passed);
      resultsEl.innerHTML = outcomes
        .map(
          (o, i) => `
            <p style="color: ${o.passed ? 'var(--success)' : 'var(--error)'};">
              ${o.passed ? '✓' : '✗'} Test ${i + 1}: expected "${escapeHtml(o.expected)}", got "${escapeHtml(o.actual)}"
            </p>
          `
        )
        .join('');
    } else {
      resultsEl.innerHTML = `<p style="color: var(--text-tertiary);">This language doesn\u2019t run live yet \u2014 project checks aren\u2019t available for it.</p>`;
      isCorrect = false;
    }

    answered = true;
    onSubmit({ correct: isCorrect });
  };

  submitBtn.addEventListener('click', onSubmitClick);
  container.appendChild(submitBtn);
  container.appendChild(resultsEl);

  return () => {
    submitBtn.removeEventListener('click', onSubmitClick);
    editor.destroy();
    executionManager.destroy();
  };
}

/** @param {string} str @returns {string} */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
