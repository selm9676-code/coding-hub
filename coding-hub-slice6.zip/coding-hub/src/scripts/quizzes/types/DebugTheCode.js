/**
 * DebugTheCode.js
 *
 * Quiz type 6/9 (spec §13). Presents buggy `starterCode`; the learner
 * edits it in a real editor and clicks "Run & Check." Grading actually
 * executes the learner's fixed code via ExecutionManager (reusing the
 * same real Python/JavaScript execution from Slice 4, or the honest
 * simulated path for other languages) and compares its output against
 * `expectedOutput` — this is real verification, not a text diff against
 * a "solution" string, so multiple valid fixes to the same bug all pass.
 *
 * For languages without real execution (C++/Rust/Go in v1.0), this
 * degrades to the same normalized-text comparison CodeCompletion uses
 * against `solution`, since there's no real output to check against —
 * that limitation is surfaced in the explanation text, not hidden.
 *
 * Quiz data shape:
 * { id, type: 'debug', question, starterCode, editorLanguage,
 *   expectedOutput?: string, solution?: string, explanation, hints, xp }
 */
import { Editor } from '../../editor/Editor.js';
import { ExecutionManager } from '../../editor/ExecutionManager.js';

const REAL_EXECUTION_LANGUAGES = new Set(['python', 'javascript']);

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountDebugTheCode(container, quiz, onSubmit) {
  let answered = false;
  const executionManager = new ExecutionManager();

  const editorWrapper = document.createElement('div');
  editorWrapper.style.height = '260px';
  container.appendChild(editorWrapper);

  const editor = new Editor({ code: quiz.starterCode, editorLanguage: quiz.editorLanguage });
  editor.mount(editorWrapper);

  const submitBtn = document.createElement('button');
  submitBtn.className = 'btn btn--primary';
  submitBtn.style.marginTop = 'var(--space-3)';
  submitBtn.textContent = 'Run & Check';

  const statusEl = document.createElement('p');
  statusEl.style.marginTop = 'var(--space-2)';
  statusEl.style.fontSize = 'var(--text-sm)';
  statusEl.style.color = 'var(--text-tertiary)';

  const onSubmitClick = async () => {
    if (answered) return;
    submitBtn.disabled = true;
    statusEl.textContent = 'Running…';

    const code = editor.getCode();
    const usesRealExecution = REAL_EXECUTION_LANGUAGES.has(quiz.editorLanguage);

    let isCorrect;
    if (usesRealExecution) {
      const result = await executionManager.run(quiz.editorLanguage, code);
      isCorrect = result.ok && normalizeOutput(result.output) === normalizeOutput(quiz.expectedOutput ?? '');
      statusEl.textContent = result.ok ? `Output: ${result.output}` : `Error: ${result.error}`;
    } else {
      // No real runtime for this language yet — fall back to comparing
      // against an authored solution string (same limitation as
      // CodeCompletion, surfaced rather than hidden).
      isCorrect = normalizeCode(code) === normalizeCode(quiz.solution ?? '');
      statusEl.textContent = 'This language doesn\u2019t run live yet — checked against the expected fix.';
    }

    answered = true;
    onSubmit({ correct: isCorrect });
  };

  submitBtn.addEventListener('click', onSubmitClick);
  container.appendChild(submitBtn);
  container.appendChild(statusEl);

  return () => {
    submitBtn.removeEventListener('click', onSubmitClick);
    editor.destroy();
    executionManager.destroy();
  };
}

/** @param {string} output @returns {string} */
function normalizeOutput(output) {
  return output.trim();
}

/** @param {string} code @returns {string} */
function normalizeCode(code) {
  return code
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .join('\n');
}
