/**
 * MultipleChoice.js
 *
 * Quiz type 1/9 (spec §13). Options rendered as selectable buttons;
 * selecting one immediately submits (no separate "confirm" step, matching
 * "Instant feedback" from spec §13).
 *
 * Quiz data shape:
 * { id, type: 'multiple-choice', question, options: string[], correct: number, explanation, hints, xp }
 */

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountMultipleChoice(container, quiz, onSubmit) {
  const cleanupFns = [];
  let answered = false;

  const optionsWrapper = document.createElement('div');
  optionsWrapper.style.display = 'flex';
  optionsWrapper.style.flexDirection = 'column';
  optionsWrapper.style.gap = 'var(--space-2)';
  optionsWrapper.setAttribute('role', 'radiogroup');
  optionsWrapper.setAttribute('aria-label', quiz.question);

  quiz.options.forEach((optionText, index) => {
    const button = document.createElement('button');
    button.className = 'btn btn--secondary';
    button.style.justifyContent = 'flex-start';
    button.style.textAlign = 'left';
    button.setAttribute('role', 'radio');
    button.setAttribute('aria-checked', 'false');
    button.textContent = optionText;

    const onClick = () => {
      if (answered) return;
      answered = true;

      const isCorrect = index === quiz.correct;
      button.setAttribute('aria-checked', 'true');

      [...optionsWrapper.children].forEach((child, childIndex) => {
        child.disabled = true;
        if (childIndex === quiz.correct) {
          child.style.borderColor = 'var(--success)';
          child.style.color = 'var(--success)';
        } else if (childIndex === index && !isCorrect) {
          child.style.borderColor = 'var(--error)';
          child.style.color = 'var(--error)';
        }
      });

      onSubmit({ correct: isCorrect });
    };

    button.addEventListener('click', onClick);
    cleanupFns.push(() => button.removeEventListener('click', onClick));
    optionsWrapper.appendChild(button);
  });

  container.appendChild(optionsWrapper);

  return () => {
    for (const fn of cleanupFns) fn();
  };
}
