/**
 * CodeCompletion.js
 *
 * Quiz type 5/9 (spec §13). Shows a code editor pre-filled with a
 * template containing one or more blanks (marked `___` in the starter
 * code); the learner edits directly in the editor and submits. Grading
 * is exact-match against `solution` after trimming and normalizing
 * whitespace — this is a straightforward string comparison, not a code
 * interpreter, so it can't tell "equivalent but differently-formatted"
 * code apart from "wrong." That's a real limitation, not hidden: the
 * explanation text should tell the learner to match the expected
 * formatting if grading feels unfair, and lesson/quiz authors should
 * write prompts that don't have many equally-valid phrasings.
 *
 * Quiz data shape:
 * { id, type: 'code-completion', question, starterCode, solution, editorLanguage, explanation, hints, xp }
 */
import { Editor } from '../../editor/Editor.js';

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountCodeCompletion(container, quiz, onSubmit) {
  let answered = false;

  const editorWrapper = document.createElement('div');
  editorWrapper.style.height = '260px';
  container.appendChild(editorWrapper);

  const editor = new Editor({ code: quiz.starterCode, editorLanguage: quiz.editorLanguage });
  editor.mount(editorWrapper);

  const submitBtn = document.createElement('button');
  submitBtn.className = 'btn btn--primary';
  submitBtn.style.marginTop = 'var(--space-3)';
  submitBtn.textContent = 'Check Answer';

  const onSubmitClick = () => {
    if (answered) return;
    answered = true;
    submitBtn.disabled = true;

    const currentCode = normalize(editor.getCode());
    const expected = normalize(quiz.solution);
    const isCorrect = currentCode === expected;

    onSubmit({ correct: isCorrect });
  };

  submitBtn.addEventListener('click', onSubmitClick);
  container.appendChild(submitBtn);

  return () => {
    submitBtn.removeEventListener('click', onSubmitClick);
    editor.destroy();
  };
}

/**
 * @param {string} code
 * @returns {string}
 */
function normalize(code) {
  return code
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .join('\n');
}
