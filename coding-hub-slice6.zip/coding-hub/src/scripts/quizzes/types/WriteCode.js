/**
 * WriteCode.js
 *
 * Quiz type 8/9 (spec §13). The learner writes code from scratch (empty
 * or near-empty starter code) to satisfy `testCases` — each a
 * { input, expectedOutput } pair for languages with real execution.
 * Runs the learner's code once per test case (simple, direct approach;
 * a large test-case count could be optimized to reuse one Pyodide/worker
 * instance, but the quiz authoring in this project doesn't yet need
 * that scale) and reports which cases passed.
 *
 * For non-executable languages, this falls back to the same
 * solution-string comparison used elsewhere, clearly labeled as such.
 *
 * Quiz data shape:
 * { id, type: 'write-code', question, starterCode, editorLanguage,
 *   testCases?: Array<{ input: string, expectedOutput: string }>,
 *   solution?: string, explanation, hints, xp }
 */
import { Editor } from '../../editor/Editor.js';
import { ExecutionManager } from '../../editor/ExecutionManager.js';

const REAL_EXECUTION_LANGUAGES = new Set(['python', 'javascript']);

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountWriteCode(container, quiz, onSubmit) {
  let answered = false;
  const executionManager = new ExecutionManager();

  const editorWrapper = document.createElement('div');
  editorWrapper.style.height = '280px';
  container.appendChild(editorWrapper);

  const editor = new Editor({ code: quiz.starterCode ?? '', editorLanguage: quiz.editorLanguage });
  editor.mount(editorWrapper);

  const resultsEl = document.createElement('div');
  resultsEl.style.marginTop = 'var(--space-3)';
  resultsEl.style.display = 'flex';
  resultsEl.style.flexDirection = 'column';
  resultsEl.style.gap = 'var(--space-1)';
  resultsEl.style.fontSize = 'var(--text-sm)';

  const submitBtn = document.createElement('button');
  submitBtn.className = 'btn btn--primary';
  submitBtn.style.marginTop = 'var(--space-3)';
  submitBtn.textContent = 'Run Tests';

  const onSubmitClick = async () => {
    if (answered) return;
    submitBtn.disabled = true;
    resultsEl.innerHTML = '<p style="color: var(--text-tertiary);">Running tests…</p>';

    const code = editor.getCode();
    const usesRealExecution = REAL_EXECUTION_LANGUAGES.has(quiz.editorLanguage) && quiz.testCases?.length > 0;

    let isCorrect;
    if (usesRealExecution) {
      const outcomes = await runTestCases(executionManager, quiz.editorLanguage, code, quiz.testCases);
      isCorrect = outcomes.every((o) => o.passed);
      renderTestResults(resultsEl, outcomes);
    } else {
      isCorrect = normalizeCode(code) === normalizeCode(quiz.solution ?? '');
      resultsEl.innerHTML = `<p style="color: var(--text-tertiary);">This language doesn\u2019t run live yet \u2014 checked against the expected solution.</p>`;
    }

    answered = true;
    onSubmit({ correct: isCorrect });
  };

  submitBtn.addEventListener('click', onSubmitClick);
  container.appendChild(submitBtn);
  container.appendChild(resultsEl);

  return () => {
    submitBtn.removeEventListener('click', onSubmitClick);
    editor.destroy();
    executionManager.destroy();
  };
}

/**
 * Runs the learner's code once per test case. Each test case's `input`
 * is prepended as-is before the learner's code (the simplest possible
 * harness: quiz authors write inputs as valid statements/expressions in
 * the target language, e.g. Python `x = 5` or JS `const x = 5;`) so the
 * learner's code can reference variables the test case defines.
 *
 * @param {ExecutionManager} executionManager
 * @param {string} editorLanguage
 * @param {string} code
 * @param {Array<{input: string, expectedOutput: string}>} testCases
 * @returns {Promise<Array<{input: string, expected: string, actual: string, passed: boolean}>>}
 */
async function runTestCases(executionManager, editorLanguage, code, testCases) {
  const outcomes = [];
  for (const testCase of testCases) {
    const fullCode = `${testCase.input}\n${code}`;
    const result = await executionManager.run(editorLanguage, fullCode);
    const actual = result.ok ? result.output.trim() : `Error: ${result.error}`;
    outcomes.push({
      input: testCase.input,
      expected: testCase.expectedOutput.trim(),
      actual,
      passed: result.ok && actual === testCase.expectedOutput.trim(),
    });
  }
  return outcomes;
}

/**
 * @param {HTMLElement} container
 * @param {Array<{input: string, expected: string, actual: string, passed: boolean}>} outcomes
 */
function renderTestResults(container, outcomes) {
  container.innerHTML = outcomes
    .map(
      (o, i) => `
        <p style="color: ${o.passed ? 'var(--success)' : 'var(--error)'};">
          ${o.passed ? '✓' : '✗'} Test ${i + 1}: expected "${escapeHtml(o.expected)}", got "${escapeHtml(o.actual)}"
        </p>
      `
    )
    .join('');
}

/** @param {string} code @returns {string} */
function normalizeCode(code) {
  return code
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .join('\n');
}

/** @param {string} str @returns {string} */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
