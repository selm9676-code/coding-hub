/**
 * TrueFalse.js
 *
 * Quiz type 2/9 (spec §13). A specialization of the two-button case;
 * kept as its own file rather than folded into MultipleChoice because
 * its data shape is simpler (`correct: boolean`, no `options` array) and
 * its accessibility semantics differ slightly (two fixed labels, not an
 * author-provided list) — collapsing them would force one shape to
 * awkwardly represent the other.
 *
 * Quiz data shape:
 * { id, type: 'true-false', question, correct: boolean, explanation, hints, xp }
 */

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountTrueFalse(container, quiz, onSubmit) {
  const cleanupFns = [];
  let answered = false;

  const wrapper = document.createElement('div');
  wrapper.style.display = 'flex';
  wrapper.style.gap = 'var(--space-3)';
  wrapper.setAttribute('role', 'radiogroup');
  wrapper.setAttribute('aria-label', quiz.question);

  [true, false].forEach((value) => {
    const button = document.createElement('button');
    button.className = 'btn btn--secondary';
    button.style.flex = '1';
    button.setAttribute('role', 'radio');
    button.setAttribute('aria-checked', 'false');
    button.textContent = value ? 'True' : 'False';

    const onClick = () => {
      if (answered) return;
      answered = true;

      const isCorrect = value === quiz.correct;
      button.setAttribute('aria-checked', 'true');

      [...wrapper.children].forEach((child, childIndex) => {
        child.disabled = true;
        const childValue = childIndex === 0;
        if (childValue === quiz.correct) {
          child.style.borderColor = 'var(--success)';
          child.style.color = 'var(--success)';
        } else if (childValue === value && !isCorrect) {
          child.style.borderColor = 'var(--error)';
          child.style.color = 'var(--error)';
        }
      });

      onSubmit({ correct: isCorrect });
    };

    button.addEventListener('click', onClick);
    cleanupFns.push(() => button.removeEventListener('click', onClick));
    wrapper.appendChild(button);
  });

  container.appendChild(wrapper);

  return () => {
    for (const fn of cleanupFns) fn();
  };
}
