/**
 * OutputPrediction.js
 *
 * Quiz type 7/9 (spec §13). Shows a read-only code snippet (via
 * highlight.js, matching the lesson reader's own code-block rendering
 * rather than introducing a third styling for "code the user doesn't
 * edit") and asks the learner to predict its output as free text.
 * Grading is an exact string match against `expectedOutput` after
 * trimming — this is intentionally the simplest possible check, since
 * "predict the output" questions are usually authored so there's exactly
 * one correct textual answer (e.g. what does this print), unlike
 * FillBlank's fuzzier acceptedAnswers list.
 *
 * Quiz data shape:
 * { id, type: 'output-prediction', question, code, editorLanguage, expectedOutput, explanation, hints, xp }
 */

let hljsPromise = null;
async function getHighlighter() {
  if (!hljsPromise) {
    hljsPromise = (async () => {
      const mod = await import('highlight.js/lib/core');
      const [python, javascript, cpp, rust, go] = await Promise.all([
        import('highlight.js/lib/languages/python'),
        import('highlight.js/lib/languages/javascript'),
        import('highlight.js/lib/languages/cpp'),
        import('highlight.js/lib/languages/rust'),
        import('highlight.js/lib/languages/go'),
      ]);
      mod.default.registerLanguage('python', python.default);
      mod.default.registerLanguage('javascript', javascript.default);
      mod.default.registerLanguage('cpp', cpp.default);
      mod.default.registerLanguage('rust', rust.default);
      mod.default.registerLanguage('go', go.default);
      return mod.default;
    })();
  }
  return hljsPromise;
}

/**
 * @param {HTMLElement} container
 * @param {Object} quiz
 * @param {(result: { correct: boolean }) => void} onSubmit
 * @returns {() => void} cleanup
 */
export function mountOutputPrediction(container, quiz, onSubmit) {
  let answered = false;

  const pre = document.createElement('pre');
  pre.style.padding = 'var(--space-3)';
  pre.style.background = 'var(--bg-primary)';
  pre.style.border = '1px solid var(--border-subtle)';
  pre.style.borderRadius = 'var(--radius-md)';
  pre.style.overflowX = 'auto';
  pre.setAttribute('role', 'region');
  pre.setAttribute('aria-label', `Code example in ${quiz.editorLanguage}`);

  const codeEl = document.createElement('code');
  codeEl.className = `language-${quiz.editorLanguage}`;
  codeEl.textContent = quiz.code;
  pre.appendChild(codeEl);
  container.appendChild(pre);

  getHighlighter().then((hljs) => {
    try {
      hljs.highlightElement(codeEl);
    } catch {
      // Unregistered language — leave the plain text as-is.
    }
  });

  const form = document.createElement('div');
  form.style.marginTop = 'var(--space-3)';
  form.style.display = 'flex';
  form.style.gap = 'var(--space-2)';

  const input = document.createElement('input');
  input.className = 'input';
  input.placeholder = 'What will this print?';
  input.setAttribute('aria-label', 'Predicted output');

  const submitBtn = document.createElement('button');
  submitBtn.className = 'btn btn--primary';
  submitBtn.textContent = 'Submit';

  const submit = () => {
    if (answered) return;
    answered = true;

    const isCorrect = input.value.trim() === quiz.expectedOutput.trim();
    input.disabled = true;
    submitBtn.disabled = true;
    input.style.borderColor = isCorrect ? 'var(--success)' : 'var(--error)';

    onSubmit({ correct: isCorrect });
  };

  const onSubmitClick = () => submit();
  const onKeyDown = (e) => {
    if (e.key === 'Enter') submit();
  };

  submitBtn.addEventListener('click', onSubmitClick);
  input.addEventListener('keydown', onKeyDown);

  form.appendChild(input);
  form.appendChild(submitBtn);
  container.appendChild(form);

  return () => {
    submitBtn.removeEventListener('click', onSubmitClick);
    input.removeEventListener('keydown', onKeyDown);
  };
}
