/**
 * QuizEngine.js
 *
 * Universal quiz runner (spec §9, §13). Given a quiz definition, mounts
 * the correct type-specific sub-component, then owns everything that's
 * common across all 9 types: recording the attempt in the Store,
 * rendering feedback, progressive hints, the solution-unlock threshold,
 * and XP awards.
 *
 * This is the only file that imports all 9 type modules — type modules
 * never import each other, and nothing outside QuizEngine dispatches on
 * `quiz.type` directly. Adding a 10th quiz type means: write the type
 * module (matching the `mount(container, quiz, onSubmit)` contract),
 * add one line to TYPE_MOUNTERS below. No other file changes.
 */
import { store } from '../store/Store.js';
import { renderFeedback, renderHintControls, renderSolutionUnlock, awardQuizXp } from './Feedback.js';
import { mountMultipleChoice } from './types/MultipleChoice.js';
import { mountTrueFalse } from './types/TrueFalse.js';
import { mountFillBlank } from './types/FillBlank.js';
import { mountDragDrop } from './types/DragDrop.js';
import { mountCodeCompletion } from './types/CodeCompletion.js';
import { mountDebugTheCode } from './types/DebugTheCode.js';
import { mountOutputPrediction } from './types/OutputPrediction.js';
import { mountWriteCode } from './types/WriteCode.js';
import { mountMiniProject } from './types/MiniProject.js';

/** @type {Object.<string, (container: HTMLElement, quiz: Object, onSubmit: (result: {correct: boolean}) => void) => (() => void)>} */
const TYPE_MOUNTERS = {
  'multiple-choice': mountMultipleChoice,
  'true-false': mountTrueFalse,
  'fill-blank': mountFillBlank,
  'drag-drop': mountDragDrop,
  'code-completion': mountCodeCompletion,
  debug: mountDebugTheCode,
  'output-prediction': mountOutputPrediction,
  'write-code': mountWriteCode,
  'mini-project': mountMiniProject,
};

export class QuizEngine {
  /** @type {HTMLElement} */
  el;

  /** @type {() => void} cleanup for the currently-mounted type component */
  #typeCleanup = () => {};

  /** @type {number} failed attempts this session, for the solution-unlock threshold */
  #failedAttempts = 0;

  /** @type {boolean} whether any hint or the solution was used this session */
  #hintsUsed = false;

  /** @type {Object} */
  #quiz;

  /**
   * @param {Object} quiz - Quiz definition (spec §5.3's per-type shapes).
   */
  constructor(quiz) {
    this.#quiz = quiz;
    this.el = document.createElement('div');
    this.el.className = 'card';

    const mounter = TYPE_MOUNTERS[quiz.type];
    if (!mounter) {
      this.#renderUnknownType(quiz.type);
      return;
    }

    this.#renderQuestionHeader();
    this.#mountType(mounter);
  }

  #renderQuestionHeader() {
    const header = document.createElement('div');
    header.style.marginBottom = 'var(--space-4)';
    header.innerHTML = `
      <p style="font-weight: var(--font-semibold);">${escapeHtml(this.#quiz.question)}</p>
    `;
    this.el.appendChild(header);
  }

  /** @param {(container: HTMLElement, quiz: Object, onSubmit: Function) => (() => void)} mounter */
  #mountType(mounter) {
    const typeContainer = document.createElement('div');
    this.el.appendChild(typeContainer);

    const feedbackAndControlsContainer = document.createElement('div');
    this.el.appendChild(feedbackAndControlsContainer);

    const onSubmit = ({ correct }) => {
      this.#handleSubmit(correct, feedbackAndControlsContainer);
    };

    this.#typeCleanup = mounter(typeContainer, this.#quiz, onSubmit);
  }

  /**
   * @param {boolean} correct
   * @param {HTMLElement} feedbackContainer
   */
  #handleSubmit(correct, feedbackContainer) {
    if (!correct) {
      this.#failedAttempts += 1;
    }

    store.dispatch({
      type: 'quiz/recordAttempt',
      payload: { quizId: this.#quiz.id, score: correct ? 100 : 0, hintsUsed: this.#hintsUsed },
    });

    renderFeedback(feedbackContainer, { correct, explanation: this.#quiz.explanation ?? '' });

    if (correct) {
      awardQuizXp(this.#quiz, this.#hintsUsed);
      store.dispatch({
        type: 'ui/pushToast',
        payload: {
          id: `quiz-xp-${Date.now()}`,
          variant: 'success',
          message: `+${this.#hintsUsed ? Math.round(this.#quiz.xp * 0.5) : this.#quiz.xp} XP`,
        },
      });
    } else {
      renderHintControls(feedbackContainer, this.#quiz.hints, () => {
        this.#hintsUsed = true;
      });
      if (this.#quiz.solution || this.#quiz.correctSolutionText) {
        renderSolutionUnlock(
          feedbackContainer,
          this.#failedAttempts,
          this.#quiz.correctSolutionText ?? this.#quiz.solution,
          () => {
            this.#hintsUsed = true;
          }
        );
      }
    }
  }

  /** @param {string} type */
  #renderUnknownType(type) {
    this.el.innerHTML = `
      <p style="color: var(--error);">Unknown quiz type "${escapeHtml(type)}". This quiz can't be displayed.</p>
    `;
  }

  /** @param {HTMLElement} parent */
  mount(parent) {
    parent.appendChild(this.el);
  }

  destroy() {
    this.#typeCleanup();
    this.el.remove();
  }
}

/** @param {string} str @returns {string} */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
