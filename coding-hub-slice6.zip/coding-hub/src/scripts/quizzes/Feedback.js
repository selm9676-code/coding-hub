/**
 * Feedback.js
 *
 * Shared feedback UI for every quiz type (spec §13): instant
 * correct/incorrect state with animation, progressive hint reveal,
 * a solution unlock after 2 failed attempts, and XP award dispatch.
 * Quiz type components (MultipleChoice.js, FillBlank.js, etc.) call
 * into this rather than each re-implementing feedback rendering, so the
 * "instant feedback: green pulse + explanation panel slide-in" behavior
 * in spec §13 is visually identical across all 9 types.
 */
import { store } from '../store/Store.js';

/**
 * @param {HTMLElement} container - Element to render feedback into (appended, not replacing existing content).
 * @param {Object} options
 * @param {boolean} options.correct
 * @param {string} options.explanation
 * @param {string[]} [options.hints] - Progressive hints; only shown via `renderHintControls`.
 */
export function renderFeedback(container, { correct, explanation }) {
  const panel = document.createElement('div');
  panel.className = `card ${correct ? 'pulse-on-success' : 'shake-on-error'}`;
  panel.style.marginTop = 'var(--space-4)';
  panel.style.borderLeft = `4px solid ${correct ? 'var(--success)' : 'var(--error)'}`;
  panel.setAttribute('role', 'status');
  panel.setAttribute('aria-live', 'polite');

  panel.innerHTML = `
    <p style="font-weight: var(--font-semibold); color: ${correct ? 'var(--success)' : 'var(--error)'};">
      ${correct ? '✓ Correct!' : '✗ Not quite.'}
    </p>
    <p style="color: var(--text-secondary); margin-top: var(--space-2); font-size: var(--text-sm);">
      ${escapeHtml(explanation)}
    </p>
  `;

  container.appendChild(panel);
  return panel;
}

/**
 * Renders progressive hint reveal controls (spec §13: "First hint
 * subtle, second hint explicit"). Each click reveals the next hint;
 * calling `onHintUsed` marks the attempt as hint-assisted (affects XP,
 * per spec §13's XP system: "Bonus for no hints").
 *
 * @param {HTMLElement} container
 * @param {string[]} hints
 * @param {() => void} onHintUsed - Called the first time any hint is revealed.
 * @returns {() => void} cleanup
 */
export function renderHintControls(container, hints, onHintUsed) {
  if (!hints || hints.length === 0) return () => {};

  let revealedCount = 0;
  let hintUsedFired = false;

  const wrapper = document.createElement('div');
  wrapper.style.marginTop = 'var(--space-3)';

  const hintList = document.createElement('div');
  hintList.style.display = 'flex';
  hintList.style.flexDirection = 'column';
  hintList.style.gap = 'var(--space-2)';

  const button = document.createElement('button');
  button.className = 'btn btn--ghost';
  button.style.fontSize = 'var(--text-xs)';
  button.textContent = `💡 Show a hint (${hints.length} available)`;

  const onClick = () => {
    if (revealedCount >= hints.length) return;
    if (!hintUsedFired) {
      hintUsedFired = true;
      onHintUsed();
    }
    const hintEl = document.createElement('p');
    hintEl.className = 'pill';
    hintEl.style.display = 'block';
    hintEl.style.width = 'fit-content';
    hintEl.textContent = hints[revealedCount];
    hintList.appendChild(hintEl);
    revealedCount += 1;

    if (revealedCount >= hints.length) {
      button.disabled = true;
      button.textContent = 'No more hints';
    } else {
      button.textContent = `💡 Show another hint (${hints.length - revealedCount} left)`;
    }
  };

  button.addEventListener('click', onClick);
  wrapper.appendChild(hintList);
  wrapper.appendChild(button);
  container.appendChild(wrapper);

  return () => button.removeEventListener('click', onClick);
}

/**
 * Renders a "Show solution" button that only appears after the
 * threshold of failed attempts (spec §13: "Unlock after 2 failed
 * attempts"). Using the solution is recorded as a hint-equivalent for
 * XP purposes — the spec groups both under "affects XP" without
 * distinguishing them further, so this reuses the same `hintsUsed` flag
 * rather than introducing a separate one the store schema doesn't have.
 *
 * @param {HTMLElement} container
 * @param {number} failedAttempts
 * @param {string} solutionText
 * @param {() => void} onSolutionRevealed
 */
export function renderSolutionUnlock(container, failedAttempts, solutionText, onSolutionRevealed) {
  if (failedAttempts < 2) return;

  const button = document.createElement('button');
  button.className = 'btn btn--secondary';
  button.style.marginTop = 'var(--space-3)';
  button.textContent = 'Show solution';

  button.addEventListener(
    'click',
    () => {
      onSolutionRevealed();
      const solutionEl = document.createElement('pre');
      solutionEl.style.marginTop = 'var(--space-3)';
      solutionEl.style.padding = 'var(--space-3)';
      solutionEl.style.background = 'var(--bg-elevated)';
      solutionEl.style.borderRadius = 'var(--radius-md)';
      solutionEl.style.overflowX = 'auto';
      solutionEl.innerHTML = `<code>${escapeHtml(solutionText)}</code>`;
      button.replaceWith(solutionEl);
    },
    { once: true }
  );

  container.appendChild(button);
}

/**
 * Awards XP for a quiz attempt (spec §13, §15): base XP from the quiz
 * definition, no bonus if hints were used. Speed bonus is explicitly
 * marked optional in the spec and is not implemented in this slice —
 * not faked with an arbitrary bonus amount.
 *
 * @param {Object} quiz - Quiz definition with at least { id, xp }.
 * @param {boolean} hintsUsed
 */
export function awardQuizXp(quiz, hintsUsed) {
  const amount = hintsUsed ? Math.round(quiz.xp * 0.5) : quiz.xp;
  store.dispatch({ type: 'xp/award', payload: { source: `quiz:${quiz.id}`, amount } });
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
