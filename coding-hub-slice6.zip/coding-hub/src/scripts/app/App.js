/**
 * App.js
 *
 * Root layout controller. Owns the persistent shell chrome (header,
 * sidebar, bottom nav) and mounts/unmounts the active route's view inside
 * `#main-content`. Individual views are responsible for their own DOM;
 * App.js's job ends at "call the view's default export with a container
 * and a route match, then clean up the previous view when the route
 * changes."
 */
import { store } from '../store/Store.js';

const NAV_ITEMS = [
  { path: '/home', label: 'Home', icon: 'home' },
  { path: '/search', label: 'Search', icon: 'search' },
  { path: '/bookmarks', label: 'Bookmarks', icon: 'bookmark' },
  { path: '/progress', label: 'Progress', icon: 'chart' },
];

export class App {
  /** @type {HTMLElement} */
  #mainContent;

  /** @type {HTMLElement} */
  #bottomNav;

  /** @type {(() => void)|null} cleanup for the currently mounted view */
  #currentViewCleanup = null;

  constructor() {
    this.#mainContent = document.getElementById('main-content');
    this.#bottomNav = document.getElementById('bottom-nav');
  }

  /** Renders the persistent chrome. Called once during boot. */
  renderShell() {
    this.#renderBottomNav(window.location.hash.replace(/^#/, '') || '/home');
  }

  #renderBottomNav(currentPath) {
    this.#bottomNav.innerHTML = '';
    for (const item of NAV_ITEMS) {
      const link = document.createElement('a');
      link.href = `#${item.path}`;
      link.className = 'bottom-nav__item';
      link.textContent = item.label;
      if (currentPath === item.path) {
        link.setAttribute('aria-current', 'page');
      }
      this.#bottomNav.appendChild(link);
    }
  }

  /**
   * Called by the Router whenever navigation resolves. Unmounts the
   * previous view (if it returned a cleanup function), shows a 404 view
   * for unmatched routes, and mounts the new one.
   *
   * @param {import('../router/Router.js').RouteMatch|null} match
   * @param {string} path
   */
  async onRouteChange(match, path) {
    if (this.#currentViewCleanup) {
      this.#currentViewCleanup();
      this.#currentViewCleanup = null;
    }

    this.#mainContent.classList.add('page-leaving');

    if (!match) {
      this.#renderNotFound(path);
      this.#renderBottomNav(path);
      return;
    }

    this.#renderSkeleton();

    try {
      const mod = await match.route.load();
      this.#mainContent.innerHTML = '';
      this.#mainContent.classList.remove('page-leaving');
      this.#mainContent.classList.add('page-entering');
      const cleanup = mod.default(this.#mainContent, match);
      if (typeof cleanup === 'function') {
        this.#currentViewCleanup = cleanup;
      }
      // Return focus to the main region for screen reader / keyboard users
      // following the new-page-content convention (spec §19).
      this.#mainContent.focus();
    } catch (err) {
      // Route module failed to load or render (spec §23, invalid lesson
      // data / missing language JSON both funnel through here).
      console.error(`Failed to load route "${match.route.name}":`, err);
      this.#renderLoadError();
    }

    this.#renderBottomNav(path);
  }

  #renderSkeleton() {
    this.#mainContent.innerHTML = `
      <div class="skeleton" style="height: 240px; border-radius: var(--radius-lg);"></div>
    `;
  }

  #renderNotFound(path) {
    this.#mainContent.innerHTML = `
      <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
        <h1>Page not found</h1>
        <p style="color: var(--text-secondary); margin-top: var(--space-3);">
          We couldn't find "${path}".
        </p>
        <a href="#/home" class="btn btn--primary" style="margin-top: var(--space-6); display:inline-flex;">
          Back to Home
        </a>
      </div>
    `;
  }

  #renderLoadError() {
    this.#mainContent.innerHTML = `
      <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
        <h1>Something went wrong</h1>
        <p style="color: var(--text-secondary); margin-top: var(--space-3);">
          This page couldn't be loaded. Please retry or go back to Home.
        </p>
        <div style="display:flex; gap: var(--space-3); justify-content:center; margin-top: var(--space-6);">
          <button class="btn btn--secondary" onclick="window.location.reload()">Retry</button>
          <a href="#/home" class="btn btn--primary">Back to Home</a>
        </div>
      </div>
    `;
  }
}
