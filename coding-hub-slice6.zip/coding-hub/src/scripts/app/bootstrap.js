/**
 * bootstrap.js
 *
 * Boot sequence run once from main.js:
 *  1. Feature-detect IndexedDB; pick the active StorageProvider.
 *  2. Run migrate() on the chosen provider.
 *  3. Hydrate the Store from persisted data (or defaults if none exists).
 *  4. Wire a persistence subscriber so future state changes are saved
 *     automatically, without any view code calling storage directly.
 *
 * This is the ONE place that decides which StorageProvider backs the
 * app for this session (spec §6: "If IndexedDB fails, fall back to
 * LocalStorageProvider with size warnings"). Everything downstream only
 * ever sees the StorageProvider interface.
 *
 * CORRECTED IN SLICE 6: earlier slices' comments claimed progress and
 * quiz results were "persisted by their own feature modules calling
 * storageProvider.set() directly" — that was never actually implemented
 * anywhere (LessonView.js and QuizEngine.js only ever dispatched to the
 * Store, never touched a StorageProvider). The practical effect: every
 * lesson completion, quiz attempt, XP award beyond the first hydration,
 * bookmark, and note was living only in memory and vanishing on reload.
 * Fixed here by having `wirePersistence()` diff every per-record slice
 * (progress, quiz, bookmarks, notes, achievements) against its previous
 * state on every dispatch and write only the records that actually
 * changed — no feature module needs to know a StorageProvider exists.
 */
import { store } from '../store/Store.js';
import { progressReducer, PROGRESS_INITIAL_STATE } from '../store/slices/progressSlice.js';
import { quizReducer, QUIZ_INITIAL_STATE } from '../store/slices/quizSlice.js';
import { uiReducer, UI_INITIAL_STATE } from '../store/slices/uiSlice.js';
import { settingsReducer, SETTINGS_INITIAL_STATE } from '../store/slices/settingsSlice.js';
import { xpReducer, XP_INITIAL_STATE } from '../store/slices/xpSlice.js';
import { bookmarksReducer, BOOKMARKS_INITIAL_STATE } from '../store/slices/bookmarksSlice.js';
import { notesReducer, NOTES_INITIAL_STATE } from '../store/slices/notesSlice.js';
import { achievementsReducer, ACHIEVEMENTS_INITIAL_STATE } from '../store/slices/achievementsSlice.js';
import { IndexedDBProvider } from '../storage/IndexedDBProvider.js';
import { LocalStorageProvider } from '../storage/LocalStorageProvider.js';
import { selectLevelFromXp } from '../store/selectors.js';
import { computeCurrentStreak } from '../progress/StreakTracker.js';
import { checkForNewUnlocks } from '../progress/AchievementEngine.js';

const SETTINGS_KEY = 'settings';
const XP_KEY = 'xp';

/**
 * @returns {Promise<import('../storage/StorageProvider.js').StorageProvider>}
 */
async function initStorageProvider() {
  if (!('indexedDB' in window)) {
    return new LocalStorageProvider();
  }

  const idbProvider = new IndexedDBProvider();
  try {
    await idbProvider.migrate();
    return idbProvider;
  } catch (err) {
    console.warn('IndexedDB unavailable, falling back to localStorage:', err);
    return new LocalStorageProvider();
  }
}

function registerSlices() {
  store.registerSlice('progress', progressReducer, PROGRESS_INITIAL_STATE);
  store.registerSlice('quiz', quizReducer, QUIZ_INITIAL_STATE);
  store.registerSlice('ui', uiReducer, UI_INITIAL_STATE);
  store.registerSlice('settings', settingsReducer, SETTINGS_INITIAL_STATE);
  store.registerSlice('xp', xpReducer, XP_INITIAL_STATE);
  store.registerSlice('bookmarks', bookmarksReducer, BOOKMARKS_INITIAL_STATE);
  store.registerSlice('notes', notesReducer, NOTES_INITIAL_STATE);
  store.registerSlice('achievements', achievementsReducer, ACHIEVEMENTS_INITIAL_STATE);
}

/**
 * @param {import('../storage/StorageProvider.js').StorageProvider} storageProvider
 */
async function hydrateStore(storageProvider) {
  const persistedSettings = await storageProvider.get('settings', SETTINGS_KEY);
  if (persistedSettings) {
    store.hydrateSlice('settings', { ...SETTINGS_INITIAL_STATE, ...persistedSettings });
  }

  const persistedXp = await storageProvider.get('xp', XP_KEY);
  if (persistedXp) {
    store.hydrateSlice('xp', persistedXp);
  }

  const progressRecords = await storageProvider.getAll('progress');
  if (progressRecords.length > 0) {
    const byLessonId = {};
    for (const record of progressRecords) {
      byLessonId[record.lessonId] = record;
    }
    store.hydrateSlice('progress', { ...PROGRESS_INITIAL_STATE, byLessonId });
  }

  const quizRecords = await storageProvider.getAll('quizResults');
  if (quizRecords.length > 0) {
    const byQuizId = {};
    for (const record of quizRecords) {
      byQuizId[record.quizId] = record;
    }
    store.hydrateSlice('quiz', { byQuizId });
  }

  const bookmarkRecords = await storageProvider.getAll('bookmarks');
  if (bookmarkRecords.length > 0) {
    const byId = {};
    for (const record of bookmarkRecords) {
      byId[record.id] = record;
    }
    store.hydrateSlice('bookmarks', { byId });
  }

  const noteRecords = await storageProvider.getAll('notes');
  if (noteRecords.length > 0) {
    const byId = {};
    for (const record of noteRecords) {
      byId[record.id] = record;
    }
    store.hydrateSlice('notes', { byId });
  }

  const achievementRecords = await storageProvider.getAll('achievements');
  if (achievementRecords.length > 0) {
    const unlockedById = {};
    for (const record of achievementRecords) {
      unlockedById[record.id] = record;
    }
    store.hydrateSlice('achievements', { unlockedById });
  }
}

/**
 * Diffs a per-record slice's `byId`/`byLessonId`/`byQuizId`/`unlockedById`
 * map between two states and persists only the records that changed —
 * new records and updated records are written; removed records are
 * deleted. This is the shared mechanism behind persisting progress,
 * quiz, bookmarks, notes, and achievements, all of which share the same
 * "map keyed by record id" shape even though the key name differs.
 *
 * @param {import('../storage/StorageProvider.js').StorageProvider} storageProvider
 * @param {string} storeName - IndexedDB object store name.
 * @param {Object.<string, Object>} prevMap
 * @param {Object.<string, Object>} nextMap
 */
function persistRecordMapDiff(storageProvider, storeName, prevMap, nextMap) {
  if (prevMap === nextMap) return;

  for (const [key, record] of Object.entries(nextMap)) {
    if (prevMap[key] !== record) {
      storageProvider.set(storeName, key, record);
    }
  }
  for (const key of Object.keys(prevMap)) {
    if (!(key in nextMap)) {
      storageProvider.delete(storeName, key);
    }
  }
}

/**
 * Subscribes to the Store so every slice is persisted automatically
 * after every dispatch that changes it — settings/xp as a single blob
 * each, and progress/quiz/bookmarks/notes/achievements as diffed
 * per-record maps (see `persistRecordMapDiff`). No feature module needs
 * to know a StorageProvider exists; dispatching an action is enough.
 *
 * @param {import('../storage/StorageProvider.js').StorageProvider} storageProvider
 */
function wirePersistence(storageProvider) {
  store.subscribe((state, prevState) => {
    if (state.settings !== prevState.settings) {
      storageProvider.set('settings', SETTINGS_KEY, { key: SETTINGS_KEY, ...state.settings });
    }
    if (state.xp !== prevState.xp) {
      storageProvider.set('xp', XP_KEY, { key: XP_KEY, ...state.xp });
    }
    if (state.progress !== prevState.progress) {
      persistRecordMapDiff(storageProvider, 'progress', prevState.progress.byLessonId, state.progress.byLessonId);
    }
    if (state.quiz !== prevState.quiz) {
      persistRecordMapDiff(storageProvider, 'quizResults', prevState.quiz.byQuizId, state.quiz.byQuizId);
    }
    if (state.bookmarks !== prevState.bookmarks) {
      persistRecordMapDiff(storageProvider, 'bookmarks', prevState.bookmarks.byId, state.bookmarks.byId);
    }
    if (state.notes !== prevState.notes) {
      persistRecordMapDiff(storageProvider, 'notes', prevState.notes.byId, state.notes.byId);
    }
    if (state.achievements !== prevState.achievements) {
      persistRecordMapDiff(
        storageProvider,
        'achievements',
        prevState.achievements.unlockedById,
        state.achievements.unlockedById
      );
    }
  });
}

/**
 * Checks for newly-eligible achievements after every dispatch and
 * unlocks them (spec §15). Runs after `wirePersistence` in `bootstrap()`
 * so an achievement unlocked here still gets persisted by the same
 * subscription mechanism — dispatch order within one Store.dispatch call
 * doesn't matter since `achievements/unlock` is itself just another
 * dispatch that both subscribers observe.
 */
function wireAchievementUnlocks() {
  store.subscribe((state) => {
    const { level } = selectLevelFromXp(state.xp.total);
    const streak = computeCurrentStreak(state.xp.history);
    const newlyEligible = checkForNewUnlocks(state, streak, level);

    for (const achievementId of newlyEligible) {
      store.dispatch({ type: 'achievements/unlock', payload: { id: achievementId } });
      store.dispatch({
        type: 'ui/pushToast',
        payload: {
          id: `achievement-${achievementId}-${Date.now()}`,
          variant: 'success',
          message: `🏆 Achievement unlocked!`,
        },
      });
    }
  });
}

/**
 * Injects the inline SVG icon sprite sheet once, so <use href="#icon-x">
 * references throughout the app resolve without a network request per
 * icon (spec §3, §8.6).
 */
async function loadIconSprite() {
  const root = document.getElementById('icon-sprite-root');
  try {
    const response = await fetch('./icons/sprite.svg');
    if (response.ok) {
      root.innerHTML = await response.text();
    }
  } catch (err) {
    // Non-fatal: icons degrade to missing <use> targets, layout unaffected.
    console.warn('Icon sprite failed to load:', err);
  }
}

/**
 * @returns {Promise<import('../storage/StorageProvider.js').StorageProvider>}
 */
export async function bootstrap() {
  registerSlices();

  const storageProvider = await initStorageProvider();
  await hydrateStore(storageProvider);
  wirePersistence(storageProvider);
  wireAchievementUnlocks();

  // Non-blocking: shell can render before the sprite arrives.
  loadIconSprite();

  return storageProvider;
}
