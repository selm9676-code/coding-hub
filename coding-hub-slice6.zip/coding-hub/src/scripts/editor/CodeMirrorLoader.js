/**
 * CodeMirrorLoader.js
 *
 * Dynamic-import + configuration entry point for CodeMirror 6 (spec §11's
 * "Monaco ESM loaded dynamically" requirement, adapted to our actual
 * editor per the confirmed CodeMirror 6 decision — see
 * ARCHITECTURE.md). Keeping this import boundary in one file means
 * `Editor.js` never imports `codemirror` directly; it always goes
 * through `loadCodeMirror()`, which is the single place that knows which
 * language packages exist and how to fall back gracefully if any of them
 * fail to load (spec §23: "Monaco load failure → fallback to plain
 * <textarea>").
 */

/** @type {Promise<Object>|null} cached core CodeMirror modules */
let corePromise = null;

/**
 * @returns {Promise<{EditorState, EditorView, basicSetup: import('@codemirror/state').Extension[], keymap, indentWithTab}>}
 */
async function loadCore() {
  if (!corePromise) {
    corePromise = (async () => {
      const [{ EditorState }, viewMod, { defaultKeymap, history, historyKeymap, indentWithTab }, { bracketMatching, indentOnInput, syntaxHighlighting } , searchMod, autocompleteMod] =
        await Promise.all([
          import('@codemirror/state'),
          import('@codemirror/view'),
          import('@codemirror/commands'),
          import('@codemirror/language'),
          import('@codemirror/search'),
          import('@codemirror/autocomplete'),
        ]);

      const { EditorView, lineNumbers, highlightActiveLine, highlightActiveLineGutter, keymap } = viewMod;
      const { searchKeymap, highlightSelectionMatches } = searchMod;
      const { closeBrackets, closeBracketsKeymap, autocompletion, completionKeymap } = autocompleteMod;

      const basicSetup = [
        lineNumbers(),
        highlightActiveLine(),
        highlightActiveLineGutter(),
        history(),
        bracketMatching(),
        closeBrackets(),
        autocompletion(),
        highlightSelectionMatches(),
        indentOnInput(),
        keymap.of([
          ...closeBracketsKeymap,
          ...defaultKeymap,
          ...searchKeymap,
          ...historyKeymap,
          ...completionKeymap,
          indentWithTab,
        ]),
      ];

      return { EditorState, EditorView, basicSetup, keymap };
    })();
  }
  return corePromise;
}

/** @type {Map<string, Promise<import('@codemirror/state').Extension>>} */
const languageExtensionCache = new Map();

/**
 * Maps this project's `editorLanguage` values (from languages.json,
 * spec §5.1) to CodeMirror language-package loaders. Only languages with
 * a real CodeMirror package are listed; anything else falls back to no
 * language extension (still fully functional as a plain text editor —
 * spec §12 only requires real code execution for Python/JavaScript in
 * v1.0, so C++/Rust/Go get syntax highlighting via these same packages
 * even though their execution is simulated).
 *
 * @type {Object.<string, () => Promise<import('@codemirror/state').Extension>>}
 */
const LANGUAGE_LOADERS = {
  python: async () => (await import('@codemirror/lang-python')).python(),
  javascript: async () => (await import('@codemirror/lang-javascript')).javascript(),
  cpp: async () => (await import('@codemirror/lang-cpp')).cpp(),
  rust: async () => (await import('@codemirror/lang-rust')).rust(),
  go: async () => {
    // No official @codemirror/lang-go package as of this project's
    // dependency set; Go source still edits fine without a dedicated
    // grammar (spec §23-style graceful degradation — no language
    // extension is not a broken editor, just an editor without
    // Go-specific indentation/highlighting rules).
    return [];
  },
};

/**
 * @param {string} editorLanguage - e.g. 'python', 'javascript', 'cpp'.
 * @returns {Promise<import('@codemirror/state').Extension|import('@codemirror/state').Extension[]>}
 */
function loadLanguageExtension(editorLanguage) {
  if (!languageExtensionCache.has(editorLanguage)) {
    const loader = LANGUAGE_LOADERS[editorLanguage];
    const promise = loader ? loader() : Promise.resolve([]);
    languageExtensionCache.set(editorLanguage, promise);
  }
  return languageExtensionCache.get(editorLanguage);
}

/**
 * @param {string} editorLanguage
 * @returns {Promise<{EditorState, EditorView, extensions: import('@codemirror/state').Extension[]}>}
 *   Everything needed to construct an EditorState for this language.
 */
export async function loadCodeMirror(editorLanguage) {
  const [{ EditorState, EditorView, basicSetup }, languageExtension, { codingHubTheme }] = await Promise.all([
    loadCore(),
    loadLanguageExtension(editorLanguage),
    import('./themes/codingHubTheme.js'),
  ]);

  return {
    EditorState,
    EditorView,
    extensions: [...basicSetup, ...codingHubTheme(), languageExtension].flat(),
  };
}
