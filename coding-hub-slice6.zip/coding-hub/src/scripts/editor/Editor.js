/**
 * Editor.js
 *
 * The editor component referenced throughout the spec (§9's component
 * list, §11's toolbar requirements). Wraps CodeMirror 6 (see
 * ARCHITECTURE.md for why this is CodeMirror and not Monaco) with the
 * chrome spec §11 calls for: a toolbar (Run, Reset, Copy, Fullscreen —
 * Format/Download are noted as not-yet-implemented rather than faked),
 * and a status bar.
 *
 * Failure handling (spec §23, "Monaco load failure → fallback to plain
 * <textarea>"): if CodeMirror's dynamic import rejects for any reason,
 * this falls back to a plain `<textarea>` so the learner can still type
 * and run code — degraded, but never a dead component.
 */
import { loadCodeMirror } from './CodeMirrorLoader.js';
import { ExecutionManager } from './ExecutionManager.js';
import { store } from '../store/Store.js';

export class Editor {
  /** @type {HTMLElement} */
  el;

  /** @type {ExecutionManager} */
  #executionManager;

  /** @type {import('@codemirror/view').EditorView|null} */
  #cmView = null;

  /** @type {HTMLTextAreaElement|null} fallback if CodeMirror fails to load */
  #fallbackTextarea = null;

  /** @type {string} the original starter code, for Reset */
  #initialCode;

  /** @type {string} */
  #editorLanguage;

  /** @type {HTMLElement} */
  #surfaceEl;

  /** @type {HTMLElement} */
  #outputEl;

  /** @type {HTMLElement} */
  #statusEl;

  /** @type {HTMLButtonElement} */
  #runBtn;

  /** @type {boolean} */
  #isRunning = false;

  /** @type {(e: KeyboardEvent) => void} */
  #onKeyDown;

  /**
   * @param {Object} options
   * @param {string} options.code - Initial/starter code.
   * @param {string} options.editorLanguage - e.g. 'python', 'javascript', 'cpp'.
   */
  constructor({ code, editorLanguage }) {
    this.#initialCode = code;
    this.#editorLanguage = editorLanguage;
    this.#executionManager = new ExecutionManager();

    this.el = document.createElement('div');
    this.el.className = 'editor';

    const toolbar = document.createElement('div');
    toolbar.className = 'editor__toolbar';
    toolbar.innerHTML = `
      <div class="editor__toolbar-group">
        <button class="btn btn--primary" data-action="run" style="min-height:36px; padding: var(--space-2) var(--space-4);">
          ▶ Run
        </button>
        <button class="btn btn--ghost" data-action="reset" style="min-height:36px;">Reset</button>
        <button class="btn btn--ghost" data-action="copy" style="min-height:36px;">Copy</button>
      </div>
      <div class="editor__toolbar-group">
        <button class="btn btn--icon" data-action="fullscreen" aria-label="Toggle fullscreen" style="width:36px; height:36px; min-height:36px;">⛶</button>
      </div>
    `;

    this.#surfaceEl = document.createElement('div');
    this.#surfaceEl.className = 'editor__surface';

    this.#outputEl = document.createElement('div');
    this.#outputEl.setAttribute('role', 'status');
    this.#outputEl.setAttribute('aria-live', 'polite');
    this.#outputEl.style.padding = 'var(--space-3)';
    this.#outputEl.style.borderTop = '1px solid var(--border-subtle)';
    this.#outputEl.style.background = 'var(--bg-surface)';
    this.#outputEl.style.fontFamily = 'var(--font-mono)';
    this.#outputEl.style.fontSize = 'var(--text-sm)';
    this.#outputEl.style.maxHeight = '160px';
    this.#outputEl.style.overflowY = 'auto';
    this.#outputEl.style.whiteSpace = 'pre-wrap';
    this.#outputEl.style.display = 'none';

    this.#statusEl = document.createElement('div');
    this.#statusEl.className = 'editor__status-bar';
    this.#statusEl.innerHTML = `<span data-status-lang></span><span data-status-state>Ready</span>`;

    this.el.appendChild(toolbar);
    this.el.appendChild(this.#surfaceEl);
    this.el.appendChild(this.#outputEl);
    this.el.appendChild(this.#statusEl);

    this.#statusEl.querySelector('[data-status-lang]').textContent = editorLanguage;

    this.#runBtn = toolbar.querySelector('[data-action="run"]');
    toolbar.querySelector('[data-action="reset"]').addEventListener('click', () => this.#reset());
    toolbar.querySelector('[data-action="copy"]').addEventListener('click', () => this.#copy());
    toolbar.querySelector('[data-action="fullscreen"]').addEventListener('click', () => this.#toggleFullscreen());
    this.#runBtn.addEventListener('click', () => this.#run());

    this.#initCodeMirror(code, editorLanguage);
    this.#wireGlobalRunShortcut();
  }

  /**
   * @param {string} code
   * @param {string} editorLanguage
   */
  async #initCodeMirror(code, editorLanguage) {
    try {
      const { EditorState, EditorView, extensions } = await loadCodeMirror(editorLanguage);
      this.#cmView = new EditorView({
        state: EditorState.create({ doc: code, extensions }),
        parent: this.#surfaceEl,
      });
    } catch (err) {
      console.warn('CodeMirror failed to load, falling back to plain textarea:', err);
      this.#mountFallbackTextarea(code);
    }
  }

  /** @param {string} code */
  #mountFallbackTextarea(code) {
    this.#fallbackTextarea = document.createElement('textarea');
    this.#fallbackTextarea.className = 'editor__fallback-textarea';
    this.#fallbackTextarea.value = code;
    this.#fallbackTextarea.spellcheck = false;
    this.#surfaceEl.appendChild(this.#fallbackTextarea);
  }

  #getCurrentCode() {
    if (this.#cmView) return this.#cmView.state.doc.toString();
    if (this.#fallbackTextarea) return this.#fallbackTextarea.value;
    return '';
  }

  /** @param {string} code */
  #setCurrentCode(code) {
    if (this.#cmView) {
      this.#cmView.dispatch({
        changes: { from: 0, to: this.#cmView.state.doc.length, insert: code },
      });
    } else if (this.#fallbackTextarea) {
      this.#fallbackTextarea.value = code;
    }
  }

  /**
   * Public read accessor for the editor's current content. Added for
   * external consumers (e.g. quiz types in Slice 5's CodeCompletion.js,
   * MiniProject.js) that need to grade the learner's code without
   * duplicating CodeMirror/fallback-textarea branching themselves.
   * @returns {string}
   */
  getCode() {
    return this.#getCurrentCode();
  }

  /**
   * Public write accessor, mirroring `getCode()`. Distinct from the
   * internal Reset button's behavior: Reset always restores
   * `#initialCode`, whereas `setCode()` lets a caller set arbitrary
   * content (e.g. restoring a previous quiz attempt's saved code).
   * @param {string} code
   */
  setCode(code) {
    this.#setCurrentCode(code);
  }

  async #run() {
    if (this.#isRunning) return;
    this.#isRunning = true;
    this.#runBtn.disabled = true;
    this.#setStatus('Running…');
    this.#outputEl.style.display = 'block';
    this.#outputEl.textContent = '';
    this.#outputEl.classList.remove('shake-on-error', 'pulse-on-success');

    const code = this.#getCurrentCode();
    const result = await this.#executionManager.run(this.#editorLanguage, code);

    this.#isRunning = false;
    this.#runBtn.disabled = false;

    if (result.ok) {
      this.#outputEl.textContent = result.output;
      this.#outputEl.style.color = 'var(--text-primary)';
      this.#outputEl.classList.add('pulse-on-success');
      this.#setStatus(result.simulated ? 'Simulated' : 'Success');
    } else {
      this.#outputEl.textContent = result.error;
      this.#outputEl.style.color = 'var(--error)';
      this.#outputEl.classList.add('shake-on-error');
      this.#setStatus('Error');
      // Toast on failure per spec §23 ("Failed code execution → Toast
      // with error message. Worker auto-restarts." — the restart itself
      // happens inside ExecutionManager on the next run() call).
      store.dispatch({
        type: 'ui/pushToast',
        payload: { id: `exec-error-${Date.now()}`, variant: 'error', message: 'Code execution failed. See details below the editor.' },
      });
    }
  }

  #reset() {
    this.#setCurrentCode(this.#initialCode);
    this.#outputEl.style.display = 'none';
    this.#setStatus('Ready');
  }

  #copy() {
    const code = this.#getCurrentCode();
    navigator.clipboard?.writeText(code).then(() => {
      this.#setStatus('Copied!');
      setTimeout(() => this.#setStatus('Ready'), 1500);
    });
  }

  #toggleFullscreen() {
    const current = store.getState().ui.editorFullscreen;
    store.dispatch({ type: 'ui/setEditorFullscreen', payload: { value: !current } });
  }

  /** @param {string} text */
  #setStatus(text) {
    this.#statusEl.querySelector('[data-status-state]').textContent = text;
  }

  /**
   * Ctrl/Cmd+Enter runs code (spec §20), scoped to while this editor's
   * surface (or its children, i.e. the CodeMirror content) has focus —
   * so multiple editors on a page (unlikely in v1.0, but not
   * impossible) don't all run at once from one keypress.
   */
  #wireGlobalRunShortcut() {
    this.#onKeyDown = (e) => {
      const isRunShortcut = (e.ctrlKey || e.metaKey) && e.key === 'Enter';
      if (!isRunShortcut) return;
      if (!this.el.contains(document.activeElement)) return;
      e.preventDefault();
      this.#run();
    };
    window.addEventListener('keydown', this.#onKeyDown);
  }

  /** @param {HTMLElement} parent */
  mount(parent) {
    parent.appendChild(this.el);
  }

  destroy() {
    window.removeEventListener('keydown', this.#onKeyDown);
    this.#cmView?.destroy();
    this.#executionManager.destroy();
    this.el.remove();
  }
}
