/**
 * codingHubTheme.js
 *
 * A CodeMirror 6 theme (`EditorView.theme()`) plus syntax highlighting
 * style (`HighlightStyle`), built from this project's design tokens
 * rather than hardcoded hex values, so the editor visually matches the
 * rest of the app (spec §8.6's "Custom dark theme matching the design
 * system", §3's technology table).
 *
 * Note: CodeMirror's `theme()` API takes a plain JS style object, not
 * CSS custom properties directly — `var(--x)` strings do resolve inside
 * browser-computed styles, so we can still reference the token names as
 * literal strings here and let the browser resolve them at paint time.
 * This keeps the theme in sync with _tokens.css without duplicating the
 * actual color values.
 */
import { EditorView } from '@codemirror/view';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { tags as t } from '@lezer/highlight';

export const codingHubEditorTheme = EditorView.theme(
  {
    '&': {
      color: 'var(--text-primary)',
      backgroundColor: 'var(--bg-primary)',
      height: '100%',
    },
    '.cm-content': {
      caretColor: 'var(--accent-cyan)',
      fontFamily: 'var(--font-mono)',
      padding: 'var(--space-3) 0',
    },
    '.cm-scroller': {
      overflow: 'auto',
      fontFamily: 'var(--font-mono)',
      lineHeight: 'var(--leading-relaxed)',
    },
    '&.cm-focused .cm-cursor': {
      borderLeftColor: 'var(--accent-cyan)',
    },
    '&.cm-focused .cm-selectionBackground, .cm-selectionBackground': {
      backgroundColor: 'var(--accent-blue-glow) !important',
    },
    '.cm-gutters': {
      backgroundColor: 'var(--bg-primary)',
      color: 'var(--text-tertiary)',
      border: 'none',
      borderRight: '1px solid var(--border-subtle)',
    },
    '.cm-activeLine': {
      backgroundColor: 'var(--bg-surface)',
    },
    '.cm-activeLineGutter': {
      backgroundColor: 'var(--bg-surface)',
    },
    '.cm-matchingBracket': {
      backgroundColor: 'var(--accent-cyan-glow)',
      outline: '1px solid var(--accent-cyan)',
    },
    '.cm-tooltip': {
      backgroundColor: 'var(--bg-elevated)',
      border: '1px solid var(--border-medium)',
      borderRadius: 'var(--radius-md)',
      color: 'var(--text-primary)',
    },
    '.cm-tooltip-autocomplete ul li[aria-selected]': {
      backgroundColor: 'var(--accent-cyan-glow)',
      color: 'var(--text-primary)',
    },
  },
  { dark: true }
);

/**
 * Syntax color mapping. Uses the same accent palette as the rest of the
 * app rather than introducing editor-specific colors, so a lesson's
 * embedded static code (highlight.js, see LessonRenderer.js) and the
 * live editor look like one consistent system.
 */
export const codingHubHighlightStyle = HighlightStyle.define([
  { tag: t.keyword, color: 'var(--accent-blue)' },
  { tag: [t.name, t.deleted, t.character, t.macroName], color: 'var(--text-primary)' },
  { tag: [t.function(t.variableName), t.labelName], color: 'var(--accent-cyan)' },
  { tag: [t.color, t.constant(t.name), t.standard(t.name)], color: 'var(--warning)' },
  { tag: [t.definition(t.name), t.separator], color: 'var(--text-primary)' },
  { tag: [t.typeName, t.className, t.number, t.changed, t.annotation, t.modifier, t.self, t.namespace], color: 'var(--warning)' },
  { tag: [t.operator, t.operatorKeyword], color: 'var(--accent-blue)' },
  { tag: [t.url, t.escape, t.regexp, t.link], color: 'var(--success)' },
  { tag: [t.meta, t.comment], color: 'var(--text-tertiary)', fontStyle: 'italic' },
  { tag: t.strong, fontWeight: 'var(--font-bold)' },
  { tag: t.emphasis, fontStyle: 'italic' },
  { tag: t.string, color: 'var(--success)' },
  { tag: t.invalid, color: 'var(--error)' },
]);

/**
 * @returns {import('@codemirror/state').Extension[]} Both pieces
 *   combined, ready to spread into an EditorState's extensions array.
 */
export function codingHubTheme() {
  return [codingHubEditorTheme, syntaxHighlighting(codingHubHighlightStyle)];
}
