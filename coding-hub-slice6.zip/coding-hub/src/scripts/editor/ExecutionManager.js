/**
 * ExecutionManager.js
 *
 * Orchestrates running user code in a dedicated Web Worker per spec §12:
 *  - All execution happens off the main thread. Never block the UI.
 *  - 5-second timeout: if a worker doesn't respond in time, terminate it
 *    (infinite-loop protection).
 *  - On any failure (timeout, worker error, uncaught exception inside
 *    the worker), the worker is terminated and a fresh one is spun up
 *    for the next run — a crashed/hung worker never silently keeps
 *    handling future runs.
 *  - Only Python and JavaScript execute real user code in v1.0. C++/
 *    Rust/Go get "simulated output" (spec §12) — this manager exposes a
 *    single `run()` entry point and dispatches internally based on
 *    language, so callers (Editor.js) don't need to know which languages
 *    are "real" vs "simulated."
 */

const TIMEOUT_MS = 5000;

/**
 * @typedef {Object} ExecutionResult
 * @property {boolean} ok
 * @property {string} output - stdout/print output, or the simulated explanation text.
 * @property {string} [error] - Present when ok is false.
 * @property {boolean} [simulated] - True for languages that don't execute real code in v1.0.
 */

export class ExecutionManager {
  /** @type {Worker|null} */
  #pythonWorker = null;

  /** @type {Worker|null} */
  #javascriptWorker = null;

  /** @type {number} counter to correlate requests with responses across worker restarts */
  #requestId = 0;

  /**
   * Runs code for the given language and resolves with its output.
   * Never rejects — failures come back as `{ ok: false, error }` so
   * callers always have a single result shape to render (spec §23:
   * "Failed code execution → Toast with error message. Worker
   * auto-restarts.").
   *
   * @param {string} editorLanguage - e.g. 'python', 'javascript', 'cpp'.
   * @param {string} code
   * @returns {Promise<ExecutionResult>}
   */
  async run(editorLanguage, code) {
    if (editorLanguage === 'python') {
      return this.#runInWorker('python', code);
    }
    if (editorLanguage === 'javascript') {
      return this.#runInWorker('javascript', code);
    }
    return this.#runSimulated(editorLanguage, code);
  }

  /**
   * @param {'python'|'javascript'} lang
   * @param {string} code
   * @returns {Promise<ExecutionResult>}
   */
  async #runInWorker(lang, code) {
    const worker = await this.#getOrCreateWorker(lang);
    const requestId = ++this.#requestId;

    return new Promise((resolve) => {
      let settled = false;

      const timeoutHandle = setTimeout(() => {
        if (settled) return;
        settled = true;
        this.#terminateWorker(lang); // infinite-loop protection (spec §12)
        resolve({ ok: false, error: 'Execution timed out after 5 seconds. Check for infinite loops.' });
      }, TIMEOUT_MS);

      const onMessage = (event) => {
        const msg = event.data;
        if (msg.requestId !== requestId) return; // stale response from a prior run
        settled = true;
        clearTimeout(timeoutHandle);
        worker.removeEventListener('message', onMessage);

        if (msg.type === 'result') {
          resolve({ ok: true, output: msg.output });
        } else if (msg.type === 'error') {
          resolve({ ok: false, error: msg.error });
        }
      };

      const onError = (event) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutHandle);
        worker.removeEventListener('message', onMessage);
        this.#terminateWorker(lang);
        resolve({ ok: false, error: event.message || 'The code execution worker crashed unexpectedly.' });
      };

      worker.addEventListener('message', onMessage);
      worker.addEventListener('error', onError, { once: true });
      worker.postMessage({ type: 'run', requestId, code });
    });
  }

  /**
   * @param {'python'|'javascript'} lang
   * @returns {Promise<Worker>}
   */
  async #getOrCreateWorker(lang) {
    const existing = lang === 'python' ? this.#pythonWorker : this.#javascriptWorker;
    if (existing) return existing;

    const worker =
      lang === 'python'
        ? new Worker(new URL('./workers/pythonWorker.js', import.meta.url), { type: 'module' })
        : new Worker(new URL('./workers/javascriptWorker.js', import.meta.url), { type: 'module' });

    if (lang === 'python') this.#pythonWorker = worker;
    else this.#javascriptWorker = worker;

    return worker;
  }

  /** @param {'python'|'javascript'} lang */
  #terminateWorker(lang) {
    const worker = lang === 'python' ? this.#pythonWorker : this.#javascriptWorker;
    worker?.terminate();
    if (lang === 'python') this.#pythonWorker = null;
    else this.#javascriptWorker = null;
  }

  /**
   * C++/Rust/Go (and any other language without a v1.0 execution runtime)
   * per spec §12: validate syntax at a basic level and show an
   * educational "simulated output" explanation rather than pretending to
   * compile and run the code. This is explicitly NOT a fake success
   * message — it tells the learner plainly that this is a walkthrough,
   * not a real run.
   *
   * @param {string} editorLanguage
   * @param {string} code
   * @returns {Promise<ExecutionResult>}
   */
  async #runSimulated(editorLanguage, code) {
    const languageLabel = { cpp: 'C++', rust: 'Rust', go: 'Go' }[editorLanguage] ?? editorLanguage;
    const trimmed = code.trim();

    if (!trimmed) {
      return { ok: false, error: 'Write some code first.', simulated: true };
    }

    return {
      ok: true,
      simulated: true,
      output:
        `${languageLabel} doesn't compile live in the browser yet — this is a walkthrough, ` +
        `not a real run. Compare your code against the lesson's expected solution to check ` +
        `your work, and re-read the lesson explanation for what this code should produce.`,
    };
  }

  /** Terminates any running workers. Call when navigating away from an editor. */
  destroy() {
    this.#pythonWorker?.terminate();
    this.#javascriptWorker?.terminate();
    this.#pythonWorker = null;
    this.#javascriptWorker = null;
  }
}
