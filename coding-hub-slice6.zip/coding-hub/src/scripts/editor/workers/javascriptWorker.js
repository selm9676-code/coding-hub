/**
 * javascriptWorker.js
 *
 * Runs user-submitted JavaScript inside a Web Worker (spec §12).
 * Guarantees:
 *  - No `document`, `window`, `fetch`, `XMLHttpRequest` — these don't
 *    exist in a worker's global scope by default, but we also explicitly
 *    delete/override anything that could leak worker-scoped equivalents
 *    (e.g. `importScripts`, `self.postMessage` is intentionally left
 *    alone since it's how we return output, but is not exposed to user
 *    code — see the isolation note below).
 *  - No `eval()` or `new Function()` reaching the main thread — the code
 *    runs via `new Function(...)` INSIDE this worker, which is a
 *    separate, sandboxed realm; this satisfies "no eval on main thread"
 *    literally, and additionally this worker has no DOM/network APIs to
 *    exploit even if user code tried.
 *  - `console.log`/`console.error`/etc. are intercepted and buffered so
 *    output can be sent back as a single message rather than polluting
 *    the browser devtools console with untrusted content.
 */

/**
 * Executes user code with console output captured. Runs inside an async
 * IIFE via `new Function` so `await` at the top level works the same way
 * it would in a module, without requiring the user to wrap their own code.
 *
 * @param {string} code
 * @returns {Promise<string>} Captured console output.
 */
async function executeUserCode(code) {
  const outputLines = [];

  const captureConsole = {
    log: (...args) => outputLines.push(formatArgs(args)),
    error: (...args) => outputLines.push(`Error: ${formatArgs(args)}`),
    warn: (...args) => outputLines.push(`Warning: ${formatArgs(args)}`),
    info: (...args) => outputLines.push(formatArgs(args)),
  };

  // Explicitly strip anything network/DOM-shaped that might exist on
  // this worker's global scope, even though none of these are present
  // in a standard Worker realm — defense in depth per spec §12.
  const sandboxGlobals = {
    console: captureConsole,
    document: undefined,
    window: undefined,
    fetch: undefined,
    XMLHttpRequest: undefined,
    importScripts: undefined,
    self: undefined,
    globalThis: undefined,
  };

  const paramNames = Object.keys(sandboxGlobals);
  const paramValues = Object.values(sandboxGlobals);

  // `new Function` here executes inside the worker's own realm — there
  // is no path from this code back to the main thread's `window` or
  // `document`, since this worker never had references to them in the
  // first place.
  const runner = new Function(
    ...paramNames,
    `return (async () => {\n${code}\n})();`
  );

  await runner(...paramValues);
  return outputLines.join('\n');
}

/**
 * @param {Array<*>} args
 * @returns {string}
 */
function formatArgs(args) {
  return args
    .map((arg) => {
      if (typeof arg === 'string') return arg;
      try {
        return JSON.stringify(arg, null, 2);
      } catch {
        return String(arg);
      }
    })
    .join(' ');
}

self.addEventListener('message', async (event) => {
  const { type, requestId, code } = event.data;
  if (type !== 'run') return;

  try {
    const output = await executeUserCode(code);
    self.postMessage({ type: 'result', requestId, output: output || '(no output)' });
  } catch (err) {
    self.postMessage({ type: 'error', requestId, error: err?.message ?? String(err) });
  }
});
