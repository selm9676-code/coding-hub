/**
 * pythonWorker.js
 *
 * Runs user-submitted Python inside a Web Worker using Pyodide (spec
 * §3, §12: "Python | Pyodide (WASM) | Dedicated worker with 5s timeout").
 * Pyodide itself is loaded lazily on the first `run` message, not at
 * worker startup, so creating the worker is cheap and the (fairly large)
 * Pyodide WASM payload only downloads when a learner actually executes
 * Python code — consistent with the lazy-loaded-WASM-runtime requirement
 * in spec §21's performance budget table.
 *
 * IMPORTANT TRADEOFF, flagged rather than silently shipped: this loads
 * Pyodide from jsdelivr's CDN via `importScripts()` at runtime. That is
 * an external network dependency the moment someone runs Python — it
 * will NOT work fully offline on a first visit to a given lesson, which
 * is in tension with spec §17's offline-support goals and the "pure
 * static files" principle in §2. The alternative — vendoring the ~10MB+
 * Pyodide distribution into this repo's `public/` folder and serving it
 * from the same origin — keeps the app truly self-contained and lets the
 * service worker cache it for offline use, at the cost of repo size and
 * a manual version-bump process instead of always tracking Pyodide's
 * latest CDN release. This file uses the CDN approach for now because
 * it's the standard/documented Pyodide integration path; switching to a
 * vendored copy is a deliberate call this project should make explicitly
 * rather than default into — see ARCHITECTURE.md for a fuller writeup.
 *
 * Output capture: Pyodide's `runPythonAsync` doesn't return `print()`
 * output directly, so stdout is redirected to a JS callback via
 * `pyodide.setStdout({ batched: ... })`, buffered, and returned as a
 * single string alongside the expression result (if any).
 */

/** @type {Promise<Object>|null} */
let pyodidePromise = null;

/**
 * @returns {Promise<Object>} The initialized Pyodide instance.
 */
async function getPyodide() {
  if (!pyodidePromise) {
    pyodidePromise = (async () => {
      // Loaded from the CDN build Pyodide publishes for exactly this
      // use case (a WASM runtime meant to be fetched at runtime, not
      // bundled) — this keeps the app's own JS bundle free of Pyodide's
      // multi-megabyte payload per spec §21.
      importScripts('https://cdn.jsdelivr.net/pyodide/v0.26.1/full/pyodide.js');
      // eslint-disable-next-line no-undef
      const pyodide = await loadPyodide();
      return pyodide;
    })();
  }
  return pyodidePromise;
}

/**
 * @param {string} code
 * @returns {Promise<string>} Captured stdout output.
 */
async function executeUserCode(code) {
  const pyodide = await getPyodide();
  const outputLines = [];

  pyodide.setStdout({
    batched: (text) => outputLines.push(text),
  });
  pyodide.setStderr({
    batched: (text) => outputLines.push(text),
  });

  await pyodide.runPythonAsync(code);
  return outputLines.join('\n');
}

self.addEventListener('message', async (event) => {
  const { type, requestId, code } = event.data;
  if (type !== 'run') return;

  try {
    const output = await executeUserCode(code);
    self.postMessage({ type: 'result', requestId, output: output || '(no output)' });
  } catch (err) {
    // Pyodide surfaces Python tracebacks as the error message/toString,
    // which is exactly what a learner needs to see to debug their code.
    self.postMessage({ type: 'error', requestId, error: err?.message ?? String(err) });
  }
});
