/**
 * sanitize.js
 *
 * Single chokepoint for turning untrusted/rendered HTML strings into safe
 * DOM-insertable HTML. Spec §22 forbids raw `innerHTML` with unsanitized
 * strings anywhere in the app — every call site that needs to insert HTML
 * (lesson content, notes, imported data rendered as text) must route
 * through `sanitizeHtml()` first.
 *
 * DOMPurify is imported dynamically so it only loads on routes that
 * actually render HTML (lesson pages, notes), keeping it out of the
 * initial bundle per the performance budget in spec §21.
 */

let purifyInstance = null;

async function getPurify() {
  if (!purifyInstance) {
    const mod = await import('dompurify');
    purifyInstance = mod.default;
  }
  return purifyInstance;
}

/**
 * @param {string} dirtyHtml
 * @param {Object} [options] - Passed through to DOMPurify.sanitize config.
 * @returns {Promise<string>} Sanitized HTML safe to assign to innerHTML.
 */
export async function sanitizeHtml(dirtyHtml, options = {}) {
  const DOMPurify = await getPurify();
  return DOMPurify.sanitize(dirtyHtml, {
    ALLOWED_TAGS: [
      'p', 'br', 'strong', 'em', 'b', 'i', 'u', 's', 'code', 'pre',
      'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'ul', 'ol', 'li', 'blockquote', 'a', 'img', 'table', 'thead',
      'tbody', 'tr', 'th', 'td', 'span', 'div', 'hr',
    ],
    ALLOWED_ATTR: ['href', 'src', 'alt', 'title', 'class', 'id', 'target', 'rel'],
    ...options,
  });
}
