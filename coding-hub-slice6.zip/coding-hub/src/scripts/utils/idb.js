/**
 * idb.js
 *
 * Minimal Promise wrapper around the raw IndexedDB API. Deliberately not a
 * full-featured library (no cursors abstraction, no query builder) — just
 * enough to support get/getAll/put/delete/clear against a single database
 * with several object stores, which is all IndexedDBProvider needs.
 */

/**
 * @param {IDBRequest} request
 * @returns {Promise<*>}
 */
export function promisifyRequest(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * @param {IDBTransaction} tx
 * @returns {Promise<void>}
 */
export function promisifyTransaction(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
  });
}

/**
 * Open (or create/upgrade) a database.
 *
 * @param {string} name
 * @param {number} version
 * @param {(db: IDBDatabase, oldVersion: number, newVersion: number|null, tx: IDBTransaction) => void} onUpgrade
 * @returns {Promise<IDBDatabase>}
 */
export function openDatabase(name, version, onUpgrade) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(name, version);

    request.onupgradeneeded = (event) => {
      const db = request.result;
      onUpgrade(db, event.oldVersion, event.newVersion, request.transaction);
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    request.onblocked = () => {
      // Another tab holds an older-version connection open. We surface
      // this as a normal rejection; the caller (IndexedDBProvider) falls
      // back to LocalStorageProvider per spec §6/§23.
      reject(new Error('IndexedDB upgrade blocked by another open tab/connection.'));
    };
  });
}

/**
 * @param {IDBDatabase} db
 * @param {string} storeName
 * @param {IDBTransactionMode} mode
 * @returns {IDBObjectStore}
 */
export function getStore(db, storeName, mode = 'readonly') {
  const tx = db.transaction(storeName, mode);
  return { store: tx.objectStore(storeName), tx };
}
