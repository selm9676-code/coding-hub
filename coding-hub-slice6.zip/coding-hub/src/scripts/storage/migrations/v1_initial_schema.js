/**
 * v1_initial_schema.js
 *
 * Creates the initial IndexedDB object stores (spec §6). This runs inside
 * the `upgradeneeded` handler, so it only executes once per browser
 * profile (or again if DB_VERSION is bumped and a later migration needs
 * to run alongside it — each migration file should be additive and
 * idempotent-safe via `if (!db.objectStoreNames.contains(...))` guards).
 */

export const SCHEMA_VERSION = 1;

/**
 * @param {IDBDatabase} db
 */
export function applyV1Schema(db) {
  if (!db.objectStoreNames.contains('progress')) {
    db.createObjectStore('progress', { keyPath: 'lessonId' });
  }

  if (!db.objectStoreNames.contains('quizResults')) {
    db.createObjectStore('quizResults', { keyPath: 'quizId' });
  }

  if (!db.objectStoreNames.contains('bookmarks')) {
    const bookmarksStore = db.createObjectStore('bookmarks', { keyPath: 'id' });
    bookmarksStore.createIndex('byType', 'type', { unique: false });
  }

  if (!db.objectStoreNames.contains('notes')) {
    const notesStore = db.createObjectStore('notes', { keyPath: 'id' });
    notesStore.createIndex('byLessonId', 'lessonId', { unique: false });
  }

  if (!db.objectStoreNames.contains('settings')) {
    // Single-row store; always accessed with key 'settings'.
    db.createObjectStore('settings', { keyPath: 'key' });
  }

  if (!db.objectStoreNames.contains('xp')) {
    // Single-row store; always accessed with key 'xp'.
    db.createObjectStore('xp', { keyPath: 'key' });
  }

  if (!db.objectStoreNames.contains('achievements')) {
    db.createObjectStore('achievements', { keyPath: 'id' });
  }
}
