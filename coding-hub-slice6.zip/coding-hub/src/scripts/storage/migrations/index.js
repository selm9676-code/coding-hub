/**
 * migrations/index.js
 *
 * Ordered migration registry. IndexedDBProvider's `onUpgrade` handler
 * walks this list and applies every migration whose version is greater
 * than `oldVersion`, in order. Adding a new migration means: bump
 * CURRENT_DB_VERSION, add a new `vN_*.js` file, and append it here —
 * never edit a past migration once it has shipped.
 */
import { SCHEMA_VERSION, applyV1Schema } from './v1_initial_schema.js';

export const CURRENT_DB_VERSION = SCHEMA_VERSION;

/** @type {Array<{ version: number, apply: (db: IDBDatabase, oldVersion: number, tx: IDBTransaction) => void }>} */
export const MIGRATIONS = [{ version: 1, apply: (db) => applyV1Schema(db) }];

/**
 * @param {IDBDatabase} db
 * @param {number} oldVersion
 * @param {IDBTransaction} tx
 */
export function runMigrations(db, oldVersion, tx) {
  for (const migration of MIGRATIONS) {
    if (migration.version > oldVersion) {
      migration.apply(db, oldVersion, tx);
    }
  }
}
