/**
 * LocalStorageProvider.js
 *
 * Fallback StorageProvider for browsers/contexts where IndexedDB is
 * unavailable or fails to open (private browsing modes, corrupted
 * profiles, very old browsers). Also used directly for lightweight
 * settings access before IndexedDB has finished opening.
 *
 * Data is namespaced under a single top-level key per store to avoid
 * polluting localStorage with one entry per record, and to keep the
 * quota footprint predictable. Because localStorage has a much smaller
 * quota than IndexedDB (typically 5-10MB), this provider warns via a
 * dispatched toast (spec §6) when writes push close to that ceiling —
 * wiring for that warning lives in bootstrap.js, which owns toast
 * dispatch; this class only reports the sizes it observes.
 */
import { StorageProvider } from './StorageProvider.js';

const NAMESPACE = 'coding-hub:v1:';
const SCHEMA_VERSION = 1;

export class LocalStorageProvider extends StorageProvider {
  #keyFor(storeName) {
    return `${NAMESPACE}${storeName}`;
  }

  #readStore(storeName) {
    const raw = localStorage.getItem(this.#keyFor(storeName));
    if (!raw) return {};
    try {
      return JSON.parse(raw);
    } catch {
      // Corrupted entry for this store only — treat as empty rather than
      // failing the whole app (spec §23, corrupted local storage).
      return {};
    }
  }

  #writeStore(storeName, storeObject) {
    localStorage.setItem(this.#keyFor(storeName), JSON.stringify(storeObject));
  }

  async migrate() {
    // localStorage has no versioned upgrade mechanism of its own; the
    // schema version is embedded in export()/import() payloads instead.
    return Promise.resolve();
  }

  async get(storeName, key) {
    const storeObject = this.#readStore(storeName);
    return storeObject[key];
  }

  async getAll(storeName) {
    const storeObject = this.#readStore(storeName);
    return Object.values(storeObject);
  }

  async set(storeName, key, value) {
    const storeObject = this.#readStore(storeName);
    storeObject[key] = value;
    this.#writeStore(storeName, storeObject);
  }

  async delete(storeName, key) {
    const storeObject = this.#readStore(storeName);
    delete storeObject[key];
    this.#writeStore(storeName, storeObject);
  }

  async export() {
    const storeNames = ['progress', 'quizResults', 'bookmarks', 'notes', 'settings', 'xp', 'achievements'];
    const stores = {};
    for (const name of storeNames) {
      stores[name] = this.#readStore(name);
    }
    return {
      schemaVersion: SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      stores,
    };
  }

  async import(data) {
    if (!data || typeof data !== 'object' || typeof data.schemaVersion !== 'number') {
      throw new Error('Import failed: missing or invalid schema version header.');
    }
    if (data.schemaVersion > SCHEMA_VERSION) {
      throw new Error(
        `Import failed: file was exported from a newer version (v${data.schemaVersion}) than this app supports (v${SCHEMA_VERSION}).`
      );
    }
    if (!data.stores || typeof data.stores !== 'object') {
      throw new Error('Import failed: no data found in file.');
    }
    for (const [storeName, storeObject] of Object.entries(data.stores)) {
      this.#writeStore(storeName, storeObject);
    }
  }
}
