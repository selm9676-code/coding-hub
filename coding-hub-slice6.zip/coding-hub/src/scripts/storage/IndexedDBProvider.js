/**
 * IndexedDBProvider.js
 *
 * Primary StorageProvider backend (spec §6). Wraps IndexedDB v2+ behind
 * the StorageProvider interface. All object stores are created/upgraded
 * via the migrations registry (migrations/index.js) so schema evolution
 * is explicit and ordered.
 *
 * Failure handling: if `open()` rejects for any reason (quota, blocked
 * upgrade, disabled storage in private browsing), the caller
 * (bootstrap.js) is expected to fall back to LocalStorageProvider and
 * surface a toast — this class does not silently degrade itself, since
 * bootstrap.js is the layer that owns which provider becomes "the"
 * active StorageProvider.
 */
import { StorageProvider } from './StorageProvider.js';
import { openDatabase, promisifyRequest, promisifyTransaction } from '../utils/idb.js';
import { CURRENT_DB_VERSION, runMigrations } from './migrations/index.js';

const DB_NAME = 'coding-hub';
const SCHEMA_VERSION_HEADER = 1; // export payload version, independent of IDB version
const ALL_STORES = ['progress', 'quizResults', 'bookmarks', 'notes', 'settings', 'xp', 'achievements'];

export class IndexedDBProvider extends StorageProvider {
  /** @type {IDBDatabase|null} */
  #db = null;

  /**
   * Opens the database and applies any pending migrations. Must be
   * awaited before any other method is called; bootstrap.js is
   * responsible for this ordering.
   * @returns {Promise<void>}
   */
  async migrate() {
    this.#db = await openDatabase(DB_NAME, CURRENT_DB_VERSION, (db, oldVersion, newVersion, tx) => {
      runMigrations(db, oldVersion, tx);
    });
  }

  #requireDb() {
    if (!this.#db) {
      throw new Error('IndexedDBProvider: migrate() must complete before use.');
    }
    return this.#db;
  }

  async get(storeName, key) {
    const db = this.#requireDb();
    const tx = db.transaction(storeName, 'readonly');
    const result = await promisifyRequest(tx.objectStore(storeName).get(key));
    return result;
  }

  async getAll(storeName) {
    const db = this.#requireDb();
    const tx = db.transaction(storeName, 'readonly');
    const result = await promisifyRequest(tx.objectStore(storeName).getAll());
    return result ?? [];
  }

  async set(storeName, key, value) {
    const db = this.#requireDb();
    const tx = db.transaction(storeName, 'readwrite');
    // Object stores are keyPath-based (see migrations), so `value` must
    // already carry the key field; `key` is accepted for interface
    // symmetry with LocalStorageProvider and to allow a future
    // out-of-line-key store without changing call sites.
    tx.objectStore(storeName).put(value);
    await promisifyTransaction(tx);
  }

  async delete(storeName, key) {
    const db = this.#requireDb();
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(key);
    await promisifyTransaction(tx);
  }

  async export() {
    const stores = {};
    for (const name of ALL_STORES) {
      stores[name] = await this.getAll(name);
    }
    return {
      schemaVersion: SCHEMA_VERSION_HEADER,
      exportedAt: new Date().toISOString(),
      stores,
    };
  }

  async import(data) {
    if (!data || typeof data !== 'object' || typeof data.schemaVersion !== 'number') {
      throw new Error('Import failed: missing or invalid schema version header.');
    }
    if (data.schemaVersion > SCHEMA_VERSION_HEADER) {
      throw new Error(
        `Import failed: file was exported from a newer version (v${data.schemaVersion}) than this app supports (v${SCHEMA_VERSION_HEADER}).`
      );
    }
    if (!data.stores || typeof data.stores !== 'object') {
      throw new Error('Import failed: no data found in file.');
    }

    const db = this.#requireDb();
    for (const [storeName, records] of Object.entries(data.stores)) {
      if (!ALL_STORES.includes(storeName)) continue;
      if (!Array.isArray(records)) continue;

      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.clear();
      for (const record of records) {
        store.put(record);
      }
      await promisifyTransaction(tx);
    }
  }
}
