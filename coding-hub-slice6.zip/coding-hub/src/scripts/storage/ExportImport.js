/**
 * ExportImport.js
 *
 * Thin user-facing wrapper around StorageProvider.export()/import().
 * Handles the "download a file" / "read an uploaded file" mechanics so
 * neither the Settings view nor the StorageProvider implementations need
 * to know about Blob/File APIs.
 */

/**
 * Triggers a browser download of the current storage state as JSON.
 * @param {import('./StorageProvider.js').StorageProvider} storageProvider
 * @returns {Promise<void>}
 */
export async function downloadExport(storageProvider) {
  const data = await storageProvider.export();
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = `coding-hub-export-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

/**
 * Reads a File object (from an <input type="file"> or drop event),
 * validates it's parseable JSON, and hands it to the storage provider's
 * import(). Throws with a user-friendly message on any failure so the
 * caller can show it directly in a toast (spec §23, invalid import file).
 *
 * @param {import('./StorageProvider.js').StorageProvider} storageProvider
 * @param {File} file
 * @returns {Promise<void>}
 */
export async function importFromFile(storageProvider, file) {
  let text;
  try {
    text = await file.text();
  } catch {
    throw new Error('Could not read the selected file.');
  }

  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('That file is not valid JSON. Please select a Coding Hub export file.');
  }

  // storageProvider.import() performs the schema-version and shape checks;
  // we just let its errors (already user-friendly) propagate.
  await storageProvider.import(data);
}
