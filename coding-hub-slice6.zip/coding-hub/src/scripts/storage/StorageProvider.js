/**
 * StorageProvider.js
 *
 * Abstract interface every storage backend must implement. The rest of
 * the app (Store persistence subscriber, ExportImport, feature modules)
 * depends only on this interface — never on IndexedDBProvider or
 * LocalStorageProvider directly. This is what makes future cloud sync
 * (spec §28) a drop-in replacement: swap which class satisfies this
 * interface, and the Store/UI layers don't change.
 *
 * All methods are async and must resolve/reject; they must never throw
 * synchronously so callers can uniformly `await` + `try/catch`.
 *
 * v2.0+ methods (sync, getLeaderboard, postComment, getUserProfile) are
 * declared here with stub implementations that resolve
 * `{ status: 'offline', data: null }` per spec §28. Concrete v1.0
 * providers inherit these stubs unless they override them.
 */

export class StorageProvider {
  /**
   * Retrieve a single record by store name and key.
   * @param {string} storeName - e.g. 'progress', 'settings'.
   * @param {string} key
   * @returns {Promise<*|undefined>}
   */
  async get(storeName, key) {
    throw new Error(`StorageProvider.get() not implemented for store "${storeName}"`);
  }

  /**
   * Retrieve all records in a store.
   * @param {string} storeName
   * @returns {Promise<Array<*>>}
   */
  async getAll(storeName) {
    throw new Error(`StorageProvider.getAll() not implemented for store "${storeName}"`);
  }

  /**
   * Write (create or overwrite) a record.
   * @param {string} storeName
   * @param {string} key
   * @param {*} value
   * @returns {Promise<void>}
   */
  async set(storeName, key, value) {
    throw new Error(`StorageProvider.set() not implemented for store "${storeName}"`);
  }

  /**
   * Delete a record.
   * @param {string} storeName
   * @param {string} key
   * @returns {Promise<void>}
   */
  async delete(storeName, key) {
    throw new Error(`StorageProvider.delete() not implemented for store "${storeName}"`);
  }

  /**
   * Serialize all persisted data to a portable JSON structure.
   * @returns {Promise<Object>} Includes a schema version header (spec §6).
   */
  async export() {
    throw new Error('StorageProvider.export() not implemented');
  }

  /**
   * Restore from a previously exported JSON structure. Implementations
   * must validate the schema version header and reject corrupted data
   * with a user-friendly error rather than partially applying it.
   * @param {Object} data
   * @returns {Promise<void>}
   */
  async import(data) {
    throw new Error('StorageProvider.import() not implemented');
  }

  /**
   * Run any pending schema migrations. Called once during app boot before
   * any other method is used.
   * @returns {Promise<void>}
   */
  async migrate() {
    throw new Error('StorageProvider.migrate() not implemented');
  }

  // ---------------------------------------------------------------------
  // v2.0+ contract (spec §28). Concrete v1.0 providers get these for free;
  // override in a future cloud-backed provider without touching the UI.
  // ---------------------------------------------------------------------

  /** @returns {Promise<{status: string, data: null}>} */
  async sync() {
    return { status: 'offline', data: null };
  }

  /**
   * @param {string} languageId
   * @returns {Promise<{status: string, data: null}>}
   */
  async getLeaderboard(languageId) {
    return { status: 'offline', data: null };
  }

  /**
   * @param {string} lessonId
   * @param {string} text
   * @returns {Promise<{status: string, data: null}>}
   */
  async postComment(lessonId, text) {
    return { status: 'offline', data: null };
  }

  /** @returns {Promise<{status: string, data: null}>} */
  async getUserProfile() {
    return { status: 'offline', data: null };
  }
}
