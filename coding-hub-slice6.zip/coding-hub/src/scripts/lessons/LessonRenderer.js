/**
 * LessonRenderer.js
 *
 * Renders a compiled lesson's HTML body into the DOM. Two responsibilities
 * that must never be skipped, per spec §22:
 *
 *  1. Sanitize before insertion — lesson HTML is build-time content (we
 *     authored it), but it still passes through `sanitizeHtml()` for
 *     defense in depth and consistency with the notes/imported-content
 *     code paths that DO handle untrusted input. There is exactly one
 *     chokepoint for "HTML goes into the DOM" in this app; lessons don't
 *     get a bypass just because we trust the source today.
 *  2. Apply syntax highlighting to code blocks via highlight.js, imported
 *     dynamically so it never loads on routes that don't render lesson
 *     content (spec §21 performance budget).
 *
 * This module does NOT know about lesson layout (split view vs stacked,
 * sticky breadcrumbs) — that's LessonLayout.js. It only turns compiled
 * JSON into a DOM subtree.
 */
import { sanitizeHtml } from '../utils/sanitize.js';

let hljsInstance = null;

async function getHighlighter() {
  if (!hljsInstance) {
    const mod = await import('highlight.js/lib/core');
    // Register only the languages this project actually teaches, rather
    // than the full highlight.js bundle, to keep this lazy chunk small.
    const [python, javascript, cpp, rust, go] = await Promise.all([
      import('highlight.js/lib/languages/python'),
      import('highlight.js/lib/languages/javascript'),
      import('highlight.js/lib/languages/cpp'),
      import('highlight.js/lib/languages/rust'),
      import('highlight.js/lib/languages/go'),
    ]);
    mod.default.registerLanguage('python', python.default);
    mod.default.registerLanguage('javascript', javascript.default);
    mod.default.registerLanguage('cpp', cpp.default);
    mod.default.registerLanguage('rust', rust.default);
    mod.default.registerLanguage('go', go.default);
    hljsInstance = mod.default;
  }
  return hljsInstance;
}

/**
 * @param {HTMLElement} container - Element to render the lesson body into.
 * @param {Object} lesson - Compiled lesson JSON (spec §5.2 shape).
 * @returns {Promise<void>}
 */
export async function renderLesson(container, lesson) {
  const safeHtml = await sanitizeHtml(lesson.html);
  container.innerHTML = safeHtml;

  const hljs = await getHighlighter();
  container.querySelectorAll('pre code').forEach((block) => {
    try {
      hljs.highlightElement(block);
    } catch {
      // Unrecognized/unregistered language on this block — leave it
      // unhighlighted rather than breaking the whole render (spec §23).
    }
  });

  // Screen-reader labeling for code blocks (spec §19).
  container.querySelectorAll('pre').forEach((pre) => {
    const codeEl = pre.querySelector('code');
    const lang = [...(codeEl?.classList ?? [])]
      .find((c) => c.startsWith('language-'))
      ?.replace('language-', '');
    pre.setAttribute('role', 'region');
    pre.setAttribute('aria-label', lang ? `Code example in ${lang}` : 'Code example');
  });

  // "Copy" affordance on every code block, matching the CodeBlock
  // component's toolbar spec (§8.6) even for lesson-embedded snippets
  // that aren't wrapped in the full CodeBlock component.
  container.querySelectorAll('pre').forEach((pre) => {
    if (pre.querySelector('.code-copy-btn')) return;
    const button = document.createElement('button');
    button.className = 'btn btn--icon code-copy-btn';
    button.style.position = 'absolute';
    button.style.top = 'var(--space-2)';
    button.style.right = 'var(--space-2)';
    button.setAttribute('aria-label', 'Copy code');
    button.textContent = '⧉';
    pre.style.position = 'relative';
    button.addEventListener('click', () => {
      const code = pre.querySelector('code')?.textContent ?? '';
      navigator.clipboard?.writeText(code).then(() => {
        button.textContent = '✓';
        setTimeout(() => {
          button.textContent = '⧉';
        }, 1500);
      });
    });
    pre.appendChild(button);
  });
}
