/**
 * LessonLayout.js
 *
 * Implements the split-view (desktop) / stacked-view (mobile) layout
 * from spec §11. This class owns only the *layout chrome* — the resize
 * handle, the mobile editor drawer collapse/expand, fullscreen toggling —
 * and exposes two content slots (`contentSlot`, `editorSlot`) that
 * callers fill with whatever they like. It does not know about lesson
 * content or the editor itself; that separation is what lets Slice 4
 * drop a real CodeMirror instance into `editorSlot` without this class
 * changing at all.
 *
 * Desktop (>1024px): left 45% lesson content (scrollable, sticky
 * breadcrumb), right 55% editor, draggable resize handle between them.
 * Mobile (<=1024px): content on top, collapsible editor drawer below
 * with a drag handle / toggle button; fullscreen editor hides content
 * entirely.
 */
import { store } from '../store/Store.js';

const MIN_CONTENT_PERCENT = 25;
const MAX_CONTENT_PERCENT = 70;
const DEFAULT_CONTENT_PERCENT = 45;

export class LessonLayout {
  /** @type {HTMLElement} */
  el;

  /** @type {HTMLElement} */
  contentSlot;

  /** @type {HTMLElement} */
  editorSlot;

  /** @type {HTMLElement} */
  #resizeHandle;

  /** @type {HTMLElement} */
  #contentPane;

  /** @type {HTMLElement} */
  #editorPane;

  /** @type {(() => void)[]} */
  #cleanupFns = [];

  constructor() {
    this.el = document.createElement('div');
    this.el.className = 'lesson-layout';

    this.#contentPane = document.createElement('div');
    this.#contentPane.className = 'lesson-layout__content reading-column';

    this.#editorPane = document.createElement('div');
    this.#editorPane.className = 'lesson-layout__editor';

    this.#resizeHandle = document.createElement('div');
    this.#resizeHandle.className = 'lesson-layout__resize-handle';
    this.#resizeHandle.setAttribute('role', 'separator');
    this.#resizeHandle.setAttribute('aria-orientation', 'vertical');
    this.#resizeHandle.setAttribute('aria-label', 'Resize lesson content and editor panes');
    this.#resizeHandle.tabIndex = 0;

    this.contentSlot = document.createElement('div');
    this.editorSlot = document.createElement('div');
    this.editorSlot.style.height = '100%';

    this.#contentPane.appendChild(this.contentSlot);
    this.#editorPane.appendChild(this.editorSlot);

    this.el.appendChild(this.#contentPane);
    this.el.appendChild(this.#resizeHandle);
    this.el.appendChild(this.#editorPane);

    this.#wireResize();
    this.#wireKeyboardResize();
    this.#applyFullscreenState(store.getState().ui.editorFullscreen);

    const unsubscribe = store.subscribe((state, prevState) => {
      if (state.ui.editorFullscreen !== prevState.ui.editorFullscreen) {
        this.#applyFullscreenState(state.ui.editorFullscreen);
      }
    });
    this.#cleanupFns.push(unsubscribe);
  }

  #wireResize() {
    let dragging = false;

    const onPointerMove = (e) => {
      if (!dragging) return;
      const rect = this.el.getBoundingClientRect();
      const percent = ((e.clientX - rect.left) / rect.width) * 100;
      const clamped = Math.min(MAX_CONTENT_PERCENT, Math.max(MIN_CONTENT_PERCENT, percent));
      this.#setContentPercent(clamped);
    };

    const onPointerUp = () => {
      dragging = false;
    };

    const onPointerDown = (e) => {
      dragging = true;
      e.preventDefault();
    };

    this.#resizeHandle.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);

    this.#cleanupFns.push(() => {
      this.#resizeHandle.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
    });
  }

  #wireKeyboardResize() {
    const onKeyDown = (e) => {
      const current = this.#getContentPercent();
      if (e.key === 'ArrowLeft') {
        this.#setContentPercent(Math.max(MIN_CONTENT_PERCENT, current - 5));
        e.preventDefault();
      } else if (e.key === 'ArrowRight') {
        this.#setContentPercent(Math.min(MAX_CONTENT_PERCENT, current + 5));
        e.preventDefault();
      }
    };
    this.#resizeHandle.addEventListener('keydown', onKeyDown);
    this.#cleanupFns.push(() => this.#resizeHandle.removeEventListener('keydown', onKeyDown));
  }

  #getContentPercent() {
    const value = this.#contentPane.style.flexBasis;
    return value ? parseFloat(value) : DEFAULT_CONTENT_PERCENT;
  }

  /** @param {number} percent */
  #setContentPercent(percent) {
    this.#contentPane.style.flex = `0 0 ${percent}%`;
    this.#contentPane.style.maxWidth = `${percent}%`;
    this.#editorPane.style.flex = `0 0 ${100 - percent}%`;
    this.#editorPane.style.maxWidth = `${100 - percent}%`;
  }

  /** @param {boolean} isFullscreen */
  #applyFullscreenState(isFullscreen) {
    this.#editorPane.classList.toggle('editor--fullscreen-host', isFullscreen);
    this.#contentPane.style.display = isFullscreen ? 'none' : '';
    this.#resizeHandle.style.display = isFullscreen ? 'none' : '';
  }

  /** @param {HTMLElement} parent */
  mount(parent) {
    parent.appendChild(this.el);
  }

  destroy() {
    for (const fn of this.#cleanupFns) fn();
    this.el.remove();
  }
}

/**
 * Builds the mobile editor drawer (spec §11): collapsed by default,
 * expandable via a drag handle / tap, with the same `editorSlot` content
 * contract as LessonLayout's desktop editor pane.
 */
export class EditorDrawer {
  /** @type {HTMLElement} */
  el;

  /** @type {HTMLElement} */
  editorSlot;

  /** @type {HTMLElement} */
  #body;

  /** @type {() => void} */
  #unsubscribe;

  constructor() {
    this.el = document.createElement('div');
    this.el.className = 'editor-drawer';

    const handle = document.createElement('button');
    handle.className = 'editor-drawer__handle-wrapper btn';
    handle.style.width = '100%';
    handle.style.display = 'flex';
    handle.style.flexDirection = 'column';
    handle.style.alignItems = 'center';
    handle.setAttribute('aria-expanded', 'false');
    handle.setAttribute('aria-controls', 'editor-drawer-body');

    const grip = document.createElement('div');
    grip.className = 'editor-drawer__handle';
    handle.appendChild(grip);

    const label = document.createElement('span');
    label.style.fontSize = 'var(--text-xs)';
    label.style.color = 'var(--text-tertiary)';
    label.textContent = 'Editor';
    handle.appendChild(label);

    this.#body = document.createElement('div');
    this.#body.className = 'editor-drawer__body';
    this.#body.id = 'editor-drawer-body';
    this.#body.style.height = '50vh';

    this.editorSlot = document.createElement('div');
    this.editorSlot.style.height = '100%';
    this.#body.appendChild(this.editorSlot);

    this.el.appendChild(handle);
    this.el.appendChild(this.#body);

    const initialCollapsed = store.getState().ui.editorDrawerCollapsed;
    this.el.dataset.collapsed = String(initialCollapsed);
    handle.setAttribute('aria-expanded', String(!initialCollapsed));

    handle.addEventListener('click', () => {
      store.dispatch({ type: 'ui/toggleEditorDrawer' });
    });

    this.#unsubscribe = store.subscribe((state, prevState) => {
      if (state.ui.editorDrawerCollapsed !== prevState.ui.editorDrawerCollapsed) {
        this.el.dataset.collapsed = String(state.ui.editorDrawerCollapsed);
        handle.setAttribute('aria-expanded', String(!state.ui.editorDrawerCollapsed));
      }
    });
  }

  /** @param {HTMLElement} parent */
  mount(parent) {
    parent.appendChild(this.el);
  }

  destroy() {
    this.#unsubscribe();
    this.el.remove();
  }
}
