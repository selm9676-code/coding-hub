/**
 * LessonNavigation.js
 *
 * Breadcrumbs, prev/next lesson links, and swipe-to-navigate (spec §11,
 * §18, §20). Prev/next is computed from the language's meta.json lesson
 * order within the current tier — crossing a tier boundary is out of
 * scope for this helper (a lesson's "next" stops at the end of its own
 * tier); wiring "next tier" continuation is a product decision for a
 * later slice, not implied by anything in the spec.
 */

/**
 * @param {Object} tierData - meta.json's tiers[tier] entry: { label, lessons: [...] }.
 * @param {string} lessonId
 * @returns {{ prev: Object|null, next: Object|null, index: number, total: number }}
 */
export function computeAdjacentLessons(tierData, lessonId) {
  const lessons = tierData?.lessons ?? [];
  const index = lessons.findIndex((l) => l.id === lessonId);
  if (index === -1) {
    return { prev: null, next: null, index: -1, total: lessons.length };
  }
  return {
    prev: index > 0 ? lessons[index - 1] : null,
    next: index < lessons.length - 1 ? lessons[index + 1] : null,
    index,
    total: lessons.length,
  };
}

/**
 * Renders breadcrumbs + prev/next controls into a container.
 *
 * @param {HTMLElement} container
 * @param {Object} options
 * @param {Object} options.language - { id, name }
 * @param {string} options.tier
 * @param {string} options.tierLabel
 * @param {Object} options.lesson - Compiled lesson { id, title }.
 * @param {{prev: Object|null, next: Object|null, index: number, total: number}} options.adjacency
 * @param {(direction: 'prev'|'next') => void} options.onNavigate - Called when a prev/next control activates.
 */
export function renderLessonNavigation(container, { language, tier, tierLabel, lesson, adjacency, onNavigate }) {
  container.innerHTML = `
    <nav aria-label="Breadcrumb" style="font-size: var(--text-sm); color: var(--text-tertiary);">
      <a href="#/language/${language.id}">${escapeHtml(language.name)}</a>
      /
      <a href="#/language/${language.id}/${tier}">${escapeHtml(tierLabel)}</a>
      /
      <span aria-current="page">${escapeHtml(lesson.title)}</span>
    </nav>
    <div style="display:flex; align-items:center; justify-content:space-between; gap: var(--space-3); margin-top: var(--space-4);">
      <button class="btn btn--secondary" data-nav="prev" ${adjacency.prev ? '' : 'disabled aria-disabled="true"'}>
        ← ${adjacency.prev ? escapeHtml(adjacency.prev.title) : 'Previous'}
      </button>
      <span style="color: var(--text-tertiary); font-size: var(--text-xs); white-space: nowrap;">
        ${adjacency.index + 1} / ${adjacency.total}
      </span>
      <button class="btn btn--secondary" data-nav="next" ${adjacency.next ? '' : 'disabled aria-disabled="true"'}>
        ${adjacency.next ? escapeHtml(adjacency.next.title) : 'Next'} →
      </button>
    </div>
  `;

  const prevBtn = container.querySelector('[data-nav="prev"]');
  const nextBtn = container.querySelector('[data-nav="next"]');

  const onPrevClick = () => adjacency.prev && onNavigate('prev');
  const onNextClick = () => adjacency.next && onNavigate('next');

  prevBtn.addEventListener('click', onPrevClick);
  nextBtn.addEventListener('click', onNextClick);

  return () => {
    prevBtn.removeEventListener('click', onPrevClick);
    nextBtn.removeEventListener('click', onNextClick);
  };
}

/**
 * Attaches swipe-left/right-to-navigate gesture handling (spec §11, §18)
 * to an element. Uses a simple touch-delta threshold rather than a
 * gesture library, since this is the only gesture this app needs.
 *
 * @param {HTMLElement} el
 * @param {{ onSwipeLeft?: () => void, onSwipeRight?: () => void }} handlers
 * @returns {() => void} cleanup
 */
export function attachSwipeNavigation(el, { onSwipeLeft, onSwipeRight }) {
  const SWIPE_THRESHOLD_PX = 60;
  const MAX_VERTICAL_DRIFT_PX = 50;

  let startX = 0;
  let startY = 0;
  let tracking = false;

  const onTouchStart = (e) => {
    if (e.touches.length !== 1) return;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
    tracking = true;
  };

  const onTouchEnd = (e) => {
    if (!tracking) return;
    tracking = false;
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - startX;
    const deltaY = touch.clientY - startY;

    if (Math.abs(deltaY) > MAX_VERTICAL_DRIFT_PX) return; // likely a scroll, not a swipe

    if (deltaX <= -SWIPE_THRESHOLD_PX) {
      onSwipeLeft?.();
    } else if (deltaX >= SWIPE_THRESHOLD_PX) {
      onSwipeRight?.();
    }
  };

  el.addEventListener('touchstart', onTouchStart, { passive: true });
  el.addEventListener('touchend', onTouchEnd, { passive: true });

  return () => {
    el.removeEventListener('touchstart', onTouchStart);
    el.removeEventListener('touchend', onTouchEnd);
  };
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
