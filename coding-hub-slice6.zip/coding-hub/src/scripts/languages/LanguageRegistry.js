/**
 * LanguageRegistry.js
 *
 * Fetches and caches `data/languages.json` (the master registry, spec
 * §5.1) and per-language `data/<id>/meta.json` (tier/lesson index, spec
 * §5.2). Both are cached in-memory for the session — the language
 * registry itself changes only on redeploy, and re-fetching it on every
 * view mount would be wasteful.
 *
 * This module knows nothing about the Store; it's a data-access layer
 * that views call directly (read-only public data doesn't need to flow
 * through the Store/StorageProvider, which is reserved for the user's
 * own progress/settings — see ARCHITECTURE.md).
 */

/** @type {Promise<Array<Object>>|null} */
let languagesPromise = null;

/** @type {Map<string, Promise<Object>>} */
const metaPromiseCache = new Map();

/**
 * @returns {Promise<Array<Object>>} All languages in the master registry.
 */
export function getLanguages() {
  if (!languagesPromise) {
    languagesPromise = fetch('./data/languages.json')
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to load languages.json: ${res.status}`);
        return res.json();
      })
      .catch((err) => {
        // Reset the cache so a retry (e.g. user clicks "Retry" after a
        // network blip) doesn't keep replaying the same rejected promise.
        languagesPromise = null;
        throw err;
      });
  }
  return languagesPromise;
}

/**
 * @param {string} languageId
 * @returns {Promise<Object|null>} The language's registry entry, or null if unknown.
 */
export async function getLanguageById(languageId) {
  const languages = await getLanguages();
  return languages.find((lang) => lang.id === languageId) ?? null;
}

/**
 * @param {string} languageId
 * @returns {Promise<Object>} The language's tier/lesson meta index.
 * @throws if the language has no meta.json (e.g. a roadmap-status language).
 */
export function getLanguageMeta(languageId) {
  if (!metaPromiseCache.has(languageId)) {
    const promise = fetch(`./data/${languageId}/meta.json`)
      .then((res) => {
        if (!res.ok) throw new Error(`No lesson data available for "${languageId}".`);
        return res.json();
      })
      .catch((err) => {
        metaPromiseCache.delete(languageId);
        throw err;
      });
    metaPromiseCache.set(languageId, promise);
  }
  return metaPromiseCache.get(languageId);
}

/**
 * @param {string} languageId
 * @param {string} tier
 * @param {string} lessonId
 * @returns {Promise<Object>} The compiled lesson JSON (spec §5.2 shape).
 */
export async function getLesson(languageId, tier, lessonId) {
  const res = await fetch(`./data/${languageId}/${tier}/${lessonId}.json`);
  if (!res.ok) {
    throw new Error(`Lesson "${lessonId}" not found for ${languageId}/${tier}.`);
  }
  return res.json();
}
