/**
 * BookmarkManager.js
 *
 * Thin dispatch/query layer over the `bookmarks` Store slice (spec §16).
 * Views call these functions rather than dispatching bookmark actions
 * directly, so the bookmark-id scheme (`lesson:${lessonId}` or
 * `snippet:${lessonId}:${index}`) lives in exactly one place.
 */
import { store } from '../store/Store.js';

/**
 * @param {string} lessonId
 * @returns {string}
 */
function lessonBookmarkId(lessonId) {
  return `lesson:${lessonId}`;
}

/**
 * @param {string} lessonId
 * @param {number} codeBlockIndex
 * @returns {string}
 */
function snippetBookmarkId(lessonId, codeBlockIndex) {
  return `snippet:${lessonId}:${codeBlockIndex}`;
}

/**
 * @param {string} lessonId
 * @returns {boolean}
 */
export function isLessonBookmarked(lessonId) {
  return Boolean(store.getState().bookmarks.byId[lessonBookmarkId(lessonId)]);
}

/**
 * Toggles a lesson bookmark on/off.
 * @param {string} lessonId
 */
export function toggleLessonBookmark(lessonId) {
  const id = lessonBookmarkId(lessonId);
  if (store.getState().bookmarks.byId[id]) {
    store.dispatch({ type: 'bookmarks/remove', payload: { id } });
  } else {
    store.dispatch({ type: 'bookmarks/add', payload: { id, bookmarkType: 'lesson', targetId: lessonId } });
  }
}

/**
 * @param {string} lessonId
 * @param {number} codeBlockIndex
 * @returns {boolean}
 */
export function isSnippetBookmarked(lessonId, codeBlockIndex) {
  return Boolean(store.getState().bookmarks.byId[snippetBookmarkId(lessonId, codeBlockIndex)]);
}

/**
 * @param {string} lessonId
 * @param {number} codeBlockIndex
 */
export function toggleSnippetBookmark(lessonId, codeBlockIndex) {
  const id = snippetBookmarkId(lessonId, codeBlockIndex);
  if (store.getState().bookmarks.byId[id]) {
    store.dispatch({ type: 'bookmarks/remove', payload: { id } });
  } else {
    store.dispatch({
      type: 'bookmarks/add',
      payload: { id, bookmarkType: 'snippet', targetId: `${lessonId}:${codeBlockIndex}` },
    });
  }
}

/**
 * @returns {Array<Object>} All bookmarks, most recently created first.
 */
export function getAllBookmarks() {
  return Object.values(store.getState().bookmarks.byId).sort(
    (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
  );
}
