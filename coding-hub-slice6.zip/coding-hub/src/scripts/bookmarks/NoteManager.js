/**
 * NoteManager.js
 *
 * Thin dispatch/query layer over the `notes` Store slice (spec §16).
 * This project models one note per lesson (note id === lesson id) rather
 * than multiple notes per lesson — the spec describes "notes attached to
 * lessons" without requiring multiple per lesson, and one-per-lesson
 * keeps the save/load model simple (a single textarea per lesson, no
 * separate "create a new note" step). If multi-note-per-lesson becomes
 * a real requirement later, the note id scheme is the one thing that
 * would need to change; every caller already goes through this module.
 */
import { store } from '../store/Store.js';

/**
 * @param {string} lessonId
 * @returns {Object|null} The note for this lesson, or null if none exists.
 */
export function getNoteForLesson(lessonId) {
  return store.getState().notes.byId[lessonId] ?? null;
}

/**
 * @param {string} lessonId
 * @param {string} content - Raw Markdown source.
 */
export function saveNote(lessonId, content) {
  if (content.trim() === '') {
    deleteNote(lessonId);
    return;
  }
  store.dispatch({ type: 'notes/save', payload: { id: lessonId, lessonId, content } });
}

/**
 * @param {string} lessonId
 */
export function deleteNote(lessonId) {
  if (!store.getState().notes.byId[lessonId]) return;
  store.dispatch({ type: 'notes/delete', payload: { id: lessonId } });
}

/**
 * @returns {Array<Object>} All notes, most recently updated first.
 */
export function getAllNotes() {
  return Object.values(store.getState().notes.byId).sort(
    (a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)
  );
}

/**
 * Full-text search across personal notes (spec §16). Simple
 * case-insensitive substring match — no fuzzy matching here, since
 * that's fuse.js's job for the lesson/language search feature (Slice 7)
 * and notes are a much smaller, personal dataset where exact substring
 * matching is both sufficient and more predictable for the note's own
 * author.
 *
 * @param {string} query
 * @returns {Array<Object>} Matching notes, most recently updated first.
 */
export function searchNotes(query) {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) return getAllNotes();
  return getAllNotes().filter((note) => note.content.toLowerCase().includes(normalizedQuery));
}
