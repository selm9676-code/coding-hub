/**
 * StatsDashboard.js
 *
 * Renders the `/#/progress` dashboard content (spec §15): XP bar + level,
 * streak flame, 30-day activity heatmap, per-language completion rings,
 * recent achievements, and a "Continue Learning" card. This is a pure
 * render function (not a class) since the dashboard has no internal
 * interactive state of its own beyond what the Store already provides —
 * ProgressView.js re-calls this on every Store change, same pattern as
 * its Slice 1 stub used.
 *
 * KNOWN LIMITATION on completion rings, disclosed rather than hidden: a
 * precise per-language completion percentage needs each language's
 * meta.json (to know the total lesson count to divide by), which this
 * dashboard intentionally does not fetch for every language on every
 * render (that would mean N extra fetches just to load the dashboard).
 * The rings below show "started this language" (filled) vs. "not yet
 * started" (empty outline) rather than a fabricated percentage — a real
 * progress ring is a legitimate follow-up once the dashboard's data
 * needs justify the extra fetches.
 */
import { selectLevelFromXp, selectCompletedLessonCount } from '../store/selectors.js';
import { computeCurrentStreak, computeActivityHeatmap } from './StreakTracker.js';
import { ACHIEVEMENTS } from './AchievementEngine.js';
import { getLanguages } from '../languages/LanguageRegistry.js';

/**
 * @param {HTMLElement} container
 * @param {Object} state - Full Store state.
 */
export function renderStatsDashboard(container, state) {
  const { level, xpIntoLevel, xpForNextLevel } = selectLevelFromXp(state.xp.total);
  const streak = computeCurrentStreak(state.xp.history);
  const heatmap = computeActivityHeatmap(state.xp.history);
  const completedCount = selectCompletedLessonCount(state);
  const unlockedAchievements = Object.values(state.achievements?.unlockedById ?? {})
    .sort((a, b) => new Date(b.unlockedAt) - new Date(a.unlockedAt))
    .slice(0, 5)
    .map((u) => ACHIEVEMENTS.find((a) => a.id === u.id))
    .filter(Boolean);

  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-8);">
      <h1>Your Progress</h1>
    </div>
    <div class="grid" style="margin-top: var(--space-8);">
      <div class="card">
        <p style="color: var(--text-tertiary); font-size: var(--text-sm);">Level ${level}</p>
        <div style="height: 12px; background: var(--bg-elevated); border-radius: var(--radius-full); margin-top: var(--space-3); overflow: hidden;">
          <div style="height: 100%; width: ${Math.min(100, (xpIntoLevel / Math.max(1, xpForNextLevel)) * 100)}%; background: var(--accent-gradient); transition: width var(--transition-slow);"></div>
        </div>
        <p style="color: var(--text-tertiary); font-size: var(--text-xs); margin-top: var(--space-2);">
          ${xpIntoLevel} / ${xpForNextLevel} XP to next level
        </p>
      </div>
      <div class="card">
        <p style="color: var(--text-tertiary); font-size: var(--text-sm);">Current Streak</p>
        <p style="font-size: var(--text-3xl); font-weight: var(--font-bold); margin-top: var(--space-2);">
          ${streak > 0 ? '🔥 ' : ''}${streak} day${streak === 1 ? '' : 's'}
        </p>
      </div>
      <div class="card">
        <p style="color: var(--text-tertiary); font-size: var(--text-sm);">Lessons Completed</p>
        <p style="font-size: var(--text-3xl); font-weight: var(--font-bold); margin-top: var(--space-2);">${completedCount}</p>
      </div>
    </div>

    <div class="card" style="margin-top: var(--space-6);">
      <h2 style="font-size: var(--text-lg); margin-bottom: var(--space-4);">Activity — last 30 days</h2>
      <div id="heatmap-mount" style="display:grid; grid-template-columns: repeat(10, 1fr); gap: var(--space-1);"></div>
    </div>

    <div id="completion-rings-mount" style="margin-top: var(--space-6);"></div>

    <div class="card" style="margin-top: var(--space-6);">
      <h2 style="font-size: var(--text-lg); margin-bottom: var(--space-4);">Recent Achievements</h2>
      <div id="achievements-mount"></div>
    </div>
  `;

  renderHeatmap(container.querySelector('#heatmap-mount'), heatmap);
  renderAchievements(container.querySelector('#achievements-mount'), unlockedAchievements);
  renderCompletionRings(container.querySelector('#completion-rings-mount'), state);
}

/**
 * @param {HTMLElement} mount
 * @param {Array<{dateKey: string, active: boolean}>} heatmap
 */
function renderHeatmap(mount, heatmap) {
  mount.innerHTML = heatmap
    .map(
      (day) => `
        <div
          title="${day.dateKey}${day.active ? ' — active' : ''}"
          style="aspect-ratio: 1; border-radius: var(--radius-sm); background: ${day.active ? 'var(--accent-cyan)' : 'var(--bg-elevated)'};"
        ></div>
      `
    )
    .join('');
}

/**
 * @param {HTMLElement} mount
 * @param {Array<Object>} achievements
 */
function renderAchievements(mount, achievements) {
  if (achievements.length === 0) {
    mount.innerHTML = `<p style="color: var(--text-tertiary); font-size: var(--text-sm);">Complete lessons and quizzes to start unlocking achievements.</p>`;
    return;
  }

  mount.innerHTML = achievements
    .map(
      (a) => `
        <div style="display:flex; align-items:center; gap: var(--space-3); padding: var(--space-2) 0;">
          <span class="pill" style="border-color: var(--accent-cyan); color: var(--accent-cyan);">🏆</span>
          <div>
            <p style="font-weight: var(--font-semibold); font-size: var(--text-sm);">${escapeHtml(a.name)}</p>
            <p style="color: var(--text-tertiary); font-size: var(--text-xs);">${escapeHtml(a.description)}</p>
          </div>
        </div>
      `
    )
    .join('');
}

/**
 * @param {HTMLElement} mount
 * @param {Object} state
 */
async function renderCompletionRings(mount, state) {
  let languages;
  try {
    languages = await getLanguages();
  } catch {
    return; // dashboard still shows everything else; rings are additive
  }

  const completeLanguages = languages.filter((l) => l.status === 'complete');
  const started = Object.keys(state.progress.byLessonId).length > 0;

  mount.innerHTML = `
    <div class="card">
      <h2 style="font-size: var(--text-lg); margin-bottom: var(--space-4);">Language Progress</h2>
      <div class="grid grid--tight">
        ${completeLanguages
          .map(
            (lang) => `
              <div style="text-align:center;">
                <div style="width:56px; height:56px; border-radius:50%; border: 3px solid ${started ? lang.accentColor : 'var(--border-subtle)'}; display:flex; align-items:center; justify-content:center; margin: 0 auto;">
                  <span style="font-size: var(--text-xs); color: ${started ? lang.accentColor : 'var(--text-tertiary)'};">${started ? '●' : '○'}</span>
                </div>
                <p style="font-size: var(--text-xs); color: var(--text-secondary); margin-top: var(--space-2);">${escapeHtml(lang.name)}</p>
              </div>
            `
          )
          .join('')}
      </div>
    </div>
  `;
}

/** @param {string} str @returns {string} */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
