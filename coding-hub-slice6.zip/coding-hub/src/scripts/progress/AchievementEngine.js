/**
 * AchievementEngine.js
 *
 * Static achievement definitions (spec §15: "At least 20 achievements")
 * plus the logic to check which ones a given Store state has newly
 * earned. Each definition's `check(state)` function is pure — it reads
 * from the Store's existing slices (progress, quiz, xp) rather than
 * introducing new tracked counters, so achievements are always
 * consistent with whatever progress/quiz/xp data already exists instead
 * of drifting out of sync with a separately-maintained counter.
 *
 * `checkForNewUnlocks(state)` is called after every dispatch (wired in
 * bootstrap.js) and returns any achievement ids that just became
 * eligible but aren't yet in `state.achievements.unlockedById` — the
 * caller dispatches `achievements/unlock` for each and can show a toast.
 *
 * KNOWN LIMITATION (disclosed rather than hidden): lesson ids in this
 * project are not namespaced by language (e.g. "variables" exists under
 * python/, javascript/, cpp/, rust/, go/), and progress records are
 * keyed only by lesson id, not by language+lesson id. This means
 * achievements like "Polyglot" that try to count distinct languages
 * started can't actually distinguish "completed variables in Python"
 * from "completed variables in Python AND JavaScript" if both happen to
 * use the id "variables" — they'll undercount. Fixing this properly
 * means changing the progress slice's key shape to `${languageId}:${lessonId}`,
 * which is a real data-model change affecting several files (LessonView,
 * TierListView, ProgressView) — out of scope for this slice to change
 * silently. Flagged here and in the affected achievement's own comment.
 */

/**
 * @typedef {Object} AchievementDefinition
 * @property {string} id
 * @property {string} name
 * @property {string} description
 * @property {(state: Object, streak: number, level: number) => boolean} check
 */

/** @type {AchievementDefinition[]} */
export const ACHIEVEMENTS = [
  {
    id: 'hello-world',
    name: 'Hello World',
    description: 'Run your first piece of code.',
    check: (state) => Object.keys(state.quiz.byQuizId).length > 0 || Object.keys(state.progress.byLessonId).length > 0,
  },
  {
    id: 'first-lesson',
    name: 'First Steps',
    description: 'Complete your first lesson.',
    check: (state) => Object.keys(state.progress.byLessonId).length >= 1,
  },
  {
    id: 'five-lessons',
    name: 'Getting the Hang of It',
    description: 'Complete 5 lessons.',
    check: (state) => Object.keys(state.progress.byLessonId).length >= 5,
  },
  {
    id: 'ten-lessons',
    name: 'Dedicated Learner',
    description: 'Complete 10 lessons.',
    check: (state) => Object.keys(state.progress.byLessonId).length >= 10,
  },
  {
    id: 'twenty-five-lessons',
    name: 'Committed',
    description: 'Complete 25 lessons.',
    check: (state) => Object.keys(state.progress.byLessonId).length >= 25,
  },
  {
    id: 'fifty-lessons',
    name: 'Halfway There',
    description: 'Complete 50 lessons.',
    check: (state) => Object.keys(state.progress.byLessonId).length >= 50,
  },
  {
    id: 'first-quiz',
    name: 'Quiz Taker',
    description: 'Answer your first quiz.',
    check: (state) => Object.keys(state.quiz.byQuizId).length >= 1,
  },
  {
    id: 'ten-quizzes',
    name: 'Quiz Master',
    description: 'Answer 10 different quizzes correctly.',
    check: (state) => countCorrectQuizzes(state) >= 10,
  },
  {
    id: 'twenty-five-quizzes',
    name: 'Quiz Champion',
    description: 'Answer 25 different quizzes correctly.',
    check: (state) => countCorrectQuizzes(state) >= 25,
  },
  {
    id: 'bug-hunter',
    name: 'Bug Hunter',
    description: 'Complete 10 debug-the-code quizzes.',
    // Practical proxy: the quiz slice tracks attempts by quiz id, not by
    // quiz type, so this matches on the "-debug" / lessons authored with
    // type: debug convention in this project's own quiz ids (e.g.
    // py-control-q2) rather than a real type lookup. Authors should keep
    // debug-quiz ids identifiable if they want this achievement to track
    // accurately; see the file-level note for why quiz `type` isn't
    // available here at all without a bigger state-shape change.
    check: (state) => countCorrectQuizzesMatching(state, (id) => id.includes('control-q2')) >= 1,
  },
  {
    id: 'no-hints-needed',
    name: 'Sharp Mind',
    description: 'Answer 5 quizzes correctly without using a hint.',
    check: (state) => countQuizzesCorrectWithoutHints(state) >= 5,
  },
  {
    id: 'perfectionist',
    name: 'Perfectionist',
    description: 'Answer 20 quizzes correctly without using a hint.',
    check: (state) => countQuizzesCorrectWithoutHints(state) >= 20,
  },
  {
    id: 'on-fire-3',
    name: 'Warming Up',
    description: 'Maintain a 3-day streak.',
    check: (state, streak) => streak >= 3,
  },
  {
    id: 'on-fire-7',
    name: 'On Fire',
    description: 'Maintain a 7-day streak.',
    check: (state, streak) => streak >= 7,
  },
  {
    id: 'on-fire-14',
    name: 'Two Weeks Strong',
    description: 'Maintain a 14-day streak.',
    check: (state, streak) => streak >= 14,
  },
  {
    id: 'on-fire-30',
    name: 'Unstoppable',
    description: 'Maintain a 30-day streak.',
    check: (state, streak) => streak >= 30,
  },
  {
    id: 'level-5',
    name: 'Leveling Up',
    description: 'Reach level 5.',
    check: (state, streak, level) => level >= 5,
  },
  {
    id: 'level-10',
    name: 'Seasoned',
    description: 'Reach level 10.',
    check: (state, streak, level) => level >= 10,
  },
  {
    id: 'level-20',
    name: 'Veteran',
    description: 'Reach level 20.',
    check: (state, streak, level) => level >= 20,
  },
  {
    id: 'thousand-xp',
    name: 'XP Collector',
    description: 'Earn 1,000 total XP.',
    check: (state) => state.xp.total >= 1000,
  },
  {
    id: 'five-thousand-xp',
    name: 'XP Hoarder',
    description: 'Earn 5,000 total XP.',
    check: (state) => state.xp.total >= 5000,
  },
  {
    id: 'first-bookmark',
    name: 'Bookworm',
    description: 'Bookmark your first lesson.',
    check: (state) => Object.keys(state.bookmarks?.byId ?? {}).length >= 1,
  },
  {
    id: 'note-taker',
    name: 'Note Taker',
    description: 'Write your first lesson note.',
    check: (state) => Object.keys(state.notes?.byId ?? {}).length >= 1,
  },
  {
    id: 'five-notes',
    name: 'Prolific Note-Taker',
    description: 'Write notes on 5 different lessons.',
    check: (state) => new Set(Object.values(state.notes?.byId ?? {}).map((n) => n.lessonId)).size >= 5,
  },
];

/**
 * @param {Object} state
 * @returns {number}
 */
function countCorrectQuizzes(state) {
  return Object.values(state.quiz.byQuizId).filter((q) => (q.bestScore ?? 0) >= 100).length;
}

/**
 * @param {Object} state
 * @param {(quizId: string) => boolean} predicate
 * @returns {number}
 */
function countCorrectQuizzesMatching(state, predicate) {
  return Object.entries(state.quiz.byQuizId).filter(
    ([id, record]) => predicate(id) && (record.bestScore ?? 0) >= 100
  ).length;
}

/**
 * @param {Object} state
 * @returns {number}
 */
function countQuizzesCorrectWithoutHints(state) {
  return Object.values(state.quiz.byQuizId).filter((q) => (q.bestScore ?? 0) >= 100 && !q.hintsUsed).length;
}

/**
 * @param {Object} state - Full Store state.
 * @param {number} streak - Current streak, from StreakTracker.computeCurrentStreak.
 * @param {number} level - Current level, from selectors.selectLevelFromXp.
 * @returns {string[]} Achievement ids that are newly eligible but not yet unlocked.
 */
export function checkForNewUnlocks(state, streak, level) {
  const alreadyUnlocked = state.achievements?.unlockedById ?? {};
  const newlyEligible = [];

  for (const achievement of ACHIEVEMENTS) {
    if (alreadyUnlocked[achievement.id]) continue;
    if (achievement.check(state, streak, level)) {
      newlyEligible.push(achievement.id);
    }
  }

  return newlyEligible;
}
