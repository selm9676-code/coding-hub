/**
 * StreakTracker.js
 *
 * Computes streak and activity-heatmap data (spec §15) from the `xp`
 * slice's `history` array — every XP award (lesson completion, quiz
 * completion) already carries a `date` field (see xpSlice.js), so this
 * is a derived view over data that already exists rather than a new
 * source of truth. There is no separate "last active date" field to
 * keep in sync; the streak is always recomputed from the same history
 * the XP bar itself displays.
 *
 * "Day" boundaries use the learner's local calendar day (via
 * `getFullYear`/`getMonth`/`getDate`, i.e. the browser's own local
 * time), not UTC — a learner working late at night shouldn't have their
 * streak break at an arbitrary UTC midnight that doesn't match their
 * actual day.
 */

/**
 * @param {Array<{date: string}>} xpHistory
 * @returns {Set<string>} Set of unique local-date strings (YYYY-MM-DD) with any activity.
 */
function getActiveDateStrings(xpHistory) {
  const dates = new Set();
  for (const entry of xpHistory) {
    const d = new Date(entry.date);
    dates.add(toDateKey(d));
  }
  return dates;
}

/**
 * @param {Date} date
 * @returns {string} YYYY-MM-DD in local time.
 */
function toDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Computes the current consecutive-day streak. A streak counts back from
 * today (or yesterday, if there's no activity yet today — the learner
 * hasn't "broken" today's streak until today actually ends) as long as
 * every preceding day has at least one activity entry.
 *
 * @param {Array<{date: string}>} xpHistory
 * @param {Date} [now] - Injectable for testing; defaults to the real current time.
 * @returns {number} Current streak length in days (0 if no activity today or yesterday).
 */
export function computeCurrentStreak(xpHistory, now = new Date()) {
  const activeDates = getActiveDateStrings(xpHistory);
  if (activeDates.size === 0) return 0;

  const todayKey = toDateKey(now);
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayKey = toDateKey(yesterday);

  // If there's no activity today AND none yesterday, the streak is
  // broken — even if there was a long streak further in the past.
  if (!activeDates.has(todayKey) && !activeDates.has(yesterdayKey)) {
    return 0;
  }

  // Start counting from today if there's activity today, otherwise from
  // yesterday (so a learner who hasn't opened the app yet today doesn't
  // see their streak zeroed out prematurely).
  let cursor = activeDates.has(todayKey) ? new Date(now) : yesterday;
  let streak = 0;

  while (activeDates.has(toDateKey(cursor))) {
    streak += 1;
    cursor = new Date(cursor);
    cursor.setDate(cursor.getDate() - 1);
  }

  return streak;
}

/**
 * Builds a 30-day activity heatmap (spec §15), oldest day first.
 *
 * @param {Array<{date: string}>} xpHistory
 * @param {Date} [now]
 * @returns {Array<{dateKey: string, active: boolean}>} 30 entries, oldest first, today last.
 */
export function computeActivityHeatmap(xpHistory, now = new Date()) {
  const activeDates = getActiveDateStrings(xpHistory);
  const days = [];

  for (let i = 29; i >= 0; i -= 1) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateKey = toDateKey(d);
    days.push({ dateKey, active: activeDates.has(dateKey) });
  }

  return days;
}
