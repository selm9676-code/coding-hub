/**
 * Router.js
 *
 * Hash-based client-side router (spec §2, §10). Hash routing is required
 * because the deployed artifact is pure static files on hosts with no
 * guaranteed server-side rewrite rules — the hash portion of a URL never
 * hits the server, so `/#/language/python/easy/variables` always resolves
 * to `index.html` regardless of host.
 *
 * Route modules are lazy-loaded: `routes.js` maps a pattern to a function
 * that returns `import('./some-view.js')`, so nothing beyond the shell
 * loads until a route is actually visited.
 */

/**
 * @typedef {Object} RouteMatch
 * @property {Object} params - Named params extracted from the hash.
 * @property {URLSearchParams} query - Parsed query string, if any.
 * @property {import('./routes.js').RouteDefinition} route - The matched route definition.
 */

export class Router {
  /** @type {import('./routes.js').RouteDefinition[]} */
  #routes = [];

  /** @type {(match: RouteMatch|null, path: string) => void} */
  #onChange;

  /** @type {Array<(to: string, from: string) => boolean|Promise<boolean>>} */
  #beforeGuards = [];

  /** @type {Array<(to: string, from: string) => void>} */
  #afterHooks = [];

  #currentPath = '';

  /** @type {() => void} bound reference to #handleHashChange, so add/removeEventListener target the same function */
  #boundHandleHashChange;

  /**
   * @param {import('./routes.js').RouteDefinition[]} routes
   * @param {(match: RouteMatch|null, path: string) => void} onChange - Called with the resolved match (or null for a 404) whenever the hash changes.
   */
  constructor(routes, onChange) {
    this.#routes = routes;
    this.#onChange = onChange;
    // Private methods are non-writable, so we can't reassign
    // this.#handleHashChange directly (that throws a TypeError). Instead we
    // keep a bound copy in a separate field and register/unregister that.
    this.#boundHandleHashChange = () => this.#handleHashChange();
  }

  /** Registers a guard that can cancel navigation by returning/resolving false. */
  beforeEach(guard) {
    this.#beforeGuards.push(guard);
  }

  /** Registers a hook invoked after every successful navigation. */
  afterEach(hook) {
    this.#afterHooks.push(hook);
  }

  /** Starts listening for hash changes and resolves the current URL immediately. */
  start() {
    window.addEventListener('hashchange', this.#boundHandleHashChange);
    this.#handleHashChange();
  }

  stop() {
    window.removeEventListener('hashchange', this.#boundHandleHashChange);
  }

  /**
   * Programmatic navigation. Setting `location.hash` triggers
   * `hashchange`, which re-enters the same resolution path as a user
   * clicking a link — so there is exactly one code path for "the route
   * changed," not two.
   * @param {string} path - e.g. '/language/python/easy'
   */
  navigate(path) {
    const target = path.startsWith('#') ? path : `#${path}`;
    if (`#${this.#currentPath}` === target) return;
    window.location.hash = target;
  }

  async #handleHashChange() {
    const rawHash = window.location.hash.replace(/^#/, '') || '/home';
    const [pathPart, queryPart] = rawHash.split('?');
    const from = this.#currentPath;

    for (const guard of this.#beforeGuards) {
      const allowed = await guard(pathPart, from);
      if (allowed === false) {
        // Guard rejected navigation; revert the visible hash to `from`.
        if (from) window.location.hash = `#${from}`;
        return;
      }
    }

    this.#currentPath = pathPart;
    const match = this.#resolve(pathPart, queryPart);
    this.#onChange(match, pathPart);

    for (const hook of this.#afterHooks) {
      hook(pathPart, from);
    }
  }

  /**
   * @param {string} path
   * @param {string} [queryString]
   * @returns {RouteMatch|null}
   */
  #resolve(path, queryString) {
    const segments = path.split('/').filter(Boolean);

    for (const route of this.#routes) {
      const patternSegments = route.pattern.split('/').filter(Boolean);
      if (patternSegments.length !== segments.length) continue;

      const params = {};
      let isMatch = true;

      for (let i = 0; i < patternSegments.length; i += 1) {
        const patternSegment = patternSegments[i];
        const actualSegment = segments[i];

        if (patternSegment.startsWith(':')) {
          params[patternSegment.slice(1)] = decodeURIComponent(actualSegment);
        } else if (patternSegment !== actualSegment) {
          isMatch = false;
          break;
        }
      }

      if (isMatch) {
        return {
          params,
          query: new URLSearchParams(queryString ?? ''),
          route,
        };
      }
    }

    return null;
  }
}
