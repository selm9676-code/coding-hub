/**
 * guards.js
 *
 * Before/after route hooks (spec §10). Kept separate from Router.js so
 * the Router class stays generic and these app-specific policies (e.g.
 * "remember the last route visited", "warn before leaving an in-progress
 * quiz") can evolve independently.
 */
import { store } from '../store/Store.js';

/**
 * Persists the last visited route to settings so a returning user can be
 * offered a "continue where you left off" experience (spec §6, §15).
 * Registered as an afterEach hook in bootstrap.js.
 *
 * @param {string} to
 */
export function recordLastRoute(to) {
  store.dispatch({ type: 'settings/setLastRoute', payload: { route: to } });
}

/**
 * Placeholder guard structure for future "unsaved changes" prompts (e.g.
 * leaving a lesson mid-quiz, or an unsaved note). Returns true (allow
 * navigation) until such flows are implemented in a later slice.
 *
 * @param {string} to
 * @param {string} from
 * @returns {boolean}
 */
export function confirmUnsavedChanges(to, from) {
  return true;
}
