/**
 * routes.js
 *
 * Route table mapping URL patterns (spec §10) to lazy-loaded view
 * modules. Each `load` function returns a dynamic import so the
 * corresponding view code only downloads when the route is first
 * visited. View modules are expected to export a default function:
 * `(container: HTMLElement, match: RouteMatch) => (void | () => void)`
 * — an optional returned cleanup function is called when navigating away.
 *
 * View modules themselves are built in later slices (Slice 2+); this
 * table exists now so the Router has real (if not-yet-created) targets,
 * and so route parsing/guarding can be exercised by unit tests in Slice 1.
 */

/**
 * @typedef {Object} RouteDefinition
 * @property {string} pattern - e.g. '/language/:languageId/:tier/:lessonId'
 * @property {string} name - Human-readable route name, used for preloading/logging.
 * @property {() => Promise<{ default: Function }>} load
 */

/** @type {RouteDefinition[]} */
export const routes = [
  {
    pattern: '/home',
    name: 'home',
    load: () => import('../../views/HomeView.js'),
  },
  {
    pattern: '/language/:languageId',
    name: 'language-hub',
    load: () => import('../../views/LanguageHubView.js'),
  },
  {
    pattern: '/language/:languageId/:tier',
    name: 'tier-lesson-list',
    load: () => import('../../views/TierListView.js'),
  },
  {
    pattern: '/language/:languageId/:tier/:lessonId',
    name: 'lesson',
    load: () => import('../../views/LessonView.js'),
  },
  {
    pattern: '/search',
    name: 'search',
    load: () => import('../../views/SearchView.js'),
  },
  {
    pattern: '/bookmarks',
    name: 'bookmarks',
    load: () => import('../../views/BookmarksView.js'),
  },
  {
    pattern: '/progress',
    name: 'progress',
    load: () => import('../../views/ProgressView.js'),
  },
  {
    pattern: '/settings',
    name: 'settings',
    load: () => import('../../views/SettingsView.js'),
  },
];
