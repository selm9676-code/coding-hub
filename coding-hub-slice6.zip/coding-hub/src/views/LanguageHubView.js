/**
 * LanguageHubView.js
 *
 * Language hub: shows the language's tagline/stats and a list of tiers.
 * Also populates the desktop sidebar (#app-sidebar) with tier navigation
 * for this language, per spec §18's "sticky sidebar (desktop): tier
 * navigation." Sidebar content is scoped to this view's lifetime — its
 * cleanup function clears the sidebar so it doesn't leak into unrelated
 * routes.
 *
 * @param {HTMLElement} container
 * @param {import('../scripts/router/Router.js').RouteMatch} match
 * @returns {() => void} cleanup
 */
import { getLanguageById, getLanguageMeta } from '../scripts/languages/LanguageRegistry.js';
import { Skeleton } from '../scripts/components/Skeleton.js';

export default function LanguageHubView(container, match) {
  const { languageId } = match.params;
  let cancelled = false;

  const skeleton = new Skeleton({ count: 1, height: '200px' });
  container.innerHTML = '';
  skeleton.mount(container);

  Promise.all([getLanguageById(languageId), getLanguageMeta(languageId).catch(() => null)])
    .then(([language, meta]) => {
      if (cancelled) return;
      skeleton.destroy();

      if (!language) {
        renderUnknownLanguage(container, languageId);
        return;
      }

      if (language.status === 'roadmap') {
        renderRoadmapLanguage(container, language);
        return;
      }

      renderCompleteLanguage(container, language, meta);
      populateSidebar(language, meta);
    })
    .catch((err) => {
      if (cancelled) return;
      skeleton.destroy();
      renderLoadError(container, err);
    });

  return () => {
    cancelled = true;
    clearSidebar();
  };
}

/**
 * @param {HTMLElement} container
 * @param {Object} language
 * @param {Object|null} meta
 */
function renderCompleteLanguage(container, language, meta) {
  const tiers = meta?.tiers ?? {};
  const tierCards = language.tiers
    .map((tierId) => {
      const tier = tiers[tierId];
      const lessonCount = tier?.lessons?.length ?? 0;
      return `
        <a href="#/language/${language.id}/${tierId}" class="card" style="display:block;">
          <h3 style="font-size: var(--text-lg); text-transform: capitalize;">${escapeHtml(tier?.label ?? tierId)}</h3>
          <p style="color: var(--text-tertiary); font-size: var(--text-sm); margin-top: var(--space-2);">
            ${lessonCount} lesson${lessonCount === 1 ? '' : 's'}${lessonCount === 0 ? ' · coming soon' : ''}
          </p>
        </a>
      `;
    })
    .join('');

  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-8);">
      <h1 style="color: ${language.accentColor};">${escapeHtml(language.name)}</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">${escapeHtml(language.tagline ?? '')}</p>
      <p style="color: var(--text-tertiary); font-size: var(--text-sm); margin-top: var(--space-2);">
        ~${language.estimatedHours} hours · ${escapeHtml(language.difficulty)}
      </p>
    </div>
    <div class="grid" style="margin-top: var(--space-8); max-width: var(--reading-width); margin-inline:auto;">
      ${tierCards}
    </div>
  `;
}

/**
 * @param {HTMLElement} container
 * @param {Object} language
 */
function renderRoadmapLanguage(container, language) {
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1 style="color: ${language.accentColor};">${escapeHtml(language.name)}</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">${escapeHtml(language.tagline ?? '')}</p>
      <div class="card" style="margin-top: var(--space-8);">
        <p class="pill" style="margin-bottom: var(--space-3);">Coming soon</p>
        <p style="color: var(--text-secondary);">
          ${escapeHtml(language.name)} lessons are on the roadmap. Voting and notify-me
          controls for roadmap languages are arriving in a later build slice.
        </p>
      </div>
      <a href="#/home" class="btn btn--secondary" style="margin-top: var(--space-6); display:inline-flex;">
        Back to all languages
      </a>
    </div>
  `;
}

/**
 * @param {HTMLElement} container
 * @param {string} languageId
 */
function renderUnknownLanguage(container, languageId) {
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1>Language not found</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">
        "${escapeHtml(languageId)}" isn't in the catalog.
      </p>
      <a href="#/home" class="btn btn--secondary" style="margin-top: var(--space-6); display:inline-flex;">
        Back to all languages
      </a>
    </div>
  `;
}

/**
 * @param {HTMLElement} container
 * @param {Error} err
 */
function renderLoadError(container, err) {
  console.error('Failed to load language hub:', err);
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1>Something went wrong</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">This page couldn't be loaded.</p>
      <button class="btn btn--secondary" style="margin-top: var(--space-6);" onclick="window.location.reload()">Retry</button>
    </div>
  `;
}

/**
 * @param {Object} language
 * @param {Object|null} meta
 */
function populateSidebar(language, meta) {
  const sidebar = document.getElementById('app-sidebar');
  if (!sidebar) return;

  const tiers = meta?.tiers ?? {};
  sidebar.innerHTML = `
    <p style="color: var(--text-tertiary); font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: var(--space-4);">
      ${escapeHtml(language.name)}
    </p>
    <nav style="display:flex; flex-direction:column; gap: var(--space-1);">
      ${language.tiers
        .map((tierId) => {
          const label = tiers[tierId]?.label ?? tierId;
          return `<a href="#/language/${language.id}/${tierId}" class="btn btn--ghost" style="justify-content:flex-start; text-transform:capitalize;">${escapeHtml(label)}</a>`;
        })
        .join('')}
    </nav>
  `;
}

function clearSidebar() {
  const sidebar = document.getElementById('app-sidebar');
  if (sidebar) sidebar.innerHTML = '';
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
