/**
 * LessonView.js
 *
 * Real lesson reader: fetches the compiled lesson + tier metadata,
 * renders sanitized/highlighted HTML into the split (desktop) or
 * stacked (mobile) layout from LessonLayout, wires breadcrumbs, prev/next
 * navigation, swipe gestures, and the `J`/`K`/`F`/`Esc` keyboard
 * shortcuts from spec §20.
 *
 * As of Slice 4, the editor pane is a real `Editor` instance (CodeMirror
 * 6 + Web Worker execution) seeded with the lesson's first code snippet.
 * Desktop and mobile each get their own independent `Editor` instance
 * since only one is ever mounted/visible for a given viewport.
 *
 * As of Slice 5, quizzes attached to this lesson (via `quizIds`,
 * populated at build/dev-serve time by matching quizzes.json's
 * `lessonId` field) render below the lesson body, each as a `QuizEngine`
 * instance. Lesson completion (spec §7, §15) is now genuinely
 * quiz-gated: viewing a lesson always records `progress/recordView`, but
 * `progress/completeLesson` only dispatches once every attached quiz has
 * been answered correctly at least once in this session. A lesson with
 * no quizzes attached completes immediately on render, since there's
 * nothing to gate on — this matches how the app behaves for the many
 * lessons that don't have quiz content authored yet, without inventing
 * a "reading time" heuristic the spec never asked for.
 *
 * @param {HTMLElement} container
 * @param {import('../scripts/router/Router.js').RouteMatch} match
 * @returns {() => void} cleanup
 */
import { getLanguageById, getLanguageMeta, getLesson } from '../scripts/languages/LanguageRegistry.js';
import { renderLesson } from '../scripts/lessons/LessonRenderer.js';
import { LessonLayout, EditorDrawer } from '../scripts/lessons/LessonLayout.js';
import {
  computeAdjacentLessons,
  renderLessonNavigation,
  attachSwipeNavigation,
} from '../scripts/lessons/LessonNavigation.js';
import { Skeleton } from '../scripts/components/Skeleton.js';
import { Editor } from '../scripts/editor/Editor.js';
import { getQuizzesByIds } from '../scripts/quizzes/QuizLoader.js';
import { QuizEngine } from '../scripts/quizzes/QuizEngine.js';
import { isLessonBookmarked, toggleLessonBookmark } from '../scripts/bookmarks/BookmarkManager.js';
import { getNoteForLesson, saveNote } from '../scripts/bookmarks/NoteManager.js';
import { store } from '../scripts/store/Store.js';

const DESKTOP_BREAKPOINT = 1024;

export default function LessonView(container, match) {
  const { languageId, tier, lessonId } = match.params;
  let cancelled = false;
  const cleanupFns = [];

  const skeleton = new Skeleton({ count: 1, height: '400px' });
  container.innerHTML = '';
  skeleton.mount(container);

  Promise.all([
    getLanguageById(languageId),
    getLanguageMeta(languageId),
    getLesson(languageId, tier, lessonId),
  ])
    .then(([language, meta, lesson]) => {
      if (cancelled) return;
      skeleton.destroy();

      if (!language) {
        renderNotFound(container, `Language "${languageId}" not found.`);
        return;
      }
      const tierData = meta.tiers?.[tier];
      if (!tierData) {
        renderNotFound(container, `Tier "${tier}" not found for ${language.name}.`);
        return;
      }

      mountLessonReader(container, cleanupFns, { language, tier, tierData, lesson, match });
    })
    .catch((err) => {
      if (cancelled) return;
      skeleton.destroy();
      renderLoadError(container, err);
    });

  return () => {
    cancelled = true;
    for (const fn of cleanupFns) fn();
  };
}

/**
 * @param {HTMLElement} container
 * @param {Array<() => void>} cleanupFns
 * @param {Object} ctx
 */
function mountLessonReader(container, cleanupFns, { language, tier, tierData, lesson, match }) {
  const adjacency = computeAdjacentLessons(tierData, lesson.id);

  container.innerHTML = '';

  const breadcrumbMount = document.createElement('div');
  breadcrumbMount.className = 'reading-column';
  breadcrumbMount.style.marginBottom = 'var(--space-6)';
  breadcrumbMount.style.display = 'flex';
  breadcrumbMount.style.alignItems = 'flex-start';
  breadcrumbMount.style.justifyContent = 'space-between';
  breadcrumbMount.style.gap = 'var(--space-3)';
  container.appendChild(breadcrumbMount);

  const breadcrumbNavMount = document.createElement('div');
  breadcrumbNavMount.style.flex = '1';
  breadcrumbMount.appendChild(breadcrumbNavMount);

  const bookmarkCleanup = mountBookmarkButton(breadcrumbMount, lesson.id);
  cleanupFns.push(bookmarkCleanup);

  const isDesktop = window.innerWidth >= DESKTOP_BREAKPOINT;

  const layout = new LessonLayout();
  layout.mount(container);

  const lessonBody = document.createElement('div');
  lessonBody.className = 'lesson-content';
  layout.contentSlot.appendChild(lessonBody);
  renderLesson(lessonBody, lesson);

  const quizSectionMount = document.createElement('div');
  quizSectionMount.style.marginTop = 'var(--space-8);';
  layout.contentSlot.appendChild(quizSectionMount);
  const quizCleanup = mountQuizSection(quizSectionMount, cleanupFns, { language, lesson });

  const notesSectionMount = document.createElement('div');
  notesSectionMount.style.marginTop = 'var(--space-8);';
  layout.contentSlot.appendChild(notesSectionMount);
  const notesCleanup = mountNotesSection(notesSectionMount, lesson.id);
  cleanupFns.push(notesCleanup);

  const starterCode = lesson.codeBlocks?.[0]?.code ?? '';
  const desktopEditor = new Editor({ code: starterCode, editorLanguage: language.editorLanguage });
  desktopEditor.mount(layout.editorSlot);
  cleanupFns.push(() => desktopEditor.destroy());

  let mobileDrawer = null;
  let mobileEditor = null;
  if (!isDesktop) {
    mobileDrawer = new EditorDrawer();
    mobileDrawer.mount(container);
    mobileEditor = new Editor({ code: starterCode, editorLanguage: language.editorLanguage });
    mobileEditor.mount(mobileDrawer.editorSlot);
    cleanupFns.push(() => mobileEditor.destroy());
  }

  const navCleanup = renderLessonNavigation(breadcrumbNavMount, {
    language,
    tier,
    tierLabel: tierData.label ?? tier,
    lesson,
    adjacency,
    onNavigate: (direction) => navigateToAdjacent(language, tier, adjacency, direction),
  });
  cleanupFns.push(navCleanup);

  const swipeCleanup = attachSwipeNavigation(lessonBody, {
    onSwipeLeft: () => adjacency.next && navigateToAdjacent(language, tier, adjacency, 'next'),
    onSwipeRight: () => adjacency.prev && navigateToAdjacent(language, tier, adjacency, 'prev'),
  });
  cleanupFns.push(swipeCleanup);

  const keyboardCleanup = attachLessonKeyboardShortcuts({
    onNext: () => adjacency.next && navigateToAdjacent(language, tier, adjacency, 'next'),
    onPrev: () => adjacency.prev && navigateToAdjacent(language, tier, adjacency, 'prev'),
  });
  cleanupFns.push(keyboardCleanup);

  cleanupFns.push(() => layout.destroy());
  if (mobileDrawer) cleanupFns.push(() => mobileDrawer.destroy());
  cleanupFns.push(quizCleanup);

  // Recording a view is always genuine, live state.
  store.dispatch({ type: 'progress/recordView', payload: { lessonId: lesson.id } });
}

/**
 * Renders a bookmark toggle button next to the breadcrumb (spec §16:
 * "Bookmark lessons: Heart icon on lesson cards and lesson page.").
 * Subscribes to the Store so the icon stays in sync if the bookmark is
 * toggled from elsewhere (unlikely in this single-view app today, but
 * correct regardless — the button is never stale relative to state).
 *
 * @param {HTMLElement} mount
 * @param {string} lessonId
 * @returns {() => void} cleanup
 */
function mountBookmarkButton(mount, lessonId) {
  const button = document.createElement('button');
  button.className = 'btn btn--icon';
  button.setAttribute('aria-label', 'Bookmark this lesson');
  button.style.flexShrink = '0';

  const render = () => {
    const bookmarked = isLessonBookmarked(lessonId);
    button.textContent = bookmarked ? '♥' : '♡';
    button.style.color = bookmarked ? 'var(--error)' : 'var(--text-secondary)';
    button.setAttribute('aria-pressed', String(bookmarked));
  };

  const onClick = () => toggleLessonBookmark(lessonId);
  button.addEventListener('click', onClick);

  render();
  const unsubscribe = store.subscribe(render);
  mount.appendChild(button);

  return () => {
    button.removeEventListener('click', onClick);
    unsubscribe();
  };
}

/**
 * Renders a Markdown-capable notes textarea for this lesson (spec §16).
 * One note per lesson (see NoteManager.js's file-level comment for why).
 * Saves on blur and via a debounce-free "Save note" button — no
 * autosave-on-every-keystroke, so the Store doesn't get a dispatch (and
 * therefore a storage write) per character typed.
 *
 * @param {HTMLElement} mount
 * @param {string} lessonId
 * @returns {() => void} cleanup
 */
function mountNotesSection(mount, lessonId) {
  const existingNote = getNoteForLesson(lessonId);

  mount.innerHTML = `
    <h2 style="font-size: var(--text-xl); margin-bottom: var(--space-3);">Your Notes</h2>
    <p style="color: var(--text-tertiary); font-size: var(--text-xs); margin-bottom: var(--space-2);">Markdown supported.</p>
    <textarea class="textarea" rows="4" placeholder="Jot down anything you want to remember about this lesson…" style="resize: vertical;"></textarea>
    <button class="btn btn--secondary" style="margin-top: var(--space-3);">Save note</button>
    <span data-save-status style="margin-left: var(--space-3); color: var(--text-tertiary); font-size: var(--text-xs);"></span>
  `;

  const textarea = mount.querySelector('textarea');
  const saveBtn = mount.querySelector('button');
  const statusEl = mount.querySelector('[data-save-status]');

  textarea.value = existingNote?.content ?? '';

  const onSaveClick = () => {
    saveNote(lessonId, textarea.value);
    statusEl.textContent = 'Saved';
    setTimeout(() => {
      statusEl.textContent = '';
    }, 1500);
  };

  // Ctrl/Cmd+S also saves (spec §20), scoped to while this textarea has focus.
  const onKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      onSaveClick();
    }
  };

  saveBtn.addEventListener('click', onSaveClick);
  textarea.addEventListener('keydown', onKeyDown);

  return () => {
    saveBtn.removeEventListener('click', onSaveClick);
    textarea.removeEventListener('keydown', onKeyDown);
  };
}

/**
 * Dispatches `progress/completeLesson` and awards the lesson's own XP
 * (from meta.json, spec §5.2's per-lesson `xp` field) — but only the
 * first time this lesson is completed. Without the guard, re-triggering
 * completion (e.g. every correct-quiz check after all quizzes are
 * already done) would re-award lesson XP repeatedly, which
 * `awardQuizXp`'s per-quiz award correctly does NOT do (that's keyed to
 * individual quiz submissions, not lesson completion).
 *
 * @param {Object} lesson - Compiled lesson JSON, needs at least { id, xp }.
 */
function completeLessonOnce(lesson) {
  const alreadyCompleted = Boolean(store.getState().progress.byLessonId[lesson.id]);
  store.dispatch({ type: 'progress/completeLesson', payload: { lessonId: lesson.id } });
  if (!alreadyCompleted && lesson.xp) {
    store.dispatch({ type: 'xp/award', payload: { source: `lesson:${lesson.id}`, amount: lesson.xp } });
  }
}

/**
 * Fetches this lesson's attached quizzes and renders one `QuizEngine`
 * per quiz. Tracks correct-answer state across all of them and
 * completes the lesson (via `completeLessonOnce`) the moment every quiz
 * has been answered correctly at least once (spec §7, §15). A lesson
 * with no quizzes attached completes immediately, since there's nothing
 * to gate completion on.
 *
 * @param {HTMLElement} mount
 * @param {Array<() => void>} cleanupFns
 * @param {{ language: Object, lesson: Object }} ctx
 * @returns {() => void} cleanup
 */
function mountQuizSection(mount, cleanupFns, { language, lesson }) {
  let cancelled = false;
  const engineCleanups = [];

  getQuizzesByIds(language.id, lesson.quizIds)
    .then((quizzes) => {
      if (cancelled) return;

      if (quizzes.length === 0) {
        completeLessonOnce(lesson);
        return;
      }

      const heading = document.createElement('h2');
      heading.style.fontSize = 'var(--text-xl)';
      heading.style.marginBottom = 'var(--space-4)';
      heading.textContent = 'Check your understanding';
      mount.appendChild(heading);

      /** @type {Set<string>} quiz ids answered correctly at least once this render */
      const correctlyAnswered = new Set();

      const quizzesWrapper = document.createElement('div');
      quizzesWrapper.style.display = 'flex';
      quizzesWrapper.style.flexDirection = 'column';
      quizzesWrapper.style.gap = 'var(--space-4)';
      mount.appendChild(quizzesWrapper);

      for (const quiz of quizzes) {
        const engine = new QuizEngine(quiz);
        engine.mount(quizzesWrapper);
        engineCleanups.push(() => engine.destroy());

        // QuizEngine dispatches quiz/recordAttempt on every submit; we
        // watch the store for this specific quiz reaching a correct
        // state rather than threading a callback through QuizEngine,
        // since the Store is already the single source of truth for
        // "was this quiz answered correctly" (spec §7).
        const unsubscribe = store.subscribe((state) => {
          const record = state.quiz.byQuizId[quiz.id];
          if (record && (record.bestScore ?? 0) >= 100) {
            correctlyAnswered.add(quiz.id);
            if (correctlyAnswered.size === quizzes.length) {
              completeLessonOnce(lesson);
            }
          }
        });
        engineCleanups.push(unsubscribe);
      }
    })
    .catch((err) => {
      if (cancelled) return;
      console.warn('Failed to load quizzes for lesson:', err);
      // Non-fatal: the lesson reader and editor above this section still
      // work fully; only the quiz section is affected (spec §23-style
      // partial degradation rather than a full-page error).
    });

  return () => {
    cancelled = true;
    for (const fn of engineCleanups) fn();
  };
}

/**
 * @param {Object} language
 * @param {string} tier
 * @param {ReturnType<typeof computeAdjacentLessons>} adjacency
 * @param {'prev'|'next'} direction
 */
function navigateToAdjacent(language, tier, adjacency, direction) {
  const target = direction === 'next' ? adjacency.next : adjacency.prev;
  if (!target) return;
  window.location.hash = `#/language/${language.id}/${tier}/${target.id}`;
}

/**
 * Global `J`/`K` (next/prev lesson) and `F`/`Esc` (fullscreen editor
 * toggle) shortcuts, scoped to this view's lifetime (spec §20). Ignored
 * while focus is inside an input/textarea/contenteditable so typing
 * "j" in a notes field (once notes exist, Slice 6) doesn't navigate away.
 *
 * @param {{ onNext: () => void, onPrev: () => void }} handlers
 * @returns {() => void} cleanup
 */
function attachLessonKeyboardShortcuts({ onNext, onPrev }) {
  const onKeyDown = (e) => {
    const target = e.target;
    const isTyping =
      target instanceof HTMLElement &&
      (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);
    if (isTyping) return;

    if (e.key === 'j' || e.key === 'J') {
      onNext();
    } else if (e.key === 'k' || e.key === 'K') {
      onPrev();
    } else if (e.key === 'f' || e.key === 'F') {
      store.dispatch({ type: 'ui/setEditorFullscreen', payload: { value: !store.getState().ui.editorFullscreen } });
    } else if (e.key === 'Escape' && store.getState().ui.editorFullscreen) {
      store.dispatch({ type: 'ui/setEditorFullscreen', payload: { value: false } });
    }
  };

  window.addEventListener('keydown', onKeyDown);
  return () => window.removeEventListener('keydown', onKeyDown);
}

/**
 * @param {HTMLElement} container
 * @param {string} message
 */
function renderNotFound(container, message) {
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1>Not found</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">${escapeHtml(message)}</p>
      <a href="#/home" class="btn btn--secondary" style="margin-top: var(--space-6); display:inline-flex;">Back to Home</a>
    </div>
  `;
}

/**
 * @param {HTMLElement} container
 * @param {Error} err
 */
function renderLoadError(container, err) {
  console.error('Failed to load lesson:', err);
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1>Something went wrong</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">This lesson couldn't be loaded.</p>
      <button class="btn btn--secondary" style="margin-top: var(--space-6);" onclick="window.location.reload()">Retry</button>
    </div>
  `;
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
