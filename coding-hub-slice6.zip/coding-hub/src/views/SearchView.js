/**
 * SearchView.js — pending Slice 7 (Search System, §14).
 * @param {HTMLElement} container
 * @returns {() => void} cleanup
 */
export default function SearchView(container) {
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16);">
      <h1>Search</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">
        Fuzzy search across lessons and languages is coming in a later build slice.
      </p>
      <a href="#/home" class="btn btn--secondary" style="margin-top: var(--space-6); display:inline-flex;">Back to Home</a>
    </div>
  `;
  return () => {};
}
