/**
 * HomeView.js
 *
 * Landing page: hero, then the full language grid (spec §29.2, Slice 2).
 * Fetches the master registry via LanguageRegistry, shows a Skeleton
 * while loading, and renders one Card per language — "complete"
 * languages link to their language hub, "roadmap" languages render the
 * same card shape but marked "Coming soon" (spec §30 final checklist:
 * "All 15 remaining languages have roadmap pages with voting/notify UI").
 * Voting/notify UI itself lands with the roadmap page content in a later
 * slice; this slice makes the distinction honestly visible rather than
 * pretending roadmap languages are already built out.
 *
 * @param {HTMLElement} container
 * @returns {() => void} cleanup
 */
import { getLanguages } from '../scripts/languages/LanguageRegistry.js';
import { Card } from '../scripts/components/Card.js';
import { Skeleton } from '../scripts/components/Skeleton.js';
import { store } from '../scripts/store/Store.js';
import { selectRecentlyViewed } from '../scripts/store/selectors.js';

export default function HomeView(container) {
  let cancelled = false;
  const cleanupFns = [];

  container.innerHTML = `
    <section class="reading-column" style="text-align: center; padding-top: var(--space-8); padding-bottom: var(--space-12);">
      <h1 style="font-size: var(--text-hero);">Coding Hub</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-4); font-size: var(--text-lg);">
        Learn to code, one lesson at a time.
      </p>
      <div style="display:flex; gap: var(--space-3); justify-content:center; margin-top: var(--space-8); flex-wrap: wrap;">
        <a href="#/search" class="btn btn--primary">Browse languages</a>
        <a href="#/progress" class="btn btn--secondary">View your progress</a>
      </div>
    </section>
    <section id="continue-learning-section"></section>
    <section style="margin-top: var(--space-8);">
      <h2 style="font-size: var(--text-2xl); margin-bottom: var(--space-6);">All Languages</h2>
      <div id="language-grid-mount"></div>
    </section>
  `;

  renderContinueLearning(container.querySelector('#continue-learning-section'));

  const gridMount = container.querySelector('#language-grid-mount');
  const skeleton = new Skeleton({ count: 8, height: '180px' });
  skeleton.mount(gridMount);

  getLanguages()
    .then((languages) => {
      if (cancelled) return;
      skeleton.destroy();
      renderLanguageGrid(gridMount, languages);
    })
    .catch((err) => {
      if (cancelled) return;
      skeleton.destroy();
      renderLoadError(gridMount, err);
    });

  return () => {
    cancelled = true;
    for (const fn of cleanupFns) fn();
  };
}

/**
 * @param {HTMLElement} mount
 * @param {Array<Object>} languages
 */
function renderLanguageGrid(mount, languages) {
  const grid = document.createElement('div');
  grid.className = 'grid';

  languages.forEach((language, index) => {
    const card = new Card({
      variant: 'language',
      staggerIndex: index,
      data: {
        ...language,
        href: language.status === 'complete' ? `#/language/${language.id}` : `#/language/${language.id}`,
      },
    });
    card.mount(grid);
  });

  mount.innerHTML = '';
  mount.appendChild(grid);
}

/**
 * @param {HTMLElement} mount
 * @param {Error} err
 */
function renderLoadError(mount, err) {
  console.error('Failed to load language registry:', err);
  mount.innerHTML = `
    <div class="card" style="text-align:center;">
      <p>Language data unavailable.</p>
      <button class="btn btn--secondary" style="margin-top: var(--space-4);" onclick="window.location.reload()">
        Retry
      </button>
    </div>
  `;
}

/**
 * Shows a "Continue Learning" card linking to the most recently viewed
 * lesson (spec §15), if any exists yet. Silent no-op otherwise — this
 * is a genuine progressive-disclosure feature, not a placeholder, it
 * just has nothing to show for a brand-new user.
 *
 * @param {HTMLElement} mount
 */
function renderContinueLearning(mount) {
  const state = store.getState();
  const recentlyViewed = selectRecentlyViewed(state);
  if (recentlyViewed.length === 0) return;

  const lastLessonId = recentlyViewed[0];
  mount.innerHTML = `
    <div class="reading-column" style="margin-bottom: var(--space-8);">
      <div class="card" style="display:flex; align-items:center; justify-content:space-between; gap: var(--space-4);">
        <div>
          <p style="color: var(--text-tertiary); font-size: var(--text-xs);">Continue learning</p>
          <p style="font-weight: var(--font-semibold); margin-top: var(--space-1);">${escapeHtml(lastLessonId)}</p>
        </div>
      </div>
    </div>
  `;
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
