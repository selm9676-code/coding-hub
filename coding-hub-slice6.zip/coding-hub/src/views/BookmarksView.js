/**
 * BookmarksView.js
 *
 * Real bookmarks list (spec §16). Shows every bookmark from the Store,
 * split into lesson bookmarks (linkable back to the lesson) and snippet
 * bookmarks (shown with their source lesson reference, since a snippet
 * on its own has no dedicated page to link to in this project).
 *
 * @param {HTMLElement} container
 * @returns {() => void} cleanup
 */
import { store } from '../scripts/store/Store.js';
import { getAllBookmarks } from '../scripts/bookmarks/BookmarkManager.js';

export default function BookmarksView(container) {
  const render = () => {
    const bookmarks = getAllBookmarks();
    const lessonBookmarks = bookmarks.filter((b) => b.type === 'lesson');
    const snippetBookmarks = bookmarks.filter((b) => b.type === 'snippet');

    container.innerHTML = `
      <div class="reading-column" style="padding-top: var(--space-8);">
        <h1>Bookmarks</h1>
      </div>
      <div style="max-width: var(--reading-width); margin-inline:auto; margin-top: var(--space-8);">
        <h2 style="font-size: var(--text-lg); margin-bottom: var(--space-4);">Lessons</h2>
        <div id="lesson-bookmarks-mount" style="display:flex; flex-direction:column; gap: var(--space-3); margin-bottom: var(--space-8);"></div>

        <h2 style="font-size: var(--text-lg); margin-bottom: var(--space-4);">Code Snippets</h2>
        <div id="snippet-bookmarks-mount" style="display:flex; flex-direction:column; gap: var(--space-3);"></div>
      </div>
    `;

    const lessonMount = container.querySelector('#lesson-bookmarks-mount');
    if (lessonBookmarks.length === 0) {
      lessonMount.innerHTML = `<p style="color: var(--text-tertiary); font-size: var(--text-sm);">No bookmarked lessons yet. Tap the bookmark icon on any lesson to save it here.</p>`;
    } else {
      lessonMount.innerHTML = lessonBookmarks
        .map(
          (b) => `
            <div class="card" style="display:flex; align-items:center; justify-content:space-between;">
              <span>${escapeHtml(b.targetId)}</span>
              <span style="color: var(--text-tertiary); font-size: var(--text-xs);">${formatDate(b.createdAt)}</span>
            </div>
          `
        )
        .join('');
    }

    const snippetMount = container.querySelector('#snippet-bookmarks-mount');
    if (snippetBookmarks.length === 0) {
      snippetMount.innerHTML = `<p style="color: var(--text-tertiary); font-size: var(--text-sm);">No bookmarked snippets yet.</p>`;
    } else {
      snippetMount.innerHTML = snippetBookmarks
        .map(
          (b) => `
            <div class="card" style="display:flex; align-items:center; justify-content:space-between;">
              <span>${escapeHtml(b.targetId)}</span>
              <span style="color: var(--text-tertiary); font-size: var(--text-xs);">${formatDate(b.createdAt)}</span>
            </div>
          `
        )
        .join('');
    }
  };

  render();
  const unsubscribe = store.subscribe(render);
  return unsubscribe;
}

/** @param {string} isoString @returns {string} */
function formatDate(isoString) {
  return new Date(isoString).toLocaleDateString();
}

/** @param {string} str @returns {string} */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
