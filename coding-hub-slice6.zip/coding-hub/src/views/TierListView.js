/**
 * TierListView.js
 *
 * Lists lessons within a single language/tier combination as lesson
 * cards, each showing completion status from the Store's progress slice
 * (spec §9, §15). Lesson content itself (the reader + editor) is Slice 3;
 * this view only needs the lesson list from meta.json plus progress data
 * that's already live from Slice 1.
 *
 * @param {HTMLElement} container
 * @param {import('../scripts/router/Router.js').RouteMatch} match
 * @returns {() => void} cleanup
 */
import { getLanguageById, getLanguageMeta } from '../scripts/languages/LanguageRegistry.js';
import { Card } from '../scripts/components/Card.js';
import { Skeleton } from '../scripts/components/Skeleton.js';
import { store } from '../scripts/store/Store.js';

export default function TierListView(container, match) {
  const { languageId, tier } = match.params;
  let cancelled = false;

  const skeleton = new Skeleton({ count: 4, height: '100px' });
  container.innerHTML = '';
  skeleton.mount(container);

  Promise.all([getLanguageById(languageId), getLanguageMeta(languageId)])
    .then(([language, meta]) => {
      if (cancelled) return;
      skeleton.destroy();

      if (!language) {
        renderNotFound(container, `Language "${languageId}" not found.`);
        return;
      }

      const tierData = meta.tiers?.[tier];
      if (!tierData) {
        renderNotFound(container, `Tier "${tier}" not found for ${language.name}.`);
        return;
      }

      renderLessonList(container, language, tier, tierData);
    })
    .catch((err) => {
      if (cancelled) return;
      skeleton.destroy();
      renderLoadError(container, err);
    });

  return () => {
    cancelled = true;
  };
}

/**
 * @param {HTMLElement} container
 * @param {Object} language
 * @param {string} tier
 * @param {Object} tierData
 */
function renderLessonList(container, language, tier, tierData) {
  const state = store.getState();

  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-8);">
      <p style="color: var(--text-tertiary); font-size: var(--text-sm);">
        <a href="#/language/${language.id}">${escapeHtml(language.name)}</a> / ${escapeHtml(tierData.label ?? tier)}
      </p>
      <h1 style="text-transform: capitalize; margin-top: var(--space-2);">${escapeHtml(tierData.label ?? tier)}</h1>
    </div>
    <div id="lesson-list-mount" style="max-width: var(--reading-width); margin-inline:auto; margin-top: var(--space-8);"></div>
  `;

  const mount = container.querySelector('#lesson-list-mount');

  if (!tierData.lessons || tierData.lessons.length === 0) {
    mount.innerHTML = `
      <div class="card" style="text-align:center;">
        <p style="color: var(--text-secondary);">Lessons for this tier are coming soon.</p>
      </div>
    `;
    return;
  }

  const list = document.createElement('div');
  list.style.display = 'flex';
  list.style.flexDirection = 'column';
  list.style.gap = 'var(--space-4)';

  tierData.lessons.forEach((lesson, index) => {
    const completed = Boolean(state.progress.byLessonId[lesson.id]);
    const card = new Card({
      variant: 'lesson',
      staggerIndex: index,
      data: {
        ...lesson,
        completed,
        href: `#/language/${language.id}/${tier}/${lesson.id}`,
      },
    });
    card.mount(list);
  });

  mount.appendChild(list);
}

/**
 * @param {HTMLElement} container
 * @param {string} message
 */
function renderNotFound(container, message) {
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1>Not found</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">${escapeHtml(message)}</p>
      <a href="#/home" class="btn btn--secondary" style="margin-top: var(--space-6); display:inline-flex;">Back to Home</a>
    </div>
  `;
}

/**
 * @param {HTMLElement} container
 * @param {Error} err
 */
function renderLoadError(container, err) {
  console.error('Failed to load tier list:', err);
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16); text-align:center;">
      <h1>Something went wrong</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">This page couldn't be loaded.</p>
      <button class="btn btn--secondary" style="margin-top: var(--space-6);" onclick="window.location.reload()">Retry</button>
    </div>
  `;
}

/**
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
