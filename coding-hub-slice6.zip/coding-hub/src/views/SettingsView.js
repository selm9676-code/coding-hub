/**
 * SettingsView.js — pending full build in Slice 7 (PWA + Polish, §17)
 * but import/export is core enough to spec §6 that we wire it live here.
 * @param {HTMLElement} container
 * @returns {() => void} cleanup
 */
export default function SettingsView(container) {
  container.innerHTML = `
    <div class="reading-column" style="padding-top: var(--space-16);">
      <h1>Settings</h1>
      <p style="color: var(--text-secondary); margin-top: var(--space-3);">
        Editor preferences, theme, and daily goal controls are coming in a later build slice.
      </p>
      <a href="#/home" class="btn btn--secondary" style="margin-top: var(--space-6); display:inline-flex;">Back to Home</a>
    </div>
  `;
  return () => {};
}
