/**
 * ProgressView.js
 *
 * Real progress dashboard (spec §15). Delegates all rendering to
 * StatsDashboard.js and re-renders on every Store change, matching the
 * pattern the Slice 1 stub already established.
 *
 * @param {HTMLElement} container
 * @returns {() => void} cleanup
 */
import { store } from '../scripts/store/Store.js';
import { renderStatsDashboard } from '../scripts/progress/StatsDashboard.js';

export default function ProgressView(container) {
  const render = () => renderStatsDashboard(container, store.getState());

  render();
  const unsubscribe = store.subscribe(render);
  return unsubscribe;
}
